/**************************************************************************

Copyright:HIKVISION

Author: HD

Date:2019-11-19 ; 2020-5-18

Description: arm control basic functions , it's a virtual base class
For different robot(Dof<=6), 1-8 need to be changed !!!

**************************************************************************/

#ifndef _ARM_BASICS_H_
#define _ARM_BASICS_H_

#include "eigen_math/common_functions.h"

typedef struct
{
    Vector6f toolPos;
    Vector6f jointPos,jointPosLast,
    jointRealPos,jointRealVel,jointRealVelLast,jointRealAcc;
    Vector6f jointCurrent;
    Matrix4f T_tool2base;
}armFeedBack;
typedef struct
{
    float d4,d2,xTool,yTool,zTool;
    int dof;
    Vector6f dhParam;
    Vector6f mass;
    Matrix<float,6,3> inertia,centre;

    Vector6f zeroPos;

    Matrix<float,6,2> jointPosLimit;
    Vector6f jointVelLimit,jointAccLimit;
    Vector6f kTorque;
    Matrix<int,6,1> jointType;// 0-rotate 1-line
}armParam;
typedef enum
{
    RUNNING  = 0,
    FINISHED = 1,
    IKERROR  = 2,
    COLLISION= 3,
    WAIT     = 4,
}armState;

class ArmBasics
{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    ArmBasics();                                                   //1
    ~ArmBasics();

    armFeedBack ReadArmState();
    armParam ReadArmParam();
    Vector6f CalCurrentByTheoryPos();
    Vector6f CalCurrentByRealPos();
    Vector6f ArmDynamicDH(const Vector6f &qIn,const Vector6f &qdIn,
                          const Vector6f &qddIn);
    void LoadParam();                                              //2

    bool JointLimit(bool isFeedBack,Vector6f& angle);
    bool ArmIK(Matrix4f &T_tool2base,Vector6f *output);            //3
protected:
    /**
    *@brief vel control
    * return :interp result
    */
    Vector6f VelControl(Vector6f &joint,Vector6f &vd);
    Matrix<float,6,5> Jacobian0(Vector6f &joint);

    /**
    *@brief forward kinematics
    *
    */
    Matrix3f GetRotToolZero2base();                                //4
    Matrix4f ArmFK(const Vector6f &angle);                         //5
    Matrix4f ArmPosCal(const Vector6f &angle,Vector6f* posInBase); //6
    Matrix3f GetRotToolNext2base(const Vector3f& rpy,const Matrix3f &R_toolNow2base );

    /**
    *@brief inverse kinematics
    * return :0-IK error; 1-no error
    */
    int ArmIKCheck(const Vector3f &rpy,const Vector3f &pos, int IKtype,Vector6f* angle);//return :false-IKerror
    bool IkErrorCheck(Matrix4f &T,Vector6f &angle,Vector6f *output);
    bool ArmIK(const Vector3f &rpy,const Vector3f &pos,Vector6f *output);
    bool ArmIK(const Vector6f &goal,Vector6f *output);
    bool ArmIKForCheck(const Vector6f &goal,Vector6f *output,Matrix4f *Ttool2base);
    float AngleTrans(float t4);

    /**
    *@brief basic dynamic functions
    */
    Vector6f Current2torque(Vector6f &torque);
    Vector6f Torque2Current(Vector6f &torque);

    Matrix6_6f MCG(Vector6f &q,Vector6f &qd,Vector6f* Cq,Vector6f* Gf);//7
    void Ctq(Vector6f &q,Vector6f &qd,Vector6f* Ct);                   //8

    //--control params
    armParam m_armParam;
    typedef struct
    {
        Vector6f toolPos;
        Vector6f jointPos,jointPosLast,
        jointVel,jointVelLast,jointAcc;
        Vector6f jointCurrent,jointTorque;
    }armInput;
    armInput m_armInput;
    armFeedBack m_armFeedBack;

    //--IK state
    bool m_isIkError;
    //-- arm state
    armState m_armState;

};

#endif
