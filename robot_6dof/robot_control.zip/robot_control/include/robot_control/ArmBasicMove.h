/**************************************************************************

Copyright:HIKVISION

Author: HD

Date:2020-1-6

Description: arm basic move

**************************************************************************/

#ifndef _ARM_BASIC_MOVE_H_
#define _ARM_BASIC_MOVE_H_

#include "eigen_math/common_functions.h"
#include "robot_control/ArmBasics.h"
#include "robot_control/spline.h"
#include "json/Defs.h"

class ArmBasicMove:virtual public ArmBasics
{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    ArmBasicMove();
    ~ArmBasicMove();

    /**
        *@brief basic move function
        */
    bool MovePoint(Vector6f &goalToolPos);
    bool SetJointPos(Vector6f &goalJointPos);
    bool MoveL(Vector6f &goalPos,float totalT);

    bool MoveC(Vector3f &posVia,Vector3f &posEnd,float totalT);
    bool MoveJ(Vector6f &goalPos,float totalT);
    bool MoveJAV(Vector6f &goalToolPos );
    bool MoveToJointPos(Vector6f &goalJointPos,float velPercent);

    bool MoveS(vector<ROUTE_NODE> point);
    bool MoveSJ(vector<ROUTE_NODE> point);
    bool Swing(const Vector3f &ps,const Vector3f &pe,
               const float swingHeight,const float totalT);
    bool MoveRot(Vector3f &rotCmd,float totalTime);

protected:
    /**
        *@brief route reset
        */
    bool Wait(float waitTime);//unit:s
    bool IsFinished(float time);
    void ResetStartPos();
    void ResetSroute();
    /**
        *@brief traj interp
        */
    tk::spline m_spline[6];
    Vector3f Interp3DCircle(Vector3f& ps,Vector3f& pm,Vector3f& pe,
                            float totalT,float tNow);
    float InterpCubicTraj(float start,float endpos,
                          float tf,float tNow);
    float InterpTtraj(float t,float s,float a,
                      float v,float *T_all);
    float InterpWhenEndposChange(float S,float E,float sV,
                                 float tf,float t);
    /**
        *@brief route constrain
        */
    void VelLimit(float* time);

    //--state calculate
    Vector3f GetRPYtoolNext2toolZero(Matrix3f& R_toolNow2base,Vector3f& rotGoal);
    void CalculateVelAcc(Vector6f &realJointPos);

    //--route move
    typedef struct
    {
        float now;
        float Hz;
    }time;
    time m_time;

    typedef struct
    {
        //start pos
        Vector6f startPos,startJointPos;
        Matrix4f startPose;
        //S route points
        vector<ROUTE_NODE> Points;   //Points=[S route point]
        Matrix<bool,1,2> iSsRouteInitiated;
        int routeNum;                //points total num
        float totalTime;
    }routeParam;
    routeParam m_sRoute;

};

#endif
