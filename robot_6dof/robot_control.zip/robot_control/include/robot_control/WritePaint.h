/**************************************************************************

Copyright:HIKVISION

Author: HD

Date:2019-12-3

Description: arm motion control functions

**************************************************************************/

#ifndef _WRITE_PAINT_H_
#define _WRITE_PAINT_H_

#include "eigen_math/common_functions.h"
#include "robot_control/MotionCtrl.h"
#include "robot_control/ArmCollisionDetect.h"
class WritePaint
{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    WritePaint();
    ~WritePaint();
    static WritePaint* GetPtr();

    //--app
    void FollowMove(int state,Vector3f& imu1,Vector3f& imu2,Vector3f& imu3,Vector3f& imu4);
    void FollowMove2(int state,Vector3f& imu1,Vector3f& imu2,Vector3f& imu3,Vector3f& imu4);

protected:
    MotionCtrl* m_arm;
    armFeedBack m_armFeedBack;
    Vector6f m_outputAngle;
    //--imu motion capture
    Vector3f CalImuMotion(Matrix3f& R_body2w,Matrix3f& Rs_body
                          ,Matrix3f& R_upperArm2w,Matrix3f& Rs_upperArm);
public:
    //--write words
    void TrajMove();
    void ReadPoint();
    void WriteInit();
    void WriteWords();
    void CalibPlane();
    Vector3f PaintTrans(const Vector3f& in );
    Vector3f WordsPointTrans(const Vector3f& in);
    typedef struct
    {
       Matrix<float,100,4> wordPoint;
       int totalRow;
       bool isSwing;
       Vector3f offset;
       int initiateCmd,count,step;
       Vector2f pointBlast;
       Matrix3f planePoint;
       Matrix4f T_plane2base;
       Matrix<bool,4,1> planeInit;
    }write;
    write m_write;

public:
    //--paint
    void PaintInit();
    void Paint();
    Vector3f ReadPaintPoint();
    int GetDataRows(string path);
    typedef struct
    {
        string path;
        int dataRows,count;
        int paintStep;
        Vector3f posLast;
        bool isSwing;
    }paint;
    paint m_paint;

public://copy move
    int CopyMove(int logCmd,int handCmd,Vector6f &realJointPos,
                 int *handMove);
    bool LogOutput(Vector6f *goalPos,int *handMove);
    void LogInit();
    typedef struct
    {
        string path;
        int logMoveState,cmdHandLast;
        Vector2i num;
        Vector6f logPos;
    }copyMove;
    copyMove m_copyMove;
};

#endif
