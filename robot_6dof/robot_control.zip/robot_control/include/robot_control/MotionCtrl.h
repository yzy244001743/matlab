/**************************************************************************

Copyright:HIKVISION

Author: HD

Date:2019-12-3

Description: arm motion control functions

**************************************************************************/

#ifndef _MOTION_CONTROL_H_
#define _MOTION_CONTROL_H_

#include "eigen_math/common_functions.h"

#include "robot_control/MoveCmd.h"

#include "robot_control/ArmBasics.h"
#include "robot_control/ArmCollisionDetect.h"
#include "robot_control/ArmBasicMove.h"

class MotionCtrl:public ArmBasicMove, public CollisionDectect
{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    MotionCtrl();
    ~MotionCtrl();
    static MotionCtrl* GetMotionCtrlPtr();
    static MotionCtrl* GetMotionCtrlSimPtr();

    //--api functions
    void GetGoalJointPos(Vector6f *jointPos);
    void GetGoalJointTorque(Vector6f *jointPos);
    void GetTend2base(Matrix4f *T_end2base);
    Vector6f GetToolPosError();
    void ArmSimInterface(Vector6f& jointCurrent, Vector6f* simJointPos);
    void ArmInterface(MOTORMODE motorMode,
                      Vector6f& realJointPos,Vector6f& jointCurrent,
                      Vector6f* theoryJointPos,Vector6f* goalTorque );
    //--test
    void LineMoveTest(Vector3f& pointA,Vector3f& pointB,Vector6f *goalAngle);
    void ImpedanceCtrlTest();
    void SplineTest();

    //--bottle catch test
    bool CupCatchTrajGen(float deltaY,float deltaZ,float cupHeight);
    bool BottleCatchTrajGen(float Y,float Z,float H);
    Vector3f CalCatchPos(Vector3f &startPos,Vector3f &endPos,float deltaR,
                         float* thetaStart,float* thetaEnd);
    bool CircleInterrupt(float cycle,float nodeTime,float cupHeight);

private:
    void ParameterInit();
    void UpdateRobotStatus(Vector6f& theoryJointPos,
                           Vector6f& realJointPos,Vector6f& realJointTor);
    void ControlLoop();
    void SafeControl();
    void TrajFollowByTorque(Vector6f &goalJointPos,float kBuffer);

    //--mode function
    void VelMove(Vector6f& toolVel);
    bool PointMove(Vector6f& toolVel,float kAcc);
    bool JointMove(Vector6f& jointVel,float kAcc);
    void SlowMove();
    bool RouteMove();
    void ReturnZeroPos();
    void FreeDrive();
    void CalFeedforwardCurrent(Vector6f *jointCurrent);
    void Suspend(float time);
    bool InterruptMoveJ();

    //--route read,check,optimize
    bool CopyCmd2Route();
    void PrintPoint(vector<ROUTE_NODE>::iterator iter);
    void ReadRoute(NODE_TYPE node);

    bool CheckMovePoint(Vector6f &endPoint,Vector6f *jointPos);
    bool CheckRotPoint(Vector3f *endPos,Vector3f *rpyEnd);
    bool CheckRotPose(Vector3f *endPos,Vector3f *rpyEnd);

    void ChangeRouteUnit(vector<ROUTE_NODE>::iterator iter);
    void ChangeJointUnit(vector<ROUTE_NODE>::iterator iter);
    Vector6f GetGoalFromCmd(vector<ROUTE_NODE>::iterator iter);
    bool InitInterruptMove();

private:
    //--filter
    Vector6f CmdLowFilter(float kLowFilter,const Vector6f &in);

    //--other function
    void PrintInfo();
    bool EndPointCorrection(Vector3f *endPos,Vector3f *rpyEnd);

    Vector6f m_cmdLast;

    typedef struct
    {
        bool isNextPoint;
        bool isFirstPoint,isPrint;   //if change to next node, print nodeInfo

        vector<ROUTE_NODE> pointPlan;//pointPlan=[all point]
        vector<ROUTE_NODE>::iterator iter,iterHead,iterEnd;
        int numNow;//print current node
    }motionParam;
    motionParam m_move;
    typedef struct
    {
        Vector6f startJointPos,endJointPos,startJointVel;
        float totalTime;
    }interrupt;
    interrupt m_interrupt;
};

#endif
