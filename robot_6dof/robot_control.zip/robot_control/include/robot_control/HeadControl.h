/**************************************************************************

Copyright:HIKVISION

Author: HD

Date:2021-1-18

Description: 2Dof-head control
**************************************************************************/

#ifndef _HEAD_CONTROL_H
#define _HEAD_CONTROL_H

#include "eigen_math/common_functions.h"

class HeadControl
{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    HeadControl();
    ~HeadControl();
    static HeadControl* GetPtr();
    /**
    *@brief initialize the present position to the zero position
    * if return 1, initialize finished
    */
    void Init(Matrix4f T_headBase2robotBase, Matrix4f T_camera2headEnd);

    Matrix4f GetT_camera2robotBase(float in[2]);//output translation
    Matrix4f HeadFK(float in[2]);

private:

     void CalHeadCamAccuracy(Matrix4f & T_camera2robotBase,Matrix4f &T_manipulator_end2base);

    typedef struct
    {
        Matrix4f T_camera2headEnd;      //calculated by T_cameraZero2robotBase
        Matrix4f T_headBase2robotBase;  //calculated by T_cameraZero2robotBase T_camera2headEnd
        Matrix4f T_headEnd2headBase;    //FK result
    }m_Trans;
    m_Trans m_headTrans;


};

#endif
