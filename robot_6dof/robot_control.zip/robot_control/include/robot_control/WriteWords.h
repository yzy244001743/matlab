/**************************************************************************

Copyright:HIKVISION

Author: HD

Date:2019-12-3

Description: arm motion control functions

**************************************************************************/

#ifndef _WRITE_WORDS_H_
#define  _WRITE_WORDS_H_

#include "eigen_math/common_functions.h"
#include "robot_control/MotionCtrl.h"

class WriteWords:virtual public MotionCtrl
{
public:
    WriteWords();
    ~WriteWords();

    //--write words
    void TrajMove();
    void ReadPoint();
    void WriteInit();
    void WriteWord();
    Vector3f WordsPointTrans(const Vector3f& in );
    typedef struct
    {
        Matrix<float,100,4> wordPoint;
        int totalRow;
        bool initiateOffset,isSwing;
        Vector3f offset;
        int initiateCmd,count,step;
        Vector2f pointBlast;
    }write;
    write m_write;
};

#endif
