/**************************************************************************

Copyright:HIKVISION

Author: HD

Date:2020-12-9

Description: collision detect based on dynamics

**************************************************************************/

#ifndef _ARM_COLLISION_DETECT_H_
#define _ARM_COLLISION_DETECT_H_

#include "eigen_math/common_functions.h"
#include "robot_control/ArmBasics.h"
class CollisionDectect: virtual public ArmBasics
{
public:
    CollisionDectect();
    ~CollisionDectect();
    void CollisionInitiate();
    void CollisionDetect();
    Vector6f FrictionCal(Vector6f &qd);

private:
    void PrintCollisionError(Vector6f &r,Vector6f &q,Vector6f &qd,
                             Vector6f &qdd,Vector6f &taoFeedback,
                             Vector6f &qdFeedback,Vector6f &friction);
    void PrintCollisionInfo(Vector6f &r);
    Vector6f HighPassFilterRC(Vector6f &Vi,Vector6f *Vi_p,Vector6f *Vo_p,
                              float sampleFrq,float CutFrq );
    Vector6f VelLowFilter(float kLowFilter,const Vector6f &in);
    Vector6f TorqueLowFilter(float kLowFilter,Vector6f &in);

    typedef struct
    {
        bool isFirst,isCollision;
        int cout;
        float initiateTime;
        Vector6f rMax;
        Vector6f velLast;
        Vector6f viP,voP;
    }collision;
    collision m_collision;

    Vector6f m_torqueLast;

};

#endif
