/**************************************************************************

Copyright:HIKVISION

Author: HD

Date:2019-12-3

Description: arm move cmd
different robots, f1 f2  f3 need to be changed
**************************************************************************/

#ifndef _ARM_MOVE_CMD_H
#define _ARM_MOVE_CMD_H

#include "eigen_math/common_functions.h"
#include "json/Defs.h"

#include <mutex>


typedef enum
{
    //--motion state
    FOLLOW_MOVE_OFF=0,
    FOLLOW_MOVE_ON=1,
    TRAJ_MOVE=2,
    POINT_MOVE,
    JOINT_MOVE,
    ROUTE_MOVE,
    RETURN_ZERO,
    STOP, //7
    SLOW_DOWN,
    INTERRUPT,
    SUSPEND,
    //--motor mode
    FREE_DRIVE, //
    //--hardware state
    START,
    CLOSE,
    POWER_OFF,//initial state
    COPY_MOVE,//
}MODE;

typedef enum
{
    POS_MODE       =0,
    TORQUE_MODE    =1,
    IMPEDANCE_MODE =2,
}MOTORMODE;

typedef struct
{
   //--arm control
   float Hz;
   float speed; //0~1
   int mode,modeLast;
   bool isSimulate;
   Vector3f velMax; //[XYZ vel, RPY vel, joint Vel]
   Vector6f toolVel,jointVel;

   //--route
   bool isUpdate;
   std::vector<ROUTE_NODE> route;

   //--print option
   bool isJointTest;
   Vector6f errorLImit;
   Matrix<int,2,1>  printJointCurrent,printMotorError,printToolError,printAllJointInfo;
   Matrix<int,3,1>  printJointInfo;
   bool isPrintTheoryTorque,isPrintNode,isLoopTest;

   //--collision
   Vector6f collisionLimit,collisionSet,collisionErrLimit;
   Vector6f printCollision;
   int isCollision;
   bool collisionOn;

   //--arm app
   int planePoint,log;

   //--hand & head & wheel control
   Vector6f hand,head;
   Matrix<float,7,1> wheel;
}Move;
typedef struct
{
   Vector6f toolPos,jointPos;
   int armState,headState,handState,wheelState;
   Matrix4f T_camera2robotBase;
}armPosInfo;


class MoveCmd
{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    MoveCmd();
    ~MoveCmd();
    /**
    *@brief initialize the present position to the zero position
    * if return 1, initialize finished
    */
    void PointMove(MOVE_DIRECTION direction, RPY_DIRECTION rpy,ACTION_TYPE action);
    void JointMove(JOINT_PART_NAME jointName, CONTROL_DIRECTION control,ACTION_TYPE action);
    void SetSpeed(int speed);
    void FreeDrive(ACTION_TYPE action);
    void HomingSet();
    void CloseRobot();
    void StartRobot();
    void PlayRoute(std::vector<ROUTE_NODE> trajectoryList);
    void PlayStop();
    void RobotModeSet(ROBOT_MODE mode);
    CURRENT_POSITION GetCurrentPosition(); //f1
    int GetArmStatus();
    int GetHeadStatus();
    int GetHandStatus();
    int GetWheelStatus();
    void GetT_camera2armBase(float *rpyxyz);
protected:
//    typedef enum  //pointMove
//    {
//        X=1,
//        Y=2,
//        Z=0,
//    }AXIS_POS_ORDER;
//    typedef enum
//    {
//        ROLL=0,
//        PIT=2,
//        YAW=1,
//    }AXIS_RPY_ORDER;

    typedef enum  //home_robot
    {
        X=0,
        Y=1,
        Z=2,
    }AXIS_POS_ORDER;   //f2
    typedef enum
    {
        ROLL=1,
        PIT=2,
        YAW=0,
    }AXIS_RPY_ORDER;   //f3

//    typedef enum
//    {
//        X=1,
//        Y=2,
//        Z=0,
//    }AXIS_POS_ORDER;
//    typedef enum  //velMove
//    {
//        ROLL=2,
//        PIT=1,
//        YAW=0,
//    }AXIS_RPY_ORDER;


};

#endif
