/**************************************************************************

Copyright:HIKVISION
Author: HD
update history:
------
2019-09-05,2019-12-11,2020-4-1,2020-5-15,
2020-07-21(acc vesion 1),
2020-08-22 增加新指令覆盖
2020-08-25 增加get_acc()获取设定的加速度值
2020-09-11 增加YB_robot低速变积分
2020-10-12 增加YB_robot抱起抖动抑制
2020-10-30 增加W_ANGLE_IMU增加防止参数误输入
2020-11-04 增加 set_dance_interp_period
------
Description:Provide motion control functions to wheel robot
----------------------------------------------
example:
正常调用：
ret=calc_motion_control_target_set(type,cmd_type, vel_forward, w_rot, pos_forward, angle_rot)  //if return -1,input error
ret=calc_motion_control_res_get(int *left_val,int *right_val)                                  //if move finished return 1 ; if error,return -1 ; else return0;
------
常用设置:
void  calc_motion_control_r_turn_set(R):         旋转点到小车中心的距离，例如旋转点在左轮，则R=car_width/2 ;若在右轮则R=-car_width/2
void  calc_motion_control_acc_set(float acc);    设置轮子线速度的加速度
float get_acc(void);                             获取当前设置的加速度值
void  set_dance_interp_period(float num);        修改舞蹈数据插值周期，1表示10ms更新一次数据
------
初始化：
（异常停止后重新运行，如运动指定距离或者指定角度时没有返回1就停止调用、小车运动过程中被劫持需要重新定位等情况）
reset_direction();
calc_motion_control_algorithm_reinit();
---------------------------------------------
无IMU模式：
V_W：  小车按照给定的线速度和角速度运动
V_DIS: 输入平均速度和距离，小车按照T型速度曲线进行直线运动
W_ANGLE：输入平均角速度和角度，小车按照T型速度曲线进行转动
IMU闭环模式:
V_W_IMU： 若只输入线速度，则基于IMU闭环控制小车直线行走（受到干扰时能自动纠正运动方向）；若只输入角速度，基于IMU闭环旋转运动。（角速度优先级高于线速度）
W_ANGLE_IMU：输入平均角速度和运动需要到达的角度，基于IMU闭环控制停止的角度等于输入的目标角度；
V_ANGLE_IMU： 输入线速度和方位角度，线速度通过编码器进行闭环控制，方位角通过IMU进行闭环控制，控制小车按照动画中的效果进行运动
---------------------------------------------
具体调用方法:
without imu:
1.calc_motion_control_target_set(V_W,指令类型,vel_forward,w_rot,0,0,0)          //remote control
2.calc_motion_control_target_set(V_DIS,指令类型,vel_forward,0,pos_forward,0,0)  // move to pos_forward in velocity of vel_forward
3.calc_motion_control_target_set(W_ANGLE,指令类型,0,w_rot,0,angle_rot,0)        // rotate to angle_rot

with imu:
4.calc_motion_control_target_set(V_W_IMU,指令类型,vel_forward,w_rot,0,0,0)         //rotate and move forward
5.calc_motion_control_target_set(W_ANGLE_IMU,指令类型,0,w_rot,0,angle_rot,0)       //rotate to angle_d
6.calc_motion_control_target_set(V_ANGLE_IMU,指令类型,vel_forward,0,0,angle_rot,0) //dance mode

attention:!!!
对于这三种模式: V_DIS ,W_ANGLE ,W_ANGLE_IMU
如果未返回1就给入新的指令，若需以当前位置为零点运动到新指令点,则指令类型=NEWCMD，否则指令类型=OLDCMD;
另外若给入的pos_forward或angle_rot和上一次给入的指令不同，则会自动认为新指令，以当前位置为零点运动到新指令点.
----------------------------------------------
unit: m/s , rad/s  , m

car & IMU direction:
Anti-clockwise w_rot>0
move forward   vel_forward>0

imu anti-clockwise : (0,pi)||(-pi,0)
**************************************************************************/

#ifndef __CALC_MOTION_CONTROL_H
#define __CALC_MOTION_CONTROL_H

#ifdef __cplusplus
extern "C" {
#endif

//--choose robot !!!
//#define _YBROBOT
//#define _CLEANROBOT
#define _HOMEROBOT
/**
*@brief get sensor datas
*input:
*output:
*/

#ifdef _YBROBOT
#include "ezapp_bsp_interface.h"
#include "ezapp_states_manager.h"
extern int ezapp_get_backed_imu_rpy(float *roll,float *pitch,float *yaw);
extern int ezapp_get_relative_encoder(int *left_motor,int *right_motor);
#endif
#ifdef _CLEANROBOT
//extern int bsp_get_imu_encoder(float *imu ,int *left_motor,int *right_motor);
#endif

#include <stdbool.h>      //bool

//control mode: withou imu
#define V_W            0x00   //remote control
#define V_DIS          0x01   //move to pos_forward in velocity of vel_forward
#define W_ANGLE        0x04   //rotate to angle_rot
//control mode: with imu
#define V_W_IMU        0x02   //rotate and move forward
#define W_ANGLE_IMU    0x03   //rotate to angle_d
#define V_ANGLE_IMU    0x05   //dance mode

//cmd type
#define NEWCMD      1
#define OLDCMD      0

//other
#define PI_HD       3.14159265f
#define LOCALIMU    0
#define GLOBALIMU   1
#define YBROBOT     0
#define CLEANROBOT  1

//--params
//PID & otrher params
typedef struct
{
    float cycle;        // unit:s  control time
    float acc_occupy;   //0-1
    int   imu_update;   //  if == n,  update data per n cycles
    int   dance_update; // update data per n cycles
    float pos_pid[3];   //motor pos pid
    float vel_pid[4];   //motor vel pid [p ,i ,d ,f]
    float integrate[3]; //ctrl.integrate param {max_limit,interp start at A,interp end at B}
    float rotate_pid[6];//car rotate with imu pid  =[f_gain,p_gain,i_gain,p_line,i_line, limit];
    float dance_pid[4]; //dance pid [f_gain,p,i,limit]
    float motor_firction[2]; // [forward ,backward]
    float dacc_limit;
}ctrl_;
typedef struct
{
    int   imu_type;  //GLOBALIMU=1 LOCALIMU=0
    int   robot_type;//0:YB 1:clean robot
    float r_wheel;   // wheel radius
    float width_car; // unit:m
    float encoder;   // encoder pulses per circle
    float k_encoder; // =car.encoder/(car.r_wheel*2*PI)
}car_;
typedef struct
{
    float vel_forward;
    float w_rot;
    float pos_forward;
    float angle_rot;
    float r_turn;
    float t_d;
    float dance[2];
    int   cmd_last;
    bool  is_new_cmd;
}input_;
typedef struct
{
    int   ctrl_mode;
    bool  end_flag;
    int   count_time;
    float pos_d;
}inner_;
typedef struct
{
    int   encoder_right;
    int   encoder_left;
    float imu_yaw;
}sensor_;
typedef struct
{
    float theory_anlge;
    float real_angle;
    float start_angle;
    float real_w;
}dir_;
typedef struct
{
    bool pid_pos_right;
    bool pid_pos_left;
    bool pid_vel_right;
    bool pid_vel_left;

    bool car_rotate_pid;
    bool dance_pid;
    bool dance_interp;
    bool encoder;
    bool encoder_v;
}printf_;
typedef struct
{
    float kn[4];  //ks,ke,t1,t2;
    bool  acc_on; //turn on the acc interp
    float acc;    //m/s^2
    float acc_interp_last[2];
}vw_interp_;
typedef struct
{
    bool on;      //turn on the position control
    float encoder_desired[2];
    float encoder_feedback[2];
    float encoder_vd[2];
}pos_;
//--api functions
/**
*@brief initiate functions
*input:
*output:if return -1 - initiate error, else return 1;
*/
int calc_motion_control_cycle_params_init(float ctrl_cycle ,float acc_occupy,float imu_update);
int calc_motion_control_speed_pid_params_init(float p,float i,float d);
int calc_motion_control_postion_pid_params_init(float p,float i,float d);
int calc_motion_control_struct_param_init(float wheel_r,float car_width,float motor_encoders);
int calc_motion_control_algorithm_reinit(void);
/**
*@brief  when first start moving ,reset direction=[0,0]
*input:
*output:if return -1 - input error, else return 1;
*/
void reset_direction(void);

/**
*@brief motion set & reset
*/
void calc_motion_control_acc_set(float acc);
float get_acc(void);
void set_dance_interp_period(float num);
void calc_motion_control_r_turn_set(float r_turn);

/**
*@brief calc_motion_control_target_set
*input:
*output:if return -1 - input error, else return 1;
*/
int calc_motion_control_target_set(unsigned char type,bool new_cmd,
                                   float vel_forward,float w_rot,float pos_forward,float angle_rot);
/**
*@brief calc_motion_control_target_set
*input:
*output:if move finished ,return 1 , else return0;
*/
int calc_motion_control_res_get(float *left_val,float *right_val);
void change_vel_i_gain(float v_encoder_now,float *e ,bool is_on);

//--inner api functions : position control
/**
*@brief stop_cmd
*input:
*output:pos_now
*/
float clear_cmd(void);
/**
*@brief get_pos
*input:
*output:pos_now
*/
float get_pos(void);
/**
*@brief line_interp
*input: dis_d t_d
*output:if move finished ,return inner_param.end_flag=1  ; pwm1-right wheel  pwm2-left wheel
*/
int line_move(float dis_d,float t_d ,int *pwm1,int*pwm2);
/**
*@brief circle_interp
*input:dis_d t_d r_turn
*output:if move finished ,return inner_param.end_flag=1 ; pwm1-right wheel  pwm2-left wheel
*/
int circle_move(float dis_d,float t_d ,int *pwm1,int*pwm2);

void position_control(int *pwm1,int*pwm2);

//--inner api functions : velocity control
/**
*@brief  wheel_speed_control
*input:cmd_vel[2]--[right,left] wheel line speed,
*output:pwm1-right wheel ; pwm2-left wheel ,return 0;
*/
int wheel_speed_control(float cmd_vel_l,float cmd_vel_r,int *pwm1,int*pwm2);
/**
*@brief  car_speed_control
*input:cmd_vel-line speed of center point; cmd_w-rotate speed
*output:pwm1-right wheel ; pwm2-left wheel ,return 0;
*/
int car_speed_control (float cmd_vel,float cmd_w, float *pwm1,float *pwm2);
/**
*@brief  car_speed_control_with_imu
*input:cmd_vel-line speed of center point; cmd_w-rotate speed
*output:pwm1-right wheel ; pwm2-left wheel ,return 1-finished ,other 0;
*/
int  car_speed_control_with_imu(float cmd_vel,float cmd_w,float angle_d,int *pwm1,int*pwm2);
/**
*@brief dance motion
*input:
*output:-1 error, other 0
*/
void dance_interp(const float pos_forward,const float angle_rot);
int dance_control(float cmd_vel,float cmd_w, int *pwm1,int*pwm2);
float angle_pid_with_imu( float cmd_w );

//--inner function : car kinematic & motor control
float interp(float dis_d ,float t_d);
float interp_cubic(float dis_d ,float t_d);
float interp_when_endpos_change(float S,float E,float sV,float tf,float t);
float car_IK_line(float pos_d);
float *car_IK_circle(float angle_d);
void output_filter(float *encoder_vel_d);
void car_IK_to_encoder(float cmd_vel,float cmd_w,float *encoder_vel_d);
void cal_encoder_v(float cmd_vel,float cmd_w,float *encoder_vel_d);
float pid_motor(float yd, float dy,float ddy,float *y_integral,float integrate_limit,
                float p_forward,float p_gaid,float i_gaid,float d_gaid);
int pid_pos_right(float yd, float y);
int pid_pos_left (float yd, float y);
int pid_vel_right(float yd, float y);
int pid_vel_left (float yd, float y);
float integrate_change(float e,float integrate_a,float integrate_b);
float motor_friction(float dy,float u);
float angle_pid(float cmd_w_d,float dy,float f_gain ,float p_gain,float i_gain,float limit,float *integrate_error);
float car_rotate_pid(float cmd_w_d,float angle_d,int *ret);
float car_rotate_pid2(float cmd_w_d,float angle_d,int *ret);
//--other functions
float sign1(float x);
float limit(float in,float min,float max);
float get_fabs_min(float a,float b);
float get_fabs_max(float a,float b);
float low_filter(float klow_filter,float in);
float w_interp(float start_angle,float cmd_w_d,float angle_d);

void  cal_imu_yaw(void);
float imu_singularity(float imu_yaw,float imu_yaw_last);
bool  control_trigger(float angle_d,float dy);
void  acc_interp(float *encoder_vel_d);

#ifdef __cplusplus
}
#endif

#endif
