//#include "robot_control/WriteWords.h"
#include "robot_control/WritePaint.h"
#include <fstream>//txt write
#include "robot_control/MoveCmd.h"
extern Move cmd;

WritePaint::WritePaint()
{
    LogInit();
    m_arm=MotionCtrl::GetMotionCtrlPtr();
}
WritePaint::~WritePaint()
{
}
WritePaint* WritePaint::GetPtr()
{
    static WritePaint ptr;
    return &ptr;
}
//--write words application
void WritePaint::WriteInit()
{
    m_write.totalRow=0;

    m_write.isSwing=0;
    m_write.initiateCmd=0;
    m_write.count=0;
    m_write.step=0;
    m_write.planeInit<<0,0,0,0;
}
void WritePaint::ReadPoint()
{
    ifstream wordTxt("../../../../src/M2_small.txt");
    ifstream wordTxt2("../../../../src/M2_small.txt");

    char read;
    while (wordTxt.get(read))
    {
        if (read == '\n')
            m_write.totalRow++;
    }
    wordTxt.close();

    for (int i = 0; i <m_write.totalRow; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            wordTxt2>>m_write.wordPoint(i,j);
        }
    }
    m_write.wordPoint=m_write.wordPoint/1000;
    wordTxt2.close();
}
Vector3f WritePaint::WordsPointTrans(const Vector3f& in )
{
    Vector4f posWordInBase;
    posWordInBase<<in(0),in(1),in(2),1;

    Matrix4f T_words2plane;
    T_words2plane<<0,0,1,0,
            -1,0,0,0,
            0,-1,0,0,
            0,0,0,1;

    posWordInBase=m_write.T_plane2base*T_words2plane*posWordInBase;

    //--output
    Vector3f out;
    out<<posWordInBase(0),posWordInBase(1),posWordInBase(2);
    return out;
}
Vector3f WritePaint::PaintTrans(const Vector3f& in )
{
    Vector4f posWordInBase;
    posWordInBase<<in(0),in(1),in(2),1;

    Matrix4f T_words2plane;
    T_words2plane<<0,0,1,0,
            0,-1,0,0,
            1,0,0,0,
            0,0,0,1;

    posWordInBase=m_write.T_plane2base*T_words2plane*posWordInBase;

    //--output
    Vector3f out;
    out<<posWordInBase(0),posWordInBase(1),posWordInBase(2);
    return out;
}
bool isShowMarker;
void WritePaint::CalibPlane()
{
    if(cmd.planePoint==1 && m_write.planeInit(0)==false)//p1
    {
        WriteInit();
        PaintInit();

        cout<<"get p1"<<endl;
        m_write.planePoint.col(0)<<m_armFeedBack.toolPos(0),m_armFeedBack.toolPos(1),m_armFeedBack.toolPos(2);
        m_write.planeInit(0)=true;
    }
    if(cmd.planePoint==2 && m_write.planeInit(1)==false)//p2
    {
        cout<<"get p2"<<endl;
        m_write.planePoint.col(1)<<m_armFeedBack.toolPos(0),m_armFeedBack.toolPos(1),m_armFeedBack.toolPos(2);
        m_write.planeInit(1)=true;
    }
    if(cmd.planePoint==3 && m_write.planeInit(2)==false)//p3
    {
        cout<<"get p3"<<endl;
        m_write.planePoint.col(2)<<m_armFeedBack.toolPos(0),m_armFeedBack.toolPos(1),m_armFeedBack.toolPos(2);
        m_write.planeInit(2)=true;
    }
    if( (cmd.planePoint==4 || cmd.planePoint==5) && m_write.planeInit(3)==false)//p4 choose write or paint
    {
        cout<<"calibrate && start writing ..."<<endl;
        m_write.planeInit(3)=true;

        //--ref https://www.cnblogs.com/nobodyzhou/p/6145030.html
        m_write.offset<<m_armFeedBack.toolPos(0),m_armFeedBack.toolPos(1),m_armFeedBack.toolPos(2);
        Vector3f a1,a2,x,y,z,xRef,yRef,y1,oRef;
        a1=m_write.planePoint.col(1)-m_write.planePoint.col(2);
        a2=m_write.planePoint.col(0)-m_write.planePoint.col(2);
        x=a1.cross(a2);
        x=x.normalized();
        xRef<<1,0,0;
        if(x.dot(xRef)<0)
        {
            x=-x;
        }

        yRef<<0,1,0;
        float t=( x(0)*(m_write.planePoint(0,0)-yRef(0))+
                  x(1)*(m_write.planePoint(1,0)-yRef(1))+
                  x(2)*(m_write.planePoint(2,0)-yRef(2) ) )/
                (x(0)*x(0)+x(1)*x(1)+x(2)*x(2));
        y<<yRef(0)+x(0)*t,yRef(1)+x(1)*t,yRef(2)+x(2)*t;

        oRef<<0,0,0;
        t=( x(0)*(m_write.planePoint(0,0)-oRef(0))+
            x(1)*(m_write.planePoint(1,0)-oRef(1))+
            x(2)*(m_write.planePoint(2,0)-oRef(2) ) )/
                (x(0)*x(0)+x(1)*x(1)+x(2)*x(2));
        y1<<oRef(0)+x(0)*t,oRef(1)+x(1)*t,oRef(2)+x(2)*t;
        y=y-y1;
        //--x y z
        z=x.cross(y);
        x=x.normalized();y=y.normalized();z=z.normalized();

        m_write.T_plane2base<<x(0),y(0),z(0),m_write.offset(0),
                x(1),y(1),z(1),m_write.offset(1),
                x(2),y(2),z(2),m_write.offset(2),
                0,0,0,1;
    }
}
void WritePaint::WriteWords()
{
    bool isCalibFinished=m_write.planeInit(0)*m_write.planeInit(1)*m_write.planeInit(2)*m_write.planeInit(3);
    if(isCalibFinished==true)
    {
        Vector2f pointA,pointB;
        Vector6f goalPos;
        Vector3f posWord, rpy;//rpy in {tool}
        //    rpy<<0,0,0;
        rpy=m_armFeedBack.toolPos.block<3,1>(3,0);

        float swingHeight=0.015;
        //--initiate
        if(m_write.initiateCmd==0)//read point
        {
            ReadPoint();
            pointA<<m_write.wordPoint(m_write.count,0),m_write.wordPoint(m_write.count,1);
            m_write.pointBlast=pointA;
            m_write.initiateCmd=1;
        }
        if (m_write.initiateCmd==1)// move right above the first point
        {
            posWord<<m_write.wordPoint(m_write.count,0),m_write.wordPoint(m_write.count,1),0+0.03;
            posWord=WordsPointTrans(posWord);
            goalPos<<posWord,rpy;

            if(m_arm->MoveL(goalPos,2)==1)
            {
                m_write.initiateCmd=2;
            }
        }
        if (m_write.initiateCmd==2)// move down to touch the paper
        {
            posWord<<m_write.wordPoint(m_write.count,0),m_write.wordPoint(m_write.count,1),0;
            posWord=WordsPointTrans(posWord);
            goalPos<<posWord,rpy;

            if(m_arm->MoveL(goalPos,2)==1)
            {
                m_write.initiateCmd=3;
            }
        }
        if (m_write.initiateCmd==3)// start writing
        {
            //--get word point
            if(m_write.count<m_write.totalRow)
            {
                pointA<<m_write.wordPoint(m_write.count,0),m_write.wordPoint(m_write.count,1);
                pointB<<m_write.wordPoint(m_write.count,2),m_write.wordPoint(m_write.count,3);
            }
            else//finished
            {
                m_write.initiateCmd=4;
            }

            if(pointA(0)==m_write.pointBlast(0) && pointA(1)==m_write.pointBlast(1))
            {
                m_write.isSwing=false;
                isShowMarker=1;
            }
            else
            {
                m_write.isSwing=true;
                isShowMarker=0;
            }

            //--robot move
            if(m_write.isSwing==false)//swing or not
            {
                posWord<<pointB(0),pointB(1),0;
                posWord=WordsPointTrans(posWord);
                goalPos<<posWord,rpy;

                float dis=(pointB-pointA).norm();
                float totalTime=Limit(dis/0.03,0.2,2);
                if(m_arm->MoveL(goalPos,totalTime)==1)
                {
                    m_write.pointBlast=pointB;
                    m_write.count++;
                }
            }
            else
            {
                //--swing method 1
                //            Matrix3f swingTraj;
                //            swingTraj<<m_write.pointBlast(0),m_write.pointBlast(1),swingHeight,
                //                    pointA(0),pointA(1),swingHeight,
                //                    pointA(0),pointA(1),0;

                //            posWord=swingTraj.row(m_write.step);
                //            posWord=WordsPointTrans(posWord);
                //            goalPos<<posWord,rpy;

                //            if(MoveL(goalPos)==1)
                //            {
                //                m_write.step++;
                //                if(m_write.step>2) //reset
                //                {
                //                    m_write.isSwing=false;
                //                    m_write.step=0;
                //                    m_write.pointBlast=pointA;
                //                }
                //            }

                //--swing method 2
                Vector3f ps,pe,tmp1,tmp2;
                ps<<m_write.pointBlast(0),m_write.pointBlast(1),0;
                pe<<pointA(0),pointA(1),0;

                float dis=(pe-ps).norm();
                float totalTime=Limit(dis/0.02,0.8,2);

                tmp1=WordsPointTrans(ps);
                tmp2=WordsPointTrans(pe);
                ps<<tmp1(1),tmp1(2),tmp1(0);//y,z,x
                pe<<tmp2(1),tmp2(2),tmp2(0);

                if(m_arm->Swing(ps,pe,swingHeight,totalTime)==1)
                {
                    m_write.isSwing=false;
                    m_write.pointBlast=pointA;
                }
            }
        }
        if (m_write.initiateCmd==4)// stop writing
        {
            posWord<<m_write.wordPoint(m_write.count-1,2),m_write.wordPoint(m_write.count-1,3),0+0.03;
            posWord=WordsPointTrans(posWord);
            goalPos<<posWord,rpy;
            if(m_arm->MoveL(goalPos,2)==1)
            {
                cmd.mode=STOP;

                m_write.totalRow=0;  //reset
                m_write.isSwing=0;
                m_write.initiateCmd=0;
                m_write.count=0;
                m_write.step=0;
                m_write.planeInit(3)=0;
            }
            isShowMarker=0;
        }
    }
}
void WritePaint::PaintInit()
{
    string path="../../../../src/trajs.txt";
    m_paint.path=path;

    m_paint.dataRows=0;
    m_paint.count=0;
    m_paint.paintStep=0;
    m_paint.posLast<<0,0,0;
    m_paint.isSwing=0;
}

int WritePaint::GetDataRows(string path)
{
    char read;
    int rows=0;
    ifstream txt(&path[0]);
    while (txt.get(read))
    {
        if (read == '\n')
            rows++;
    }
    txt.close();
    cout<<"dataRows:"<<rows<<endl;
    return rows;
}
Vector3f WritePaint::ReadPaintPoint()
{
    Vector2f pos;
    static Vector3f posWord;
    float scale=1000.0f*3.5;
    static ifstream posTxt(&m_paint.path[0]);
    m_paint.count++;
    if(m_paint.count>m_paint.dataRows)
    {
        posTxt.close();
        posTxt.open(&m_paint.path[0],ios_base::in);//reopen to start at head
    }
    else
    {
        for (int j = 0; j < 2; j++)
        {
            posTxt>>pos(j,0);
        }
        if(pos(0)==666 && pos(1)==666)
        {
            m_paint.isSwing=true;
            m_paint.count++;
            for (int j = 0; j < 2; j++)
            {
                posTxt>>pos(j,0);
            }
            cout<<"swing..."<<endl;
        }
        cout<<"pos:"<<pos.transpose()<<endl;
        posWord<<-pos(0)/scale,pos(1)/scale,0;
        posWord=PaintTrans(posWord);
        //    cout<<"pos:"<<posWord.transpose()<<endl;
    }
    return posWord;
}
void WritePaint::Paint()
{
    bool isCalibFinished=m_write.planeInit(0)*m_write.planeInit(1)*m_write.planeInit(2)*m_write.planeInit(3);
    if(isCalibFinished==true)
    {
        static Vector3f posWord,rpy;
        static Vector6f goalPos;
        rpy=m_armFeedBack.toolPos.block<3,1>(3,0);
        float swingHeight=0.015;

        if(m_paint.paintStep==0)//get data rows
        {
            m_paint.dataRows=GetDataRows(m_paint.path);
            m_paint.paintStep=1;
        }
        if(m_paint.paintStep==1)//paint
        {
            if(m_paint.isSwing==false)
            {
                posWord=ReadPaintPoint();
                goalPos<<posWord,rpy;
                m_paint.posLast=m_armFeedBack.toolPos.block<3,1>(0,0);
            }
            if (m_paint.isSwing)
            {
                //                cout<<"swing"<<endl;
                Vector3f ps,pe;
                ps<<m_paint.posLast(1),m_paint.posLast(2),m_paint.posLast(0);
                pe<<posWord(1),posWord(2),posWord(0);

                float dis=(pe-ps).norm();
                float totalTime=Limit(dis/0.02,0.8,2);
                //                totalTime=0.5;//debug
                //                cmd.speed=4;//debug

                if(m_arm->Swing(ps,pe,swingHeight,totalTime)==1)
                {
                    m_paint.isSwing=false;
                }
            }
            else
            {
                m_arm->MovePoint(goalPos);
            }

            if(m_paint.count>m_paint.dataRows)
            {
                m_paint.paintStep=2;
            }
        }
        if(m_paint.paintStep==2)// stop writing
        {
            goalPos(0)=m_paint.posLast(0)+0.05;
            if(m_arm->MoveL(goalPos,2)==1)
            {
                cmd.mode=STOP;

                m_paint.dataRows=0; //reset
                m_paint.count=0;
                m_paint.paintStep=0;
                m_paint.posLast<<0,0,0;
                m_paint.isSwing=0;
                m_write.planeInit(3)=0;
            }
        }
    }
}
void WritePaint::TrajMove()
{
    //--get arm state
    m_armFeedBack=m_arm->ReadArmState();
    //--app WriteWords & Paint
    bool isCalibFinished=m_write.planeInit(0)*m_write.planeInit(1)*m_write.planeInit(2)*m_write.planeInit(3);
    if(isCalibFinished==false)
    {
        CalibPlane();
    }
    if (cmd.planePoint==4)
    {
        WriteWords();
    }
    if (cmd.planePoint==5)
    {
        Paint();
    }
}

//--copy move application
void WritePaint::LogInit()
{
    cmd.planePoint=0;
    cmd.log=0;

    //string tmp="/home/hd/robot_arm2/robot_arm_server/src/jointpos2.txt";
    string path="/home/pi/robot_arm/src2/jointposPi.txt";
    //memcpy(&m_copyMove.path[0],&tmp[0],sizeof(tmp)); //error
    m_copyMove.path=path;
    m_copyMove.num<<0,0;
    m_copyMove.logMoveState=0;
    m_copyMove.cmdHandLast=0;
    m_copyMove.logPos<<0,0,0,0,0,0;

}
int WritePaint::CopyMove(int logCmd,int handCmd,Vector6f &realJointPos,
                         int *handMove )
{
    if(logCmd==0 )//stop
    {
    }
    else if(logCmd==1)//log pos
    {
        ofstream jointPos(m_copyMove.path,ios::app);
        if(jointPos.fail())
        {
            cout<<"write txt open failed"<<endl;
        }
        if( (handCmd==1 || handCmd==2) && handCmd!=m_copyMove.cmdHandLast)
        {
            cout<<"hand operate:"<<handCmd<<endl;
            jointPos<<handCmd<<" "<<
                      realJointPos(0)<<" "<<
                      realJointPos(1)<<" "<<
                      realJointPos(2)<<" "<<
                      realJointPos(3)<<" "<<
                      realJointPos(4)<<" "<<
                      realJointPos(5)<<endl;
            m_copyMove.cmdHandLast=handCmd;
        }
        if(handCmd==0)
        {
            jointPos<<handCmd<<" "<<
                      realJointPos(0)<<" "<<
                      realJointPos(1)<<" "<<
                      realJointPos(2)<<" "<<
                      realJointPos(3)<<" "<<
                      realJointPos(4)<<" "<<
                      realJointPos(5)<<endl;
        }
    }
    else if(logCmd==2)//output pos
    {
        cmd.mode=COPY_MOVE;
        if(m_copyMove.logMoveState==0 )
        {
            LogInit();
            m_copyMove.logMoveState=1;
        }
        if (m_copyMove.logMoveState==1 ) //load txt
        {
            ifstream wordTxt(m_copyMove.path);
            char read;
            while (wordTxt.get(read))
            {
                if (read == '\n')
                    m_copyMove.num[0]++;
            }
            wordTxt.close();
            m_copyMove.logMoveState=2;
            cout<<"txt load finished:"<<m_copyMove.num[0]<<endl;
        }
        else if (m_copyMove.logMoveState==2)//get first point
        {
            LogOutput(&m_copyMove.logPos,handMove);
            m_copyMove.logMoveState=3;

        }
        else if (m_copyMove.logMoveState==3)//move to first point
        {
            if(m_arm->MoveToJointPos(m_copyMove.logPos,1)==1)
            {
                m_copyMove.logMoveState=4;
                cout<<"\n"<<"arrived at the first point !!!"<<endl;
                cout<<"start moving ...  "<<endl;
            }
        }
        else if (m_copyMove.logMoveState==4) //copy move
        {
            Vector6f goalJointPos;
            if(LogOutput(&goalJointPos,handMove)==1)
            {
                m_copyMove.logMoveState==5;

                cmd.mode=STOP;
                cmd.log=0;
                LogInit();

                cout<<"\n"<<"output finished !!!"<<endl;
            }
            m_arm->SetJointPos(goalJointPos);
        }
        else
        {
            //do nothing
        }
    }
    else if(logCmd==3)//delete txt
    {
        LogInit();
        cmd.log=0;
        ofstream clearTxt(m_copyMove.path);
        cout<<"\n"<<"clear finished !!!"<<endl;
    }
    else
    {
        //do nothing
    }
}
#include <stdio.h>
#include <iomanip>
bool WritePaint::LogOutput(Vector6f *goalPos,int *handMove)
{
    //    m_copyMove.num[0]=1000;
    static ifstream posTxt(&m_copyMove.path[0]);
    //    static ifstream posTxt("/home/hd/robot_arm2/robot_arm_server/src/jointpos.txt");
    //    char *tmp="/home/hd/robot_arm2/robot_arm_server/src/jointpos.txt";
    //    static ifstream posTxt(tmp);
    //    cout<<m_copyMove.path.c_str()<<endl;

    for (int i = 0; i < 7; i++)
    {
        if(i==0)
        {
            posTxt>> *handMove;
        }
        else
        {
            posTxt>>goalPos->coeffRef(i-1,0);
        }
    }

    std::fflush (stdout);
    cout<<"\r";
    //    cout.width(5);
    cout<<setprecision(3)<<int(100.0*m_copyMove.num[1]/(m_copyMove.num[0]+1))
            <<"%"<<" : "<<*handMove<<" , "<<goalPos->col(0).transpose() ;
    m_copyMove.num[1]++;
    if(m_copyMove.num[1]>=m_copyMove.num[0]) //finished
    {
        posTxt.close();
        posTxt.open(&m_copyMove.path[0],ios_base::in);//reopen to start at head
        m_copyMove.num[1]=0;
        return 1;
    }
    return 0;
}

//--imu motion capture application
Vector6f ImuLowFilter(int state,float kLowFilter,const Vector6f in)
{
    Vector6f out;
    static Vector6f last;
    if(state==0)
    {
        last<<0,0,0,0,0,0;
    }
    out = kLowFilter* in + (1.0F - kLowFilter) * last;
    last= out;
    return out;
}
Vector3f WritePaint::CalImuMotion(Matrix3f& R_body2w,Matrix3f& Rs_body
                                  ,Matrix3f& R_upperArm2w,Matrix3f& Rs_upperArm)
{
    Matrix3f R_upperArm2body;
    Vector3f rpy;
    R_upperArm2body=Rs_body*R_body2w.transpose()*R_upperArm2w;
    rpy=rot2rpy(R_upperArm2body)-rot2rpy(Rs_upperArm);

    //--pose inverse
    Matrix3f R,R2,Rtmp;
    R2<<0,1,0,
            0,0,1,
            1,0,0;

    Rtmp=AngleAxisf(rpy[2], Vector3f::UnitY())
            * AngleAxisf(rpy[1], Vector3f::UnitX())
            * AngleAxisf(rpy[0], Vector3f::UnitZ());
    R=R2*Rtmp;
    float t1,t2,t3;
    t1=atan2( R(1,1),R(0,1) ) ;
    t3=atan2( R(2,2),R(2,0) ) ;
    // t2=-acos( -R(2,1) )+pi/2;
    if(fabs(cos(t3))>0.01)
    {
        t2=atan2( R(2,0)/cos(t3), R(2,1) )-pi/2;  //? why -pi/2
    }
    else
    {
        t2=atan2( R(2,2)/sin(t3), R(2,1) )-pi/2;
    }

    //--output
    Vector3f out;
    out<<t1,t2,t3;
    return out;
}
void WritePaint::FollowMove(int state,Vector3f& imu1,Vector3f& imu2,Vector3f& imu3,Vector3f& imu4)
{
    Matrix3f R_body2w,R_upperArm2w,R_lowerArm2w,R_wrist2w;
    static Vector4f yawOffset;
    static Matrix3f Rs_body,Rs_upperArm,Rs_lowerArm,Rs_wrist;

    static int count=0,state2=0;
    if(state==0)//reset
    {
        count=0;
        state2=0;
        Vector6f tmp;
        ImuLowFilter(state,0.01,tmp);
    }
    else       //run
    {
        count++;
        if(count%100==0)
        {
            state2++;
            if(state2>=3)
            {
                state2=3;
                count=0;
            }
        }
        state=state2;
    }


    if (state==1)
    {
        yawOffset(0)=imu1(2);
        yawOffset(1)=imu2(2);
        yawOffset(2)=imu3(2);
        yawOffset(3)=imu4(2);
    }

    imu1(2)-=yawOffset(0);
    imu2(2)-=yawOffset(1);
    imu3(2)-=yawOffset(2);
    imu4(2)-=yawOffset(3);

    R_body2w=rpy2rot(imu1);
    R_upperArm2w=rpy2rot(imu2);
    R_lowerArm2w=rpy2rot(imu3);
    R_wrist2w=rpy2rot(imu4);

    if (state==2)
    {
        Rs_body=R_body2w;
        Rs_upperArm=R_upperArm2w;
        Rs_lowerArm=R_lowerArm2w;
        Rs_wrist=R_wrist2w;
    }
    if (state==3)
    {
        Vector3f out1,out2,out3;
        out1=CalImuMotion(R_body2w,Rs_body,R_upperArm2w,Rs_upperArm);
        out2=CalImuMotion(R_upperArm2w,Rs_upperArm,R_lowerArm2w,Rs_lowerArm);
        out3=CalImuMotion(R_lowerArm2w,Rs_lowerArm,R_wrist2w,Rs_wrist);
        Vector6f goalJointPos;
        goalJointPos<<out1(0),out1(1),out1(2)+pi/2,out2(0),out3(2)-pi/2,out3(1);
        goalJointPos=ImuLowFilter(state,0.1,goalJointPos);
        //        cout<<out1(0)<<","<<out1(1)<<","<<out1(2)+pi/8<<","<<out2(0)<<","<<out3(2)<<","<<out3(1)<<endl;
        //               m_armInput.jointPos<<out1(0),out1(1),out1(2),0,0,0;  // joint 1 2 3
        //               m_armInput.jointPos<<0,0,0,out1(2),0,0;          // joint 4
        //               m_armInput.jointPos<<0,0,0,0,-out1(0),out1(1);       // joint 5 6
        m_arm->JointLimit(0,goalJointPos);
        m_arm->SetJointPos(goalJointPos);
    }
}
void WritePaint::FollowMove2(int state,Vector3f& imu1,Vector3f& imu2,Vector3f& imu3,Vector3f& imu4)
{
    Matrix3f R_body2w,R_upperArm2w,R_lowerArm2w,R_wrist2w;
    static Vector4f yawOffset;
    static Matrix3f Rs_body,Rs_upperArm,Rs_lowerArm,Rs_wrist;

    static int count=0,state2=0;
    count++;
    if(count%100==0)
    {
        state2++;
        if(state2>=3)
        {
            state2=3;
        }
    }
    state=state2;

    if (state==1)
    {
        yawOffset(0)=imu1(2);
        yawOffset(1)=imu2(2);
        yawOffset(2)=imu3(2);
        yawOffset(3)=imu4(2);
    }

    imu1(2)-=yawOffset(0);
    imu2(2)-=yawOffset(1);
    imu3(2)-=yawOffset(2);
    imu4(2)-=yawOffset(3);

    R_body2w=rpy2rot(imu1);
    R_upperArm2w=rpy2rot(imu2);
    R_lowerArm2w=rpy2rot(imu3);
    R_wrist2w=rpy2rot(imu4);

    if (state==2)
    {
        Rs_body=R_body2w;
        Rs_upperArm=R_upperArm2w;
        Rs_lowerArm=R_lowerArm2w;
        Rs_wrist=R_wrist2w;
    }
    if (state==3)
    {
        armParam m_armParam;
        m_armParam=m_arm->ReadArmParam();
        Matrix3f R_2_1,R_3_2,R_4_3,R_5_4;
        Matrix3f R_1_w,R_2_w,R_3_w,R_4_w;
        Matrix4f T_1_w,T_2_1,T_3_2,T_4_3,T_5_4;
        Matrix4f T1,T2,T3,T4,T5;
        Vector3f pos;
        float l1,l2,l3,l4;
        l1=0.1;
        l2=m_armParam.d4;
        l3=m_armParam.d2;
        l4=m_armParam.xTool;
        //--R
        R_1_w=R_body2w*Rs_body.transpose();
        R_2_w=R_upperArm2w*Rs_upperArm.transpose();
        R_3_w=R_lowerArm2w*Rs_lowerArm.transpose();
        R_4_w=R_wrist2w*Rs_wrist.transpose();

        R_2_1=R_1_w.transpose()*R_2_w;
        R_3_2=R_2_w.transpose()*R_3_w;
        R_4_3=R_3_w.transpose()*R_4_w;
        R_5_4<<1,0,0,
                0,1,0,
                0,0,1;
        //--T
        pos<<0,0,0;
        T_1_w<<R_1_w,
                pos,
                (RowVector4f()<<0, 0, 0, 1).finished();
        pos<<0,l1,0;
        T_2_1<<R_2_1,
                pos,
                (RowVector4f()<<0, 0, 0, 1).finished();
        pos<<0,0,-l2;
        T_3_2<<R_3_2,
                pos,
                (RowVector4f()<<0, 0, 0, 1).finished();
        pos<<0,0,-l3;
        T_4_3<<R_4_3,
                pos,
                (RowVector4f()<<0, 0, 0, 1).finished();
        pos<<0,0,-l4;
        T_5_4<<R_5_4,
                pos,
                (RowVector4f()<<0, 0, 0, 1).finished();

        T1=T_1_w;
        T2=T1*T_2_1;
        T3=T2*T_3_2;
        T4=T3*T_4_3;
        T5=T4*T_5_4;
        //--P in {world}
        Vector3f p1,p2,p3,p4,p5,p0;
        p0<<0,0,-0.1;
        p1=T1.block<3,1>(0,3);
        p2=T2.block<3,1>(0,3);
        p3=T3.block<3,1>(0,3);
        p4=T4.block<3,1>(0,3);
        p5=T5.block<3,1>(0,3);

        //--method1 IK
        Matrix4f Trans,Trans2,Ttool;
        Trans<<0,0,1,0,
                1,0,0,0,
                0,1,0,-l1,
                0,0,0,1;
        Trans2<<0,1,0,0,
                0,0,1,0,
                1,0,0,0,
                0,0,0,1;
        Ttool=Trans*T5*Trans2.inverse();
        Ttool<<0,1,0,p5(2),
                0,0,1,p5(0),
                1,0,0,p5(1),
                0,0,0,1;
        Vector3f rpy;
        plot3(p5(2),p5(0),p5(1));
        //         cout<<p5(2) <<","<<p5(0)<<","<<p5(1)<<endl;
        Vector6f goalJointPos;
        m_arm->ArmIK(Ttool,&goalJointPos);
        m_arm->SetJointPos(goalJointPos);
        //--method2
        Vector3f v0,v1,v2,v3,v4,v01;
        v0=p0-p1;
        v1=p2-p1;
        v2=p3-p2;
        v3=p4-p3;
        v4=p5-p4;
        v0=v0.normalized();
        v1=v1.normalized();
        v2=v2.normalized();
        v3=v3.normalized();
        v4=v4.normalized();

        v01=v0.cross(v1);
        float t1,t2,t3,t4,t5,t6;
        float a,b,c;
        a=v2.dot(v0);
        b=v2.dot(v1);
        c=v2.dot(v01);
        t2=atan2(b,a);
        t1=-atan2(c,a);

        t4=-acos(v2.dot(v3));
        t6=-acos(v3.dot(v4));

        Vector3f v02,vn1,vn2;
        v02=a*v0+b*v1;
        vn1=v01.cross(v02);
        vn1=vn1.normalized();
        vn2=v3.cross(v2);
        vn2=vn2.normalized();
        t3=acos(vn1.dot(vn2));

        goalJointPos<<t1,t2,t3,t4,0,t6;
        m_arm->SetJointPos(goalJointPos);
    }
}

