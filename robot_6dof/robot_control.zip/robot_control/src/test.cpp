#include "robot_control/MotionCtrl.h"

#include <fstream>//write
extern armMove cmd;
extern armPosInfo dataShow;

void BottleCatchTrajGen()
{
    Matrix3f R0;
    R0<<0,1,0,
            0,0,1,
            1,0,0;

    float dirS=10*pi/180;
    float dirE=80*pi/180;  // 40-80 ok
    float R=0.35;
    float h=-0.514;

    //--test
    static bool isFirst=1;
    if(isFirst)
    {
        isFirst=0;

        Vector3f startPos,midPos,endPos;
        Vector3f rpyStart,rpyMid,rpyEnd,rpyN,axis;
        Matrix3f poseEnd,poseN;
        float height=0.172;
        startPos<<-514.171, 315.287, -47.7198;
        startPos=startPos/1000;
        endPos<<-342.51, 354.449, 234.241;
        endPos=endPos/1000;

        startPos<<h,R*cos(dirS),R*sin(dirS);
        endPos  <<h,R*cos(dirE),R*sin(dirE);
        //--s, m, e point calculate
        endPos(0)=startPos(0)+height;
        midPos=(startPos+endPos)/2;

        float thetaStart=atan2(startPos(2),startPos(1));
        float thetaAxis=atan2(endPos(2),endPos(1)) ;
        float thetaEnd=atan2(endPos(2),endPos(1)) ;
        float thetaMid=(thetaStart+thetaAxis)/2;
        float thetaOffset=6*pi/180;
        if(thetaEnd<=pi/2)
        {
            thetaOffset=thetaEnd/(pi/2)*-5*pi/180;
            thetaOffset=-6*pi/180;
        }
        thetaOffset=0;

        float radius=sqrt(endPos(1)*endPos(1)+endPos(2)*endPos(2));
        midPos(1)=radius*cos(thetaMid);
        midPos(2)=radius*sin(thetaMid);

        rpyStart<<-90*pi/180+thetaStart,0,90*pi/180;
        rpyEnd  <<-90*pi/180+thetaEnd,thetaOffset,90*pi/180;
        rpyMid=(rpyStart+rpyEnd)/2;

        poseEnd=R0*rpy2rot(rpyEnd);
        Vector3f tmpY,tmpRpy;
        tmpRpy<<thetaEnd,0,4*pi/180 ;
        tmpY<<0,1,0;
        axis=rpy2rot(tmpRpy)*tmpY;
        axis=-poseEnd*tmpY;
        //        axis<<0,cos(thetaAxis),sin(thetaAxis);

        //--route traj
        Matrix<float,7,11> routeN;
        routeN.col(0)<<LINE_NODE,startPos(0)+0.05,startPos(1)-0.15,startPos(2),
                rpyStart(0),rpyStart(1),rpyStart(2);
        routeN.col(1)<<LINE_NODE,startPos(0),startPos(1) ,startPos(2),
                rpyStart(0),rpyStart(1),rpyStart(2);
        routeN.col(2)<<WAIT_NODE, 1, 0, 0, 0, 0, 0;
        //-S
        routeN.col(3)<<S_NODE,midPos(0),midPos(1) ,midPos(2),
                rpyMid(0),rpyMid(1),rpyMid(2);
        routeN.col(4)<<S_NODE,endPos(0),endPos(1) ,endPos(2),
                rpyEnd(0),rpyEnd(1),rpyEnd(2);

        routeN.col(5)<<J_NODE,endPos(0),endPos(1) ,endPos(2),
                0,100*pi/180,0;
        routeN.col(6)<<J_NODE,endPos(0),endPos(1) ,endPos(2),
                0,-60*pi/180,0;
        //        for (int i=0;i<5;i++)
        //        {
        //            poseN=rotK(axis,-i*25*pi/180)*poseEnd;

        //            Vector3f rot;
        //            rot<<0*pi/180,i*25*pi/180,0*pi/180;
        //            poseN=poseEnd*rpy2rot(rot);

        //            rpyN=rot2rpy(R0.transpose()*poseN);
        //            cout<<rpyN.transpose()/pi*180<<endl;
        //            if(i==0)
        //            {
        //                routeN.col(3+1+i)<<S_NODE,endPos(0),endPos(1) ,endPos(2),
        //                        rpyN(0),rpyN(1),rpyN(2);
        //            }
        //            else
        //            {
        //                routeN.col(3+1+i)<<J_NODE,endPos(0),endPos(1) ,endPos(2),
        //                        rpyN(0),rpyN(1),rpyN(2);
        //            }
        //        }

        routeN.col(7)=routeN.col(3);
        routeN.col(8)=routeN.col(1);routeN(0,8)=S_NODE;
        //-
        routeN.col(9)<<WAIT_NODE, 0, 0, 0, 0, 0, 0;
        routeN.col(10)=routeN.col(0);

        //--convert to mm & degree
        for (int i=0;i<11;i++)
        {
            routeN(1,i)=routeN(1,i)*1000;
            routeN(2,i)=routeN(2,i)*1000;
            routeN(3,i)=routeN(3,i)*1000;
            routeN(4,i)=routeN(4,i)/pi*180;
            routeN(5,i)=routeN(5,i)/pi*180;
            routeN(6,i)=routeN(6,i)/pi*180;
        }
        //--copy to cmd
        cmd.route.clear();
        for (int i=0;i<11;i++)
        {
            ROUTE_NODE route;
            if(routeN(0,i)==0)
            {
                route.nodeType=LINE_NODE;
            }
            if(routeN(0,i)==1)
            {
                route.nodeType=WAIT_NODE;
            }
            if(routeN(0,i)==2)
            {
                route.nodeType=CIRCLE_NODE;
            }
            if(routeN(0,i)==3)
            {
                route.nodeType=S_NODE;
            }
            route.xPos=routeN(1,i);
            route.yPos=routeN(2,i);
            route.zPos=routeN(3,i);
            route.rxPos=routeN(4,i);
            route.ryPos=routeN(5,i);
            route.rzPos=routeN(6,i);
            cmd.route.push_back(route);

            cout<<i<<", "<<routeN(0,i)<<", "<<routeN(1,i)<<", "<<routeN(2,i)
               <<", "<<routeN(3,i)<<", "<<routeN(4,i)<<", "<<routeN(5,i)
              <<", "<<routeN(6,i) <<endl;
        }

    }
    //    ControlLoop();
}
//--test
#include "stdlib.h"
#include "time.h"

int main_( )
{ 
    while(1)
    {

        usleep(1000*10);
    }
    return 0;
}

