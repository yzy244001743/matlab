#include "robot_control/ArmBasics.h"

Matrix<float,6,5> ArmBasics::Jacobian0(Vector6f &t)
{
    float a1=m_armParam.dhParam(0);
    float a2=m_armParam.dhParam(1);
    float a3=m_armParam.dhParam(2);
    float a4=m_armParam.dhParam(3);
    float t1,t2,t3,t4,t5;
    t1=t(0);
    t2=t(1);
    t3=t(2);
    t4=t(3);
    t5=t(4);

    Matrix<float,6,5> J0;
    J0<<0, cos(t2 + t3 + t4)*(a3 + a1*cos(t3 + t4) + a2*cos(t4) + a4*cos(t5)) + sin(t2 + t3 + t4)*cos(t5)*cos(t5)*(a1*sin(t3 + t4) + a2*sin(t4)) + sin(t2 + t3 + t4)*sin(t5)*sin(t5)*(a1*sin(t3 + t4) + a2*sin(t4)), cos(t2 + t3 + t4)*(a3 + a2*cos(t4) + a4*cos(t5)) + a2*sin(t2 + t3 + t4)*cos(t5)*cos(t5)*sin(t4) + a2*sin(t2 + t3 + t4)*sin(t4)*sin(t5)*sin(t5), cos(t2 + t3 + t4)*(a3 + a4*cos(t5)), -a4*sin(t2 + t3 + t4)*sin(t5),
            0, sin(t2 + t3 + t4)*(a3 + a1*cos(t3 + t4) + a2*cos(t4) + a4*cos(t5)) - cos(t2 + t3 + t4)*cos(t5)*cos(t5)*(a1*sin(t3 + t4) + a2*sin(t4)) - cos(t2 + t3 + t4)*sin(t5)*sin(t5)*(a1*sin(t3 + t4) + a2*sin(t4)), sin(t2 + t3 + t4)*(a3 + a2*cos(t4) + a4*cos(t5)) - a2*cos(t2 + t3 + t4)*sin(t4)*sin(t5)*sin(t5) - a2*cos(t2 + t3 + t4)*cos(t5)*cos(t5)*sin(t4), sin(t2 + t3 + t4)*(a3 + a4*cos(t5)),  a4*cos(t2 + t3 + t4)*sin(t5),
            1,                                                                                                                                                                          0,                                                                                                                                  0,                                   0,                   -a4*cos(t5),
            0,                                                                                                                                                                                            0,                                                                                                                                  0,                                   0,             cos(t2 + t3 + t4),
            0,                                                                                                                                                                                            0,                                                                                                                                  0,                                   0,             sin(t2 + t3 + t4),
            0,                                                                                                                                                                        1,                                                                                                              1,               1,                             0;

    return J0;
}
void ArmBasics::Ctq(Vector6f &q,Vector6f &qd,Vector6f* Ct)
{
    float c1,c2,c3,c4,c5,c6,s1,s2,s3,s4,s5,s6;
    float t1,t2,t3,t4,t5,t6,dt1,dt2,dt3,dt4,dt5,dt6;
    float m1=m_armParam.mass(0);
    float m2=m_armParam.mass(1);
    float m3=m_armParam.mass(2);
    float m4=m_armParam.mass(3);
    float m5=m_armParam.mass(4);
    float m6=m_armParam.mass(5);

    float a1=m_armParam.dhParam(0);
    float a2=m_armParam.dhParam(1);
    float a3=m_armParam.dhParam(2);
    float a4=m_armParam.dhParam(3);

    Vector6f qZero;
    qZero<<0,pi/2,0,0,0,0;//MDH offset
    t1=q(0);
    t2=q(1)+qZero(1);
    t3=q(2);
    t4=q(3);
    t5=q(4);
    t6=q(5);

    dt1=qd(0);
    dt2=qd(1);
    dt3=qd(2);
    dt4=qd(3);
    dt5=qd(4);
    dt6=qd(5);

    s1=sin(t1);
    s2=sin(t2);
    s3=sin(t3);
    s4=sin(t4);
    s5=sin(t5);
    s6=sin(t6);

    c1=cos(t1);
    c2=cos(t2);
    c3=cos(t3);
    c4=cos(t4);
    c5=cos(t5);
    c6=cos(t6);

    Vector6f alpha;
    //--alpha
    alpha(0)=0.0;
    alpha(1)=0.0;
    alpha(2)=- 0.147*a1*dt2*dt2*m3*sin(t2)*(t2)*sin(t3) - 0.147*a1*dt2*dt3*m3*cos(t2)*(t2)*sin(t3) - 0.147*a1*dt2*dt3*m3*sin(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt2*m3*cos(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt2*m4*cos(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt2*m5*cos(t2)*(t2)*sin(t3)
    - 1.0*a1*a2*dt2*dt2*m3*sin(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt2*m4*sin(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt2*m5*sin(t2)*(t2)*sin(t3) - 0.147*a1*dt2*dt2*m3*cos(t2)*(t2)*sin(t3)
    - 0.126*a1*dt2*dt2*m4*cos(t2)*(t2)*cos(t3)*sin(t4) - 0.126*a1*dt2*dt2*m4*cos(t2)*(t2)*cos(t4)*sin(t3) - 0.126*a1*dt2*dt2*m4*cos(t3)*sin(t2)*(t2)*sin(t4) - 0.126*a1*dt2*dt2*m4*cos(t4)*sin(t2)*(t2)*sin(t3)
    - 1.0*a1*a3*dt2*dt2*m4*cos(t2)*(t2)*cos(t3)*sin(t4) - 1.0*a1*a3*dt2*dt2*m4*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*sin(t4)
    - 1.0*a1*a3*dt2*dt2*m5*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt2*m4*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt2*m4*cos(t4)*sin(t2)*(t2)*sin(t3)
    - 1.0*a1*a3*dt2*dt2*m5*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt2*m5*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt3*m3*cos(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt3*m4*cos(t2)*(t2)*sin(t3)
    - 1.0*a1*a2*dt2*dt3*m5*cos(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt3*m3*sin(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt3*m4*sin(t2)*(t2)*sin(t3) - 1.0*a1*a2*dt2*dt3*m5*sin(t2)*(t2)*sin(t3) - 0.126*a1*dt2*dt3*m4*cos(t2)*(t2)*cos(t3)*sin(t4)
    - 0.126*a1*dt2*dt3*m4*cos(t2)*(t2)*cos(t4)*sin(t3) - 0.126*a1*dt2*dt4*m4*cos(t2)*(t2)*cos(t3)*sin(t4) - 0.126*a1*dt2*dt4*m4*cos(t2)*(t2)*cos(t4)*sin(t3) - 0.126*a1*dt2*dt3*m4*cos(t3)*sin(t2)*(t2)*sin(t4)
    - 0.126*a1*dt2*dt3*m4*cos(t4)*sin(t2)*(t2)*sin(t3) - 0.126*a1*dt2*dt4*m4*cos(t3)*sin(t2)*(t2)*sin(t4) - 0.126*a1*dt2*dt4*m4*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*cos(t5)*sin(t4)
    - 1.0*a1*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t4)*cos(t5)*sin(t3) - 1.0*a1*a4*dt2*dt2*m5*cos(t3)*cos(t5)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a4*dt2*dt2*m5*cos(t4)*cos(t5)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a3*dt2*dt3*m4*cos(t2)*(t2)*cos(t3)*sin(t4)
    - 1.0*a1*a3*dt2*dt3*m4*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*sin(t4) - 1.0*a1*a3*dt2*dt3*m5*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt4*m4*cos(t2)*(t2)*cos(t3)*sin(t4)
    - 1.0*a1*a3*dt2*dt4*m4*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*sin(t4) - 1.0*a1*a3*dt2*dt4*m5*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt3*m4*cos(t3)*sin(t2)*(t2)*sin(t4)
    - 1.0*a1*a3*dt2*dt3*m4*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a3*dt2*dt3*m5*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt3*m5*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a3*dt2*dt4*m4*cos(t3)*sin(t2)*(t2)*sin(t4)
    - 1.0*a1*a3*dt2*dt4*m4*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a3*dt2*dt4*m5*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt4*m5*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*cos(t5)*sin(t4)
    - 1.0*a1*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t4)*cos(t5)*sin(t3) - 1.0*a1*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*cos(t5)*sin(t4) - 1.0*a1*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t4)*cos(t5)*sin(t3) - 1.0*a1*a4*dt2*dt5*m5*cos(t2)*(t2)*cos(t3)*cos(t4)*sin(t5)
    - 1.0*a1*a4*dt2*dt3*m5*cos(t3)*cos(t5)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a4*dt2*dt3*m5*cos(t4)*cos(t5)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a4*dt2*dt4*m5*cos(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)
    - 1.0*a1*a4*dt2*dt4*m5*cos(t4)*cos(t5)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a4*dt2*dt5*m5*cos(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) + a1*a4*dt2*dt5*m5*cos(t2)*(t2)*sin(t3)*sin(t4)*sin(t5) + a1*a4*dt2*dt5*m5*sin(t2)*(t2)*sin(t3)*sin(t4)*sin(t5)
    ;
    alpha(3)=- 0.126*a2*dt2*dt2*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 0.126*a2*dt3*dt3*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 0.126*a2*dt2*dt2*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 0.126*a2*dt2*dt2*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 0.126*a2*dt3*dt3*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 0.126*a2*dt3*dt3*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)
    - 0.126*a2*dt2*dt2*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 0.126*a2*dt3*dt3*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 0.126*a1*dt2*dt2*m4*cos(t2)*(t2)*cos(t3)*sin(t4) - 0.126*a1*dt2*dt2*m4*cos(t2)*(t2)*cos(t4)*sin(t3)
    - 0.126*a1*dt2*dt2*m4*cos(t3)*sin(t2)*(t2)*sin(t4) - 0.126*a1*dt2*dt2*m4*cos(t4)*sin(t2)*(t2)*sin(t3) + 0.0102*a2*dt2*dt3*m4*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4) - 1.0*a1*a3*dt2*dt2*m4*cos(t2)*(t2)*cos(t3)*sin(t4)
    - 1.0*a1*a3*dt2*dt2*m4*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*sin(t4) - 1.0*a1*a3*dt2*dt2*m5*cos(t2)*(t2)*cos(t4)*sin(t3) + 0.0102*a2*dt2*dt3*m4*cos(t2)*(t2)*cos(t4)*sin(t3)*(t3)
    - 0.252*a2*dt2*dt3*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) + 0.0102*a2*dt2*dt3*m4*cos(t3)*(t3)*cos(t4)*sin(t2)*(t2) - 0.126*a2*dt2*dt4*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 0.126*a2*dt3*dt4*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)
    - 1.0*a1*a3*dt2*dt2*m4*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt2*m4*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a3*dt2*dt2*m5*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt2*m5*cos(t4)*sin(t2)*(t2)*sin(t3)
    + 0.0102*a2*dt2*dt3*m4*cos(t4)*sin(t2)*(t2)*sin(t3)*(t3) - 0.252*a2*dt2*dt3*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 0.252*a2*dt2*dt3*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 0.126*a2*dt2*dt4*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 0.126*a2*dt2*dt4*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 0.126*a2*dt3*dt4*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 0.126*a2*dt3*dt4*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 0.252*a2*dt2*dt3*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 0.126*a2*dt2*dt4*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 0.126*a2*dt3*dt4*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt2*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)
    - 1.0*a2*a3*dt3*dt3*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt3*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt2*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt2*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)
    - 1.0*a2*a3*dt2*dt2*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt2*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a3*dt3*dt3*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt3*dt3*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)
    - 1.0*a2*a3*dt3*dt3*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt3*dt3*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a3*dt2*dt2*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt2*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 1.0*a2*a3*dt3*dt3*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt3*dt3*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 0.126*a1*dt2*dt3*m4*cos(t2)*(t2)*cos(t3)*sin(t4) - 0.126*a1*dt2*dt3*m4*cos(t2)*(t2)*cos(t4)*sin(t3)
    - 0.126*a1*dt2*dt4*m4*cos(t2)*(t2)*cos(t3)*sin(t4) - 0.126*a1*dt2*dt4*m4*cos(t2)*(t2)*cos(t4)*sin(t3) - 0.126*a1*dt2*dt3*m4*cos(t3)*sin(t2)*(t2)*sin(t4) - 0.126*a1*dt2*dt3*m4*cos(t4)*sin(t2)*(t2)*sin(t3) - 0.126*a1*dt2*dt4*m4*cos(t3)*sin(t2)*(t2)*sin(t4)
    - 0.126*a1*dt2*dt4*m4*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*cos(t5)*sin(t4) - 1.0*a1*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t4)*cos(t5)*sin(t3)
    - 1.0*a1*a4*dt2*dt2*m5*cos(t3)*cos(t5)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a4*dt2*dt2*m5*cos(t4)*cos(t5)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a3*dt2*dt3*m4*cos(t2)*(t2)*cos(t3)*sin(t4) - 1.0*a1*a3*dt2*dt3*m4*cos(t2)*(t2)*cos(t4)*sin(t3)
    - 1.0*a1*a3*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*sin(t4) - 1.0*a1*a3*dt2*dt3*m5*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt4*m4*cos(t2)*(t2)*cos(t3)*sin(t4) - 1.0*a1*a3*dt2*dt4*m4*cos(t2)*(t2)*cos(t4)*sin(t3)
    - 1.0*a1*a3*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*sin(t4) - 1.0*a1*a3*dt2*dt4*m5*cos(t2)*(t2)*cos(t4)*sin(t3) - 1.0*a1*a3*dt2*dt3*m4*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt3*m4*cos(t4)*sin(t2)*(t2)*sin(t3)
    - 1.0*a1*a3*dt2*dt3*m5*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt3*m5*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a3*dt2*dt4*m4*cos(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a3*dt2*dt4*m4*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a3*dt2*dt4*m5*cos(t3)*sin(t2)*(t2)*sin(t4)
    - 1.0*a1*a3*dt2*dt4*m5*cos(t4)*sin(t2)*(t2)*sin(t3) - 1.0*a2*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4) - 1.0*a2*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)
    - 1.0*a2*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt2*dt2*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt3*dt3*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)
    - 1.0*a2*a4*dt2*dt2*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt3*dt3*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 2.0*a2*a3*dt2*dt3*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)
    - 2.0*a2*a3*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt4*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt3*dt4*m4*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)
    - 1.0*a2*a3*dt3*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4) - 2.0*a2*a3*dt2*dt3*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 2.0*a2*a3*dt2*dt3*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 2.0*a2*a3*dt2*dt3*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 2.0*a2*a3*dt2*dt3*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a3*dt2*dt4*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt4*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a3*dt2*dt4*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 1.0*a2*a3*dt2*dt4*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a3*dt3*dt4*m4*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt3*dt4*m4*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a3*dt3*dt4*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 1.0*a2*a3*dt3*dt4*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4) - 2.0*a2*a3*dt2*dt3*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 2.0*a2*a3*dt2*dt3*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt2*dt4*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 1.0*a2*a3*dt2*dt4*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt3*dt4*m4*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a3*dt3*dt4*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a1*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*cos(t5)*sin(t4)
    - 1.0*a1*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t4)*cos(t5)*sin(t3) - 1.0*a1*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*cos(t5)*sin(t4) - 1.0*a1*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t4)*cos(t5)*sin(t3)
    - 1.0*a1*a4*dt2*dt5*m5*cos(t2)*(t2)*cos(t3)*cos(t4)*sin(t5) - 1.0*a1*a4*dt2*dt3*m5*cos(t3)*cos(t5)*sin(t2)*(t2)*sin(t4) - 1.0*a1*a4*dt2*dt3*m5*cos(t4)*cos(t5)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a4*dt2*dt4*m5*cos(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)
    - 1.0*a1*a4*dt2*dt4*m5*cos(t4)*cos(t5)*sin(t2)*(t2)*sin(t3) - 1.0*a1*a4*dt2*dt5*m5*cos(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) + a1*a4*dt2*dt5*m5*cos(t2)*(t2)*sin(t3)*sin(t4)*sin(t5)
    + a1*a4*dt2*dt5*m5*sin(t2)*(t2)*sin(t3)*sin(t4)*sin(t5) - 2.0*a2*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4) - 1.0*a2*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4) - 1.0*a2*a4*dt2*dt5*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*sin(t5)
    - 1.0*a2*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4) - 1.0*a2*a4*dt3*dt5*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*sin(t5) - 2.0*a2*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4)
    - 2.0*a2*a4*dt2*dt3*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt2*dt4*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a4*dt2*dt5*m5*cos(t2)*(t2)*cos(t4)*sin(t3)*(t3)*sin(t5)
    - 1.0*a2*a4*dt2*dt5*m5*cos(t3)*(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) - 1.0*a2*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt3*dt4*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)
    - 1.0*a2*a4*dt3*dt5*m5*cos(t2)*(t2)*cos(t4)*sin(t3)*(t3)*sin(t5) - 1.0*a2*a4*dt3*dt5*m5*cos(t3)*(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) - 2.0*a2*a4*dt2*dt3*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt2*dt4*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)
    - 1.0*a2*a4*dt2*dt5*m5*cos(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 1.0*a2*a4*dt3*dt4*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt3*dt5*m5*cos(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5)
    ;
    alpha(4)=a4*dt1*dt5*m5*sin(t5) - 1.0*a4*a4*dt5*dt5*m5*cos(t5)*sin(t5) - 1.0*a3*a4*dt2*dt2*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt3*dt3*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt4*dt4*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5)
    - 1.0*a1*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*cos(t4)*sin(t5) - 1.0*a1*a4*dt2*dt2*m5*cos(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) + a1*a4*dt2*dt2*m5*cos(t2)*(t2)*sin(t3)*sin(t4)*sin(t5) + a1*a4*dt2*dt2*m5*sin(t2)*(t2)*sin(t3)*sin(t4)*sin(t5)
    - 1.0*a2*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*sin(t5) - 1.0*a2*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*sin(t5) - 1.0*a2*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t4)*sin(t3)*(t3)*sin(t5)
    - 1.0*a2*a4*dt2*dt2*m5*cos(t3)*(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) - 1.0*a2*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t4)*sin(t3)*(t3)*sin(t5) - 1.0*a2*a4*dt3*dt3*m5*cos(t3)*(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) - 1.0*a2*a4*dt2*dt2*m5*cos(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5)
    - 1.0*a2*a4*dt3*dt3*m5*cos(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 1.0*a4*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t5) - 1.0*a4*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t5)
    - 1.0*a4*a4*dt4*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t5) + a4*a4*dt5*dt5*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t5) - 1.0*a4*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)*(t4)*sin(t5)
    - 1.0*a4*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t4)*(t4)*cos(t5)*sin(t3)*(t3)*sin(t5) - 1.0*a4*a4*dt2*dt2*m5*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t5)
    - 1.0*a4*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t4)*(t4)*cos(t5)*sin(t3)*(t3)*sin(t5) - 1.0*a4*a4*dt3*dt3*m5*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t5)
    - 1.0*a4*a4*dt4*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt4*dt4*m5*cos(t2)*(t2)*cos(t4)*(t4)*cos(t5)*sin(t3)*(t3)*sin(t5) - 1.0*a4*a4*dt4*dt4*m5*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t5)
    + a4*a4*dt5*dt5*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)*(t4)*sin(t5) + a4*a4*dt5*dt5*m5*cos(t2)*(t2)*cos(t4)*(t4)*cos(t5)*sin(t3)*(t3)*sin(t5) + a4*a4*dt5*dt5*m5*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t5)
    - 1.0*a4*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt2*dt2*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt2*dt2*m5*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5)
    - 1.0*a4*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt3*dt3*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt3*dt3*m5*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5)
    - 1.0*a4*a4*dt4*dt4*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt4*dt4*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt4*dt4*m5*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5)
    + a4*a4*dt5*dt5*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) + a4*a4*dt5*dt5*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5) + a4*a4*dt5*dt5*m5*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5)
    - 1.0*a3*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt4*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt2*dt2*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5)
    - 1.0*a4*a4*dt3*dt3*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a4*a4*dt4*dt4*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) + a4*a4*dt5*dt5*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5)
    - 1.0*a3*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt2*dt2*m5*cos(t2)*(t2)*cos(t4)*(t4)*sin(t3)*(t3)*sin(t5) - 1.0*a3*a4*dt2*dt2*m5*cos(t3)*(t3)*cos(t4)*(t4)*sin(t2)*(t2)*sin(t5)
    - 1.0*a3*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt3*dt3*m5*cos(t2)*(t2)*cos(t4)*(t4)*sin(t3)*(t3)*sin(t5) - 1.0*a3*a4*dt3*dt3*m5*cos(t3)*(t3)*cos(t4)*(t4)*sin(t2)*(t2)*sin(t5)
    - 1.0*a3*a4*dt4*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt4*dt4*m5*cos(t2)*(t2)*cos(t4)*(t4)*sin(t3)*(t3)*sin(t5) - 1.0*a3*a4*dt4*dt4*m5*cos(t3)*(t3)*cos(t4)*(t4)*sin(t2)*(t2)*sin(t5) - 1.0*a3*a4*dt2*dt2*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5)
    - 1.0*a3*a4*dt2*dt2*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt2*dt2*m5*cos(t4)*(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 1.0*a3*a4*dt3*dt3*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5)
    - 1.0*a3*a4*dt3*dt3*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt3*dt3*m5*cos(t4)*(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 1.0*a3*a4*dt4*dt4*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5)
    - 1.0*a3*a4*dt4*dt4*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5) - 1.0*a3*a4*dt4*dt4*m5*cos(t4)*(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 2.0*a3*a4*dt2*dt3*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt2*dt3*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5)
    - 2.0*a3*a4*dt2*dt3*m5*cos(t4)*(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 2.0*a3*a4*dt2*dt4*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt2*dt4*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5)
    - 2.0*a3*a4*dt2*dt4*m5*cos(t4)*(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 2.0*a3*a4*dt3*dt4*m5*cos(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt3*dt4*m5*cos(t3)*(t3)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5)
    - 2.0*a3*a4*dt3*dt4*m5*cos(t4)*(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 2.0*a3*a4*dt2*dt3*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt2*dt4*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt3*dt4*m5*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5)
    - 1.0*a1*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*cos(t4)*sin(t5) - 1.0*a1*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*cos(t4)*sin(t5) - 1.0*a1*a4*dt2*dt5*m5*cos(t2)*(t2)*cos(t3)*cos(t5)*sin(t4)
    - 1.0*a1*a4*dt2*dt5*m5*cos(t2)*(t2)*cos(t4)*cos(t5)*sin(t3) - 1.0*a1*a4*dt2*dt3*m5*cos(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) - 1.0*a1*a4*dt2*dt4*m5*cos(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) - 1.0*a1*a4*dt2*dt5*m5*cos(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)
    - 1.0*a1*a4*dt2*dt5*m5*cos(t4)*cos(t5)*sin(t2)*(t2)*sin(t3) + a1*a4*dt2*dt3*m5*cos(t2)*(t2)*sin(t3)*sin(t4)*sin(t5) + a1*a4*dt2*dt4*m5*cos(t2)*(t2)*sin(t3)*sin(t4)*sin(t5)
    + a1*a4*dt2*dt3*m5*sin(t2)*(t2)*sin(t3)*sin(t4)*sin(t5) + a1*a4*dt2*dt4*m5*sin(t2)*(t2)*sin(t3)*sin(t4)*sin(t5) - 2.0*a2*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*sin(t5) - 1.0*a2*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*sin(t5)
    - 1.0*a2*a4*dt2*dt5*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4) - 1.0*a2*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*sin(t5) - 1.0*a2*a4*dt3*dt5*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)
    - 2.0*a2*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t4)*sin(t3)*(t3)*sin(t5) - 2.0*a2*a4*dt2*dt3*m5*cos(t3)*(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) - 1.0*a2*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t4)*sin(t3)*(t3)*sin(t5) - 1.0*a2*a4*dt2*dt4*m5*cos(t3)*(t3)*cos(t4)*sin(t2)*(t2)*sin(t5)
    - 1.0*a2*a4*dt2*dt5*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt2*dt5*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4) - 1.0*a2*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t4)*sin(t3)*(t3)*sin(t5)
    - 1.0*a2*a4*dt3*dt4*m5*cos(t3)*(t3)*cos(t4)*sin(t2)*(t2)*sin(t5) - 1.0*a2*a4*dt3*dt5*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt3*dt5*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)
    - 2.0*a2*a4*dt2*dt3*m5*cos(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 1.0*a2*a4*dt2*dt4*m5*cos(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 1.0*a2*a4*dt2*dt5*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 1.0*a2*a4*dt3*dt4*m5*cos(t4)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5)
    - 1.0*a2*a4*dt3*dt5*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4) - 2.0*a4*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t5) - 2.0*a4*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t5)
    - 2.0*a4*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t5) - 2.0*a4*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)*(t4)*sin(t5) - 2.0*a4*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t4)*(t4)*cos(t5)*sin(t3)*(t3)*sin(t5)
    - 2.0*a4*a4*dt2*dt3*m5*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t5) - 2.0*a4*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)*(t4)*sin(t5) - 2.0*a4*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t4)*(t4)*cos(t5)*sin(t3)*(t3)*sin(t5)
    - 2.0*a4*a4*dt2*dt4*m5*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t5) - 2.0*a4*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t5)*sin(t4)*(t4)*sin(t5) - 2.0*a4*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t4)*(t4)*cos(t5)*sin(t3)*(t3)*sin(t5)
    - 2.0*a4*a4*dt3*dt4*m5*cos(t3)*(t3)*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t5) - 2.0*a4*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a4*a4*dt2*dt3*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5)
    - 2.0*a4*a4*dt2*dt3*m5*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 2.0*a4*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a4*a4*dt2*dt4*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5)
    - 2.0*a4*a4*dt2*dt4*m5*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 2.0*a4*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t5)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a4*a4*dt3*dt4*m5*cos(t3)*(t3)*cos(t5)*sin(t2)*(t2)*sin(t4)*(t4)*sin(t5)
    - 2.0*a4*a4*dt3*dt4*m5*cos(t4)*(t4)*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t5) - 2.0*a3*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*sin(t5)
    - 2.0*a3*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*cos(t4)*(t4)*sin(t5) - 2.0*a4*a4*dt2*dt3*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a4*a4*dt2*dt4*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5)
    - 2.0*a4*a4*dt3*dt4*m5*cos(t5)*sin(t2)*(t2)*sin(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt2*dt3*m5*cos(t2)*(t2)*cos(t4)*(t4)*sin(t3)*(t3)*sin(t5)
    - 2.0*a3*a4*dt2*dt3*m5*cos(t3)*(t3)*cos(t4)*(t4)*sin(t2)*(t2)*sin(t5) - 2.0*a3*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt2*dt4*m5*cos(t2)*(t2)*cos(t4)*(t4)*sin(t3)*(t3)*sin(t5)
    - 2.0*a3*a4*dt2*dt4*m5*cos(t3)*(t3)*cos(t4)*(t4)*sin(t2)*(t2)*sin(t5) - 2.0*a3*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t3)*(t3)*sin(t4)*(t4)*sin(t5) - 2.0*a3*a4*dt3*dt4*m5*cos(t2)*(t2)*cos(t4)*(t4)*sin(t3)*(t3)*sin(t5)
    - 2.0*a3*a4*dt3*dt4*m5*cos(t3)*(t3)*cos(t4)*(t4)*sin(t2)*(t2)*sin(t5);

    //--return
    Ct->col(0)=alpha;
}
