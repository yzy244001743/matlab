#include <fstream>//txt write
#include "robot_control/MotionCtrl.h"

extern Move cmd;
extern armPosInfo dataShow;
extern mutex mut;

MotionCtrl::MotionCtrl()
{
    //--calculate initial values
    m_armFeedBack.T_tool2base=ArmPosCal(m_armInput.jointPos,&m_armFeedBack.toolPos);
    m_armInput.toolPos=m_armFeedBack.toolPos;
    ParameterInit();
    m_move.isFirstPoint=true;
}
MotionCtrl::~MotionCtrl()
{
    cout<<"MotionCtrl end"<<endl;
}

MotionCtrl* MotionCtrl::GetMotionCtrlPtr()
{
    static MotionCtrl motionCtrlPtr;
    return &motionCtrlPtr;
}
MotionCtrl* MotionCtrl::GetMotionCtrlSimPtr()
{
    static MotionCtrl motionCtrlSimPtr;
    return &motionCtrlSimPtr;
}

void MotionCtrl::ParameterInit()
{
    //--route move
    m_time.now=0;
    m_time.Hz=100;

    m_move.isNextPoint=false;
    m_move.isPrint=true;

    m_move.pointPlan.clear();
    m_move.numNow=0;
    ResetStartPos();
    ResetSroute();

    //--other
    m_cmdLast<<0,0,0,0,0,0;
    CollisionInitiate();
}

void MotionCtrl::UpdateRobotStatus(Vector6f& theoryJointPos,
                                   Vector6f& realJointPos,Vector6f& jointCurrent)
{
    //--update feedback pos
    m_armFeedBack.jointPos=theoryJointPos;
    JointLimit(1,m_armFeedBack.jointPos);
    m_armFeedBack.T_tool2base=ArmPosCal(m_armFeedBack.jointPos,&m_armFeedBack.toolPos);

    //--update feedback torque
    m_armFeedBack.jointCurrent=jointCurrent;

    //--update pos when at freedrive mode
    m_armInput.toolPos=m_armFeedBack.toolPos;
    m_armInput.jointPos=m_armFeedBack.jointPos;

    //--calculate joint vel , collision detect , joint torque calculate
    CalculateVelAcc(realJointPos);
    if( (cmd.mode==ROUTE_MOVE || cmd.mode==INTERRUPT || cmd.mode==JOINT_MOVE) &&
            cmd.collisionOn==true)
    {
        CollisionDetect();
    }

    //--print information
    PrintInfo();

    //--dataShow,only joint pos is real
    dataShow.jointPos=realJointPos;
    //ArmPosCal(realJointPos,&dataShow.toolPos);
    dataShow.toolPos=m_armFeedBack.toolPos;
    dataShow.armState=m_armState;
}
void MotionCtrl::ControlLoop()
{
    if(m_time.now==0)
    {
        ResetStartPos();
    }
    //-- mode
    switch (cmd.mode)
    {
    case FOLLOW_MOVE_OFF:
        ParameterInit();
        break;
    case TRAJ_MOVE:
        //TrajMove();
        break;
    case POINT_MOVE:
        PointMove(cmd.toolVel,0.01);
        //VelMove(cmd.toolVel);
        break;
    case JOINT_MOVE:
        JointMove(cmd.jointVel,0.01);
        break;
    case SLOW_DOWN:
        SlowMove();
        break;
    case ROUTE_MOVE:
        RouteMove();
        break;
    case INTERRUPT:
        RouteMove();
        break;
    case RETURN_ZERO:
        ReturnZeroPos();
        break;
    case STOP:
        ParameterInit();
        break;
    case SUSPEND:
        Suspend(cmd.collisionSet(1));
    case FREE_DRIVE:
        FreeDrive();
        break;
    case COPY_MOVE:
        //CopyMove();
        break;
    case CLOSE:
        break;
    default:
        break;
    }
    if(cmd.modeLast!=cmd.mode &&
            cmd.mode!=SLOW_DOWN)//update
    {
        cmd.modeLast=cmd.mode;
    }

    //--arm velocity safe control
    SafeControl();

    //--arm state
    if(m_isIkError==true)
    {
        cmd.mode=STOP;
        m_armState=IKERROR;
        m_isIkError=false;//reset
    }
    if(cmd.mode!=STOP &&
             m_armState!=WAIT )
    {
        m_armState=RUNNING;
    }
    if(cmd.mode==STOP &&
            m_armState!=IKERROR &&
            m_armState!=COLLISION)
    {
        m_armState=FINISHED;
    }
}
void MotionCtrl::SafeControl()
{
    //--velocity safe control
    if(cmd.isJointTest==true)
    {
        if(cmd.printAllJointInfo(0)==true)
        {
            m_armParam.jointVelLimit<<0.3,30*DEG2RAD,30*DEG2RAD,
                    30*DEG2RAD,30*DEG2RAD,30*DEG2RAD;//when test the max end vel(<1m)
        }
        else
        {
            m_armParam.jointVelLimit<<0.3,60*DEG2RAD,60*DEG2RAD,
                    60*DEG2RAD,60*DEG2RAD,60*DEG2RAD;
        }
    }

    Matrix<float,6,5> J0=Jacobian0(m_armInput.jointPos);
    Vector6f velTip=J0*m_armInput.jointVel.block<5,1>(0,0);
    //if(cmd.mode!=STOP)  //test ok
    //{cout<<"tipVel= "<<velTip.transpose()<<endl;}

    if(cmd.mode!=STOP)
    {
        cout<<clr::red;
        for(int i=0;i<m_armParam.dof;i++)
        {
            if(fabs(m_armInput.jointPos(i)-m_armInput.jointPosLast(i))>
                    m_armParam.jointVelLimit(i)/m_time.Hz*1.2)
            {
                if(m_armParam.jointType(i)==0)
                {
                    cout<<"joint "<<i+1<<" out of speed !"
                       <<" v_now:"<<(m_armInput.jointPos(i)-m_armInput.jointPosLast(i))*m_time.Hz*RAD2DEG<<"deg/s;"
                      <<" limitV:"<<m_armParam.jointVelLimit(i)*RAD2DEG<<"deg/s"<<endl;
                }
                else
                {
                    cout<<"joint "<<i+1<<" out of speed !"
                       <<" v_now:"<<(m_armInput.jointPos(i)-m_armInput.jointPosLast(i))*m_time.Hz<<"m/s;"
                      <<" limitV:"<<m_armParam.jointVelLimit(i)<<"m/s"<<endl;
                }
                m_isIkError=true;
            }
        }
        if( sqrt(velTip(0)*velTip(0)+velTip(1)*velTip(1) )>1)
        {
            m_isIkError=true;
            cout<<"tip vel out of speed"
               <<" v_now:"<<velTip(0)
              <<" limitV:"<<1<<endl;
        }
        cout<<clr::reset;
    }
}
void MotionCtrl::TrajFollowByTorque(Vector6f &goalJointPos,float kBuffer)
{
    //--traj follow
    Vector6f kp,kd,dq;
    kp<<4800,6000,4000,4000,4000,5000;
    kd<<800,2200,600,1500,300,300;
    dq<<0,0,0,0,0,0;
    m_armInput.jointTorque=ArmDynamicDH(m_armInput.jointPos,m_armInput.jointVel,dq);//forward feedback

    //Vector6f qdFeedback=VelLowFilter(0.1,m_armFeedBack.jointRealVel);
    static Vector6f velLast;
    float kLowFilter=0.1;
    Vector6f qdFeedback = kLowFilter* m_armFeedBack.jointRealVel + (1.0F - kLowFilter) *velLast;
    velLast=qdFeedback;

    for(int i=0;i<m_armParam.dof;i++)
    {
        Vector6f dy,dv;
        dy(i)=goalJointPos(i)-m_armFeedBack.jointRealPos(i);
        dv(i)=m_armInput.jointVel(i)-qdFeedback(i);
        m_armInput.jointCurrent(i)=m_armParam.kTorque(i)*m_armInput.jointTorque(i)+
                kBuffer*( kp(i)*dy(i)+0.25*kd(i)*dv(i) );
    }
}

//--api functions
void MotionCtrl::GetGoalJointPos(Vector6f *jointPos)
{
    jointPos->col(0)=m_armInput.jointPos;
}

void MotionCtrl::GetGoalJointTorque(Vector6f *jointTorque)
{
    jointTorque->col(0)=m_armInput.jointCurrent;
}

void MotionCtrl::GetTend2base(Matrix4f *T_end2base)
{
    for(int i=0;i<4;i++)
    {
        T_end2base->col(i)=m_armFeedBack.T_tool2base.col(i);
    }
}

Vector6f MotionCtrl::GetToolPosError()
{
    Vector6f realToolPosPos;
    ArmPosCal(dataShow.jointPos,&realToolPosPos);
    Vector6f error=m_armFeedBack.toolPos-realToolPosPos;
    cout<<"real/theory POS: "<<realToolPosPos(0)<<","<<realToolPosPos(1)<<","<<realToolPosPos(2)<<","
       <<m_armFeedBack.toolPos(0)<<","<<m_armFeedBack.toolPos(1)<<","<<m_armFeedBack.toolPos(2)<<"; ";
    return error;
}

void MotionCtrl::ArmSimInterface(Vector6f& jointCurrent, Vector6f* simJointPos)
{
    UpdateRobotStatus((*simJointPos),(*simJointPos),jointCurrent);
    ControlLoop();
    GetGoalJointPos(simJointPos);//output goal angle
}
void MotionCtrl::ArmInterface(MOTORMODE motorMode,
                              Vector6f& realJointPos, Vector6f& jointCurrent,
                              Vector6f* theoryJointPos,Vector6f* goalTorque )
{
    static MOTORMODE modeLast=POS_MODE;
    static float kBuffer=0;
    if(modeLast!=motorMode)
    {
        kBuffer=0;
        modeLast=motorMode;//update
        if(motorMode==TORQUE_MODE)
        {
            cmd.mode=FREE_DRIVE;
        }
    }
    //--control algorithm
    if(motorMode==POS_MODE)
    {
        UpdateRobotStatus((*theoryJointPos),realJointPos,jointCurrent);
        ControlLoop();
        GetGoalJointPos(theoryJointPos);  //output goal angle
        CalFeedforwardCurrent(goalTorque);//output goal torque
    }
    if(motorMode==TORQUE_MODE)
    {
        UpdateRobotStatus((*theoryJointPos),realJointPos,jointCurrent);
        ControlLoop();
        GetGoalJointTorque(goalTorque);   //output goal torque
    }
    if(motorMode==IMPEDANCE_MODE)
    {
        UpdateRobotStatus((*theoryJointPos),realJointPos,jointCurrent);
        ControlLoop();
        GetGoalJointPos(theoryJointPos);  //output goal angle
        //--get torque
        if(kBuffer<=1)
        {
            kBuffer+=(0.01/3);
        }
        TrajFollowByTorque((*theoryJointPos),kBuffer);
        GetGoalJointTorque(goalTorque);   //output goal current
    }
}

//--mode function
void MotionCtrl::VelMove(Vector6f& toolVel)
{
    Vector6f velJoint;
    velJoint=VelControl(m_armInput.jointPos,toolVel);
    m_armInput.jointPos+=velJoint/m_time.Hz;
    JointLimit(0,m_armInput.jointPos);
}
bool MotionCtrl::PointMove(Vector6f& toolVelCmd,float kAcc)
{
    Vector3f rpy,pos;
    typedef enum
    {
        WORLD = 0,
        TOOL = 1,
    }IK_TYPE;
    IK_TYPE IKtype;
    IKtype=TOOL;

    Vector6f toolVel=toolVelCmd;
    toolVel=CmdLowFilter(kAcc,toolVel);
    //cout<<toolVel.transpose()<<endl;
    //--cal present toolPos
    if(IKtype==WORLD)
    {
        m_armInput.toolPos+=toolVel/m_time.Hz;
        pos=m_armInput.toolPos.block<3,1>(0,0);
        rpy=m_armInput.toolPos.block<3,1>(3,0);
    }
    if(IKtype==TOOL)
    {
        //pos in {world}
        m_armInput.toolPos(0)+=toolVel(0)/m_time.Hz;
        m_armInput.toolPos(1)+=toolVel(1)/m_time.Hz;
        m_armInput.toolPos(2)+=toolVel(2)/m_time.Hz;
        pos=m_armInput.toolPos.block<3,1>(0,0);

        //rpy in {tool} ,reference to the toolZero
        rpy=toolVel.block<3,1>(3,0)/m_time.Hz;           //RPY_toolNext2toolNow
        Matrix3f R_toolNow2base=m_armFeedBack.T_tool2base.block<3,3>(0,0);
        rpy=GetRPYtoolNext2toolZero(R_toolNow2base,rpy); //RPY_toolNext2toolZero
    }
    //--IK
    ArmIK(rpy,pos,&m_armInput.jointPos);

    //--return
    if(toolVel.norm()<0.01*cmd.speed)//v<0.01 m/s
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool MotionCtrl::JointMove(Vector6f& jointVelCmd,float kAcc)
{
    Vector6f jointVel;
    for(int i=0;i<m_armParam.dof;i++)
    {
        if(m_armParam.jointType(i)==0)
        {
            jointVel(i)=cmd.velMax(2)*jointVelCmd(i);
        }
        else
        {
            jointVel(i)=cmd.velMax(0)*jointVelCmd(i);
        }
    }
    jointVel=CmdLowFilter(kAcc,jointVel);
    m_armInput.jointPos+=jointVel/m_time.Hz;
    JointLimit(0,m_armInput.jointPos);

    //--return
    if(jointVel.norm()<1.0f*DEG2RAD*cmd.speed)//v<1 degree/s
    {
        return 1;
    }
    else
    {
        return 0;
    }
    //cout<<jointVel(0)<<","<<jointVelCmd(0)<<endl;
}
void MotionCtrl::SlowMove()
{
    if(cmd.modeLast==POINT_MOVE)
    {
        if(PointMove(cmd.toolVel,0.06)==1)
        {
            cmd.mode=STOP;
        }
    }
    if(cmd.modeLast==JOINT_MOVE)
    {
        if(JointMove(cmd.jointVel,0.06)==1)
        {
            cmd.mode=STOP;
        }
    }
}
bool MotionCtrl::RouteMove()
{
    m_armState=RUNNING;
    //--copy cmd to pointPlan , optimize or ckeck the point is valid
    if(cmd.isUpdate==true)
    {
        cmd.isUpdate=false;
        if(CopyCmd2Route()==false)
        {
            m_armState=IKERROR;
            cmd.mode=STOP;
            return 0;
        }
        if(cmd.mode==INTERRUPT)
        {
            if(InitInterruptMove()==false)
            {
                cmd.mode=STOP;
                return 0;
            }
        }
    }

    //--iter
    if(m_move.isNextPoint==true)
    {
        m_move.iter++;
        m_move.numNow++;
        m_move.isNextPoint=false;
        m_move.isPrint=true;

        float error=(m_armInput.jointPos-m_armParam.zeroPos).squaredNorm();
        if(error<0.1 &&
                (m_move.iter->nodeType!=J_NODE &&
                 m_move.iter->nodeType!=SJ_NODE &&
                 m_move.iter->nodeType!=IK_J_NODE &&
                 m_move.iter->nodeType!=IK_SJ_NODE &&
                 m_move.iter->nodeType!=WAIT_NODE &&
                 m_move.iter->nodeType!=HAND_NODE &&
                 m_move.iter->nodeType!=HEAD_NODE &&
                 m_move.iter->nodeType!=WHEEL_NODE) )
        {
            m_move.isFirstPoint=true;
        }
    }
    if(m_move.iter==m_move.iterEnd)
    {
        m_move.isNextPoint=false;
        if(cmd.isLoopTest)
        {
            m_move.iter=m_move.iterHead;//loop test
        }
        else
        {
            cmd.mode=STOP;              //not loop
        }
    }

    //--print node information
    if(cmd.isPrintNode==true && m_move.isPrint==true && cmd.mode!=STOP)
    {
        cout<<clr::cyan<<"current node:"<<m_move.numNow<<" --> "<<clr::reset;
        PrintPoint(m_move.iter);
        m_move.isPrint=false;
    }
    //--INTERRUPT
    if(cmd.mode==INTERRUPT)
    {
        if(InterruptMoveJ()==1)
        {
            m_move.isNextPoint=true;
            cmd.mode=ROUTE_MOVE;
        }
    }
    //--ROUTE_MOVE
    if(cmd.mode==ROUTE_MOVE && m_move.isFirstPoint==false)
    {
        if(m_move.iter->nodeType==IK_J_NODE)//node trans
        {
            Vector6f jointPos;
            Vector6f toopPos=GetGoalFromCmd(m_move.iter);
            ArmIK(toopPos,&jointPos);
            if(JointLimit(0,jointPos)==1)
            {
                cout<<clr::red<<"IK_J_NODE error --> "<<clr::reset;
                return 0;
            }
            m_move.iter->xPos=jointPos(0);
            m_move.iter->yPos=jointPos(1);
            m_move.iter->zPos=jointPos(2);
            m_move.iter->rxPos=jointPos(3);
            m_move.iter->ryPos=jointPos(4);
            m_move.iter->rzPos=jointPos(5);
            m_move.iter->nodeType=J_NODE;
        }
        if(m_move.iter->nodeType==IK_SJ_NODE)//node trans
        {
            int count=0;
            while(m_move.iter->nodeType==IK_SJ_NODE && m_move.iter!=m_move.iterEnd )
            {
                Vector6f jointPos;
                Vector6f toopPos=GetGoalFromCmd(m_move.iter);
                ArmIK(toopPos,&jointPos);
                if(JointLimit(0,jointPos)==1)
                {
                    cout<<clr::red<<"IK_SJ_NODE error --> "<<clr::reset;
                    return 0;
                }
                m_move.iter->xPos=jointPos(0);
                m_move.iter->yPos=jointPos(1);
                m_move.iter->zPos=jointPos(2);
                m_move.iter->rxPos=jointPos(3);
                m_move.iter->ryPos=jointPos(4);
                m_move.iter->rzPos=jointPos(5);
                m_move.iter->nodeType=SJ_NODE;

                m_move.iter++; count++;
            }
            m_move.iter=m_move.iter-count;
        }
        switch(m_move.iter->nodeType)
        {
        case WAIT_NODE:
        {
            float waitTime=m_move.iter->time;
            if(Wait(waitTime)==1)
            {
                m_move.isNextPoint=true;
            }
            m_armState=WAIT;
            break;
        }
        case HAND_NODE:
        {
            mut.lock ();
            cmd.hand=GetGoalFromCmd(m_move.iter);
            mut.unlock ();
            m_move.isNextPoint=true;
            break;
        }
        case HEAD_NODE:
        {
            mut.lock ();
            cmd.head=GetGoalFromCmd(m_move.iter);
            mut.unlock ();
            m_move.isNextPoint=true;
            break;
        }
        case WHEEL_NODE:
        {
            mut.lock ();
            cmd.wheel << m_move.iter->time ,GetGoalFromCmd(m_move.iter);//[tpye,1*6 cmd]
            mut.unlock ();
            m_move.isNextPoint=true;
            break;
        }
        case LINE_NODE:
        {
            Vector6f goalToolPos=GetGoalFromCmd(m_move.iter);
            float totalT=m_move.iter->time;
            if(MoveL(goalToolPos,totalT)==1)
            {
                m_move.isNextPoint=true;
            }
            break;
        }
        case J_NODE:
        {
            Vector6f goalAnglePos=GetGoalFromCmd(m_move.iter);
            float totalT=m_move.iter->time;
            if(cmd.isJointTest)
            {
                if(MoveJAV(goalAnglePos)==1)
                {
                    m_move.isNextPoint=true;
                }
            }
            else
            {
//                if(MoveJ(goalAnglePos,totalT)==1)
//                {
//                    m_move.isNextPoint=true;
//                }
                if(MoveToJointPos(goalAnglePos,1)==1)
                {
                    m_move.isNextPoint=true;
                }
            }
            break;
        }
        case CIRCLE_NODE:
        {
            Vector3f pm,pe;
            pm<<m_move.iter->xPos,
                    m_move.iter->yPos,
                    m_move.iter->zPos;
            pe<<(m_move.iter+1)->xPos,
                    (m_move.iter+1)->yPos,
                    (m_move.iter+1)->zPos;
            float totalT=(m_move.iter->time+(m_move.iter-1)->time);
            if(MoveC(pm,pe,totalT)==1)
            {
                m_move.iter++;
                m_move.numNow++;
                m_move.isNextPoint=true;
            }
            break;
        }
        case S_NODE:
        {
            ReadRoute(S_NODE);
            if(MoveS(m_sRoute.Points)==1)
            {
                m_move.isNextPoint=true;
            }
            break;
        }
        case SJ_NODE:
        {
            ReadRoute(SJ_NODE);
            if(MoveSJ(m_sRoute.Points)==1)
            {
                m_move.isNextPoint=true;
            }
            break;
        }
        case ROT_NODE:
        {
            Vector3f rotCmd;
            rotCmd<<m_move.iter->rxPos,m_move.iter->ryPos,m_move.iter->rzPos;
            float totalTime=m_move.iter->time;
            if(MoveRot(rotCmd,totalTime)==1)
            {
                m_move.isNextPoint=true;
            }
            break;
        }
        default:
            break;
        }
    }
    if(cmd.mode == ROUTE_MOVE &&
            m_move.isFirstPoint==true &&
            (m_move.iter->nodeType!=HAND_NODE &&
            m_move.iter->nodeType!=HEAD_NODE &&
            m_move.iter->nodeType!=WHEEL_NODE ) )//only when startPos ~= zeroPos
    {
        Vector6f goalJointPos,goalToolPos;
        goalToolPos=GetGoalFromCmd(m_move.iter);
        ArmIK(goalToolPos,&goalJointPos);

        if(MoveToJointPos(goalJointPos,0.5)==1)
        {
            m_move.isFirstPoint=false;
        }
    }

    //--return
    return 1;
}

void MotionCtrl::ReturnZeroPos()
{   
    m_move.isFirstPoint=true;
//    if(MoveJ(m_armParam.zeroPos,2)==1)
//    {
//        cmd.mode=STOP;
//    }
    if(MoveToJointPos(m_armParam.zeroPos,0.5)==1)
    {
        cmd.mode=STOP;
    }
    //    if(MoveJAV(m_armParam.zeroPos)==1)// seems weird
    //    {
    //        cmd.mode=STOP;
    //    }
}
void MotionCtrl::FreeDrive()
{
    Vector6f dq;
    dq<<0,0,0,0,0,0;
    //m_armInput.jointTorque=ArmDynamicDH(m_armFeedBack.jointRealPos,dq,dq);
    m_armInput.jointTorque=ArmDynamicDH(m_armFeedBack.jointRealPos,m_armFeedBack.jointRealVel,dq);
    m_armInput.jointCurrent=Torque2Current(m_armInput.jointTorque);
    for(int i=0;i<m_armParam.dof;i++)
    {
        m_armInput.jointCurrent(i)=Limit(m_armInput.jointCurrent(i),-1500,1500);// 1000==100%
    }
}
void MotionCtrl::CalFeedforwardCurrent(Vector6f *jointCurrent)
{
    Vector6f torque=ArmDynamicDH(m_armInput.jointPos,m_armInput.jointVel,m_armInput.jointAcc)
            +0*FrictionCal(m_armInput.jointVel);
    Vector6f current=Torque2Current(torque);
    for(int i=0;i<m_armParam.dof;i++)
    {
        current(i)=Limit(current(i),-1500,1500);// 1000==100%
    }

    static int num=0;
    if(num++%5==0)
    {
        //cout<<"fc: "<<current.transpose()<<endl;
        num=0;
    }
    jointCurrent->col(0)=current;
}
void MotionCtrl::Suspend(float time)
{
    if(IsFinished(time)==1)
    {
        if(m_move.pointPlan.empty()==true)
        {
            cout<<clr::red<<"node is empty !"<<clr::reset;
            cmd.mode=STOP;
        }
        else
        {
            cmd.mode=INTERRUPT;
            InitInterruptMove();
        }
    }
}
bool MotionCtrl::InitInterruptMove()
{
    m_interrupt.startJointVel=m_armInput.jointVel;
    m_interrupt.startJointPos=m_armInput.jointPos;

    Vector6f endToolPos=GetGoalFromCmd(m_move.iter);
    if(     m_move.iter->nodeType==J_NODE ||
            m_move.iter->nodeType==SJ_NODE )
    {
        m_interrupt.endJointPos=endToolPos;
    }
    else if(m_move.iter->nodeType==LINE_NODE ||
            m_move.iter->nodeType==IK_J_NODE ||
            m_move.iter->nodeType==IK_SJ_NODE
            )
    {
        ArmIK(endToolPos,&m_interrupt.endJointPos);
    }
    else
    {
        cout<<clr::red<<"interrupt node error !"<<clr::reset;
        return false;
    }

    Vector3f dis;
    dis<<   m_armInput.toolPos(0)-endToolPos(0),
            m_armInput.toolPos(1)-endToolPos(1),
            m_armInput.toolPos(2)-endToolPos(2);
    //m_interrupt.totalTime=dis.norm()/0.2*cmd.speed;
    //m_interrupt.totalTime=Limit(m_interrupt.totalTime,0.5,10);
    m_interrupt.totalTime=m_move.iter->time;
    if(m_armState==COLLISION)
    {
        m_interrupt.totalTime=m_move.iter->time-m_time.now;
        m_interrupt.totalTime=Limit(m_interrupt.totalTime,0.3,2);
    }

    m_time.now=0;
    IsFinished(m_interrupt.totalTime);//m_time.now +1
    return true;
}

bool MotionCtrl::InterruptMoveJ()
{
    for(int i=0;i<m_armParam.dof;i++)
    {
        m_armInput.jointPos(i)=InterpWhenEndposChange(m_interrupt.startJointPos(i),m_interrupt.endJointPos(i)
                                                      ,m_interrupt.startJointVel(i),m_interrupt.totalTime,m_time.now);
    }
    return(IsFinished(m_interrupt.totalTime));
}

//--route read,check,optimize
bool MotionCtrl::CopyCmd2Route()
{
    //--init
    m_move.pointPlan.clear();
    m_move.pointPlan.assign(cmd.route.begin(), cmd.route.end());
    m_move.iter=m_move.pointPlan.begin();
    m_move.iterHead=m_move.pointPlan.begin();
    m_move.iterEnd=m_move.pointPlan.end();
    if(m_move.pointPlan.empty()==true)
    {
        cout<<clr::red<<"node is empty !"<<clr::reset;
        return 0;
    }

    //--loop decode
    while( m_move.iter!=m_move.iterEnd )
    {
        if( m_move.iter->nodeType!=ROT_NODE &&
                (m_move.iter+1)->nodeType==ROT_NODE &&
                (m_move.iter+1)!=m_move.iterEnd )  //need to be optimized based on last node-T_tool2base;
        {
            ChangeRouteUnit(m_move.iter);
            Vector6f endPoint=GetGoalFromCmd(m_move.iter);
            Vector3f endPos,rpyEnd;
            endPos=endPoint.block<3,1>(0,0);
            rpyEnd=endPoint.block<3,1>(3,0);
            if(CheckRotPoint(&endPos,&rpyEnd)==0)
            {
                cout<<clr::red<<"Rot Node error --> "<<clr::reset;
                PrintPoint(m_move.iter);
                return 0;
            }
            m_move.iter->xPos=endPos(0);//update the optimized result
            m_move.iter->yPos=endPos(1);
            m_move.iter->zPos=endPos(2);
            m_move.iter->rxPos=rpyEnd(0);
            m_move.iter->ryPos=rpyEnd(1);
            m_move.iter->rzPos=rpyEnd(2);
        }
        else if (m_move.iter->nodeType==ROT_NODE)
        {
            ChangeRouteUnit(m_move.iter);
        }
        else if (m_move.iter->nodeType==J_NODE ||
                 m_move.iter->nodeType==SJ_NODE)
        {
            ChangeJointUnit(m_move.iter);
            Vector6f endPoint=GetGoalFromCmd(m_move.iter);
            if(JointLimit(0,endPoint)==1)
            {
                cout<<clr::red<<"J_NODE error --> "<<clr::reset;
                return 0;
            }
        }
        else if(m_move.iter->nodeType==WAIT_NODE ||
                m_move.iter->nodeType==HAND_NODE ||
                m_move.iter->nodeType==HEAD_NODE ||
                m_move.iter->nodeType==WHEEL_NODE )
        {
            //do nothing
        }
        else
        {
            ChangeRouteUnit(m_move.iter);
            Vector6f endPoint=GetGoalFromCmd(m_move.iter);
            Vector6f jointPos;

            //cout<<"IKerror check: "<<ArmIKCheck( endPoint.block<3,1>(3,0), endPoint.block<3,1>(0,0),sign(m_armInput.jointPosLast(2)))<<endl;
            if (CheckMovePoint(endPoint,&jointPos)==0)
            {
                cout<<clr::red<<"Move node error --> "<<clr::reset;
                PrintPoint(m_move.iter);
                return 0;
            }
        }
        PrintPoint(m_move.iter);
        m_move.iter++;                    //next node
    }

    //--reset
    m_move.iter=m_move.pointPlan.begin(); //reset iter
    if( m_move.iter->nodeType==J_NODE        ||
            m_move.iter->nodeType==SJ_NODE   ||
            m_move.iter->nodeType==IK_J_NODE ||
            m_move.iter->nodeType==IK_SJ_NODE||
            m_move.iter->nodeType==WAIT_NODE ||
            m_move.iter->nodeType==HAND_NODE ||
            m_move.iter->nodeType==HEAD_NODE ||
            m_move.iter->nodeType==WHEEL_NODE)
    {
        m_move.isFirstPoint=false;
    }
    return 1;
}
void MotionCtrl::PrintPoint(vector<ROUTE_NODE>::iterator iter)
{
    if(cmd.isPrintNode==true)
    {
        cout<<clr::blue;
        switch (iter->nodeType)
        {
        case LINE_NODE:
            cout<<"LINE_NODE  ";
            break;
        case WAIT_NODE:
            cout<<"WAIT_NODE  ";
            break;
        case CIRCLE_NODE:
            cout<<"CIRCLE_NODE";
            break;
        case S_NODE:
            cout<<"S_NODE     ";
            break;
        case SJ_NODE:
            cout<<"SJ_NODE    ";
            break;
        case J_NODE:
            cout<<"J_NODE     ";
            break;
        case ROT_NODE:
            cout<<"ROT_NODE   ";
            break;
        case HAND_NODE:
            cout<<"HAND_NODE  ";
            break;
        case HEAD_NODE:
            cout<<"HEAD_NODE  ";
            break;
        case WHEEL_NODE:
            cout<<"WHEEL_NODE ";
            break;
        case IK_J_NODE:
            cout<<"IK_J_NODE  ";
            break;
        case IK_SJ_NODE:
            cout<<"IK_SJ_NODE ";
            break;
        default:
            break;
        }
        cout<<clr::reset;
        if(iter->nodeType==HAND_NODE ||
                iter->nodeType==HEAD_NODE ||
                iter->nodeType==WHEEL_NODE||
                iter->nodeType==J_NODE ||
                iter->nodeType==SJ_NODE||
                iter->nodeType==IK_J_NODE ||
                iter->nodeType==IK_SJ_NODE)
        {
            cout<<": "<<iter->time<<", "<<iter->xPos<<", "<<iter->yPos<<", "<<iter->zPos
               <<", "<<iter->rxPos<<", "<<iter->ryPos<<", "<<iter->rzPos<<endl;
        }
        else
        {
            cout<<": "<<iter->time<<", "<<iter->xPos<<", "<<iter->yPos<<", "<<iter->zPos
               <<", "<<iter->rxPos/pi*180<<", "<<iter->ryPos/pi*180<<", "<<iter->rzPos/pi*180<<endl;

        }
    }
}
void MotionCtrl::ReadRoute(NODE_TYPE node)
{
    while(m_move.iter->nodeType==node && m_sRoute.iSsRouteInitiated[0]==false)
    {
        m_sRoute.Points.push_back(*m_move.iter);
        m_move.iter++;
        m_move.numNow++;
        if(m_move.iter->nodeType!=node || m_move.iter==m_move.iterEnd)
        {
            m_move.iter--;
            m_move.numNow--;
            m_sRoute.iSsRouteInitiated[0]=true;
        }
    }
}

bool MotionCtrl::CheckMovePoint(Vector6f &endPoint,Vector6f *jointPos)
{
    Matrix4f Ttool2base;
    float ret=ArmIKForCheck(endPoint,jointPos,&Ttool2base);

    return ret;
}
bool MotionCtrl::CheckRotPoint(Vector3f *endPos,Vector3f *rpyEnd)
{
    float calTimes=0;
    rpyEnd->coeffRef(1)=-calTimes/180*pi;
    float ret=0;
    while(ret==0)
    {
        ret=CheckRotPose(endPos,rpyEnd);
        rpyEnd->coeffRef(1)=-1.0/180*pi*calTimes;
        calTimes++;
        if(calTimes>10)
        {
            break;
        }
    }
    return ret;
}
bool MotionCtrl::CheckRotPose(Vector3f *endPos,Vector3f *rpyEnd)
{
    Vector6f endPoint,jointPos;
    endPoint<<endPos->coeffRef(0),endPos->coeffRef(1),endPos->coeffRef(2),
            rpyEnd->coeffRef(0),rpyEnd->coeffRef(1),rpyEnd->coeffRef(2);
    Matrix4f Ttool2base,tmp;
    float ret=ArmIKForCheck(endPoint,&jointPos,&Ttool2base);
    if (ret==0)
    {
        return 0;
    }
    //--rot check
    int num=20;
    for (int i=1;i<num;i++)
    {
        Vector3f RPY_toolNext2toolNow,RPY_toolNext2toolZero;
        RPY_toolNext2toolNow<<0,i*100.0f/num*pi/180,0;
        Matrix3f R_toolNow2base=Ttool2base.block<3,3>(0,0);
        RPY_toolNext2toolZero=GetRPYtoolNext2toolZero(R_toolNow2base,RPY_toolNext2toolNow);

        endPoint<<endPos->coeffRef(0),endPos->coeffRef(1),endPos->coeffRef(2),
                RPY_toolNext2toolZero(0),RPY_toolNext2toolZero(1),RPY_toolNext2toolZero(2);
        ret=ArmIKForCheck(endPoint,&jointPos,&tmp);
        if (ret==0)
        {
            return 0;
        }
    }

    return ret;
}
void MotionCtrl::ChangeRouteUnit(vector<ROUTE_NODE>::iterator iter)
{
    iter->xPos=iter->xPos/1000;
    iter->yPos=iter->yPos/1000;
    iter->zPos=iter->zPos/1000;
    iter->rxPos=iter->rxPos*DEG2RAD;
    iter->ryPos=iter->ryPos*DEG2RAD;
    iter->rzPos=iter->rzPos*DEG2RAD;
}
void MotionCtrl::ChangeJointUnit(vector<ROUTE_NODE>::iterator iter)
{
    float mm2m=0.001;
    Vector6f unit;
    for (int i=0;i<m_armParam.dof;i++)
    {
        if(m_armParam.jointType(i)==0)
        {
            unit(i)=DEG2RAD;
        }
        else
        {
            unit(i)=mm2m;
        }
    }
    iter->xPos=iter->xPos*unit(0);
    iter->yPos=iter->yPos*unit(1);
    iter->zPos=iter->zPos*unit(2);
    iter->rxPos=iter->rxPos*unit(3);
    iter->ryPos=iter->ryPos*unit(4);
    iter->rzPos=iter->rzPos*unit(5);
}
Vector6f MotionCtrl::GetGoalFromCmd(vector<ROUTE_NODE>::iterator iter)
{
    Vector6f goalToolPos;

    goalToolPos(0)=iter->xPos;
    goalToolPos(1)=iter->yPos;
    goalToolPos(2)=iter->zPos;
    goalToolPos(3)=iter->rxPos;
    goalToolPos(4)=iter->ryPos;
    goalToolPos(5)=iter->rzPos;
    return goalToolPos;
}

//--filter
Vector6f MotionCtrl::CmdLowFilter(float kLowFilter,const Vector6f &in)
{
    Vector6f out;
    out = kLowFilter* in + (1.0F - kLowFilter) * m_cmdLast;
    m_cmdLast= out;
    return out;
}


//--other function
#include <iomanip>
void MotionCtrl::PrintInfo()
{
    //--m_print**(0)==0: no print,1: print when runs,2 : always print
    int period;
    cout<< fixed <<setprecision(3);//is valid for the project , not only the pkg

    //--print joint current -> joint theory/real current [1*n;1*n]
    static int n=1;
    period=cmd.Hz/cmd.printJointCurrent(1);
    cmd.isPrintTheoryTorque=cmd.printJointCurrent(0);
    if( cmd.printJointCurrent(0)!=0
            &&( cmd.mode!=STOP|| cmd.printJointCurrent(0)==2) )
    {
        if((n++)%period==0)
        {
            Vector6f theoryCurrent=CalCurrentByTheoryPos();
            cout<<"joint theory/real current:"<<theoryCurrent.transpose()<<" ; "
               <<m_armFeedBack.jointCurrent.transpose()<<endl;
            n=1;
        }
    }

    //--print all motor error -> motor error [1*n]
    static int n2=1;
    period=cmd.Hz/cmd.printMotorError(1);
    if( cmd.printMotorError(0)!=0
            &&( cmd.mode!=STOP|| cmd.printMotorError(0)==2) )
    {
        if((n2++)%period==0)
        {
            Vector6f error;
            error=m_armInput.jointPos-m_armFeedBack.jointRealPos;
            bool isPrint=false;
            for (int i=0;i<m_armParam.dof;i++)
            {
                if (m_armParam.jointType(i)==0)
                {
                    if(fabs(error(i))>cmd.errorLImit(i)*DEG2RAD)
                    {
                        isPrint=true;
                    }
                }
                else
                {
                    if(fabs(error(i))>cmd.errorLImit(i))
                    {
                        isPrint=true;
                    }
                }
            }
            if(isPrint)
            {
                for (int i=0;i<m_armParam.dof;i++)
                {
                    if (m_armParam.jointType(i)==0)
                    {
                        error(i)=error(i)*RAD2DEG;
                    }
                    else
                    {
                        error(i)=error(i);
                    }
                }
                cout<<"motor error: "<<error.transpose()<<endl;
            }
            n2=1;
        }
    }

    //--print ToolError  ->  tool error xyzrpy(m,deg) [1*6]
    static int n3=1;
    period=cmd.Hz/cmd.printToolError(1);
    if( cmd.printToolError(0)!=0
            &&( cmd.mode!=STOP|| cmd.printToolError(0)==2) )
    {
        if((n3++)%period==0)
        {
            Vector6f error= GetToolPosError();
            cout<<"tool error xyzrpy(m,deg):" <<error(0)<<","<<error(1)<<","<<error(2)<<","
               <<RAD2DEG*error(3)<<","<<RAD2DEG*error(4)<<","<<RAD2DEG*error(5)<< endl;
            n3=1;
        }
    }

    //--print single JointInfo -> [jointi:e,pos,realpos;e,vel,realVel;I]
    static int n4=1;
    period=cmd.Hz/cmd.printJointInfo(1);
    if( cmd.printJointInfo(0)!=0
            &&( cmd.mode!=STOP|| cmd.printJointInfo(0)==2) )
    {
        if((n4++)%period==0)
        {
            int i=cmd.printJointInfo(2)-1;
            if(m_armParam.jointType(i)==0)
            {
                cout<<"joint(e,pos,realpos;e,vel,realVel;I) "<< i+1 <<": "
                   <<(m_armInput.jointPos(i)-m_armFeedBack.jointRealPos(i))*RAD2DEG<<","
                  <<m_armInput.jointPos(i)*RAD2DEG<<","<<m_armFeedBack.jointRealPos(i)*RAD2DEG<<"; "
                 <<(m_armInput.jointVel(i)-m_armFeedBack.jointRealVel(i))*RAD2DEG<<","
                <<m_armInput.jointVel(i)*RAD2DEG<<","<<m_armFeedBack.jointRealVel(i)*RAD2DEG<<"; "
                <<m_armFeedBack.jointCurrent(i)<<endl;
            }
            else
            {
                cout<<"joint(e,pos,realpos;e,vel,realVel;I) "<< i+1 <<": "
                   <<(m_armInput.jointPos(i)-m_armFeedBack.jointRealPos(i))<<","
                  <<m_armInput.jointPos(i)<<","<<m_armFeedBack.jointRealPos(i)<<"; "
                 <<(m_armInput.jointVel(i)-m_armFeedBack.jointRealVel(i))<<","
                <<m_armInput.jointVel(i)<<","<<m_armFeedBack.jointRealVel(i)<<"; "
                <<m_armFeedBack.jointCurrent(i)<<endl;
            }
            n4=1;
        }
    }

    //--print all jointInfo -> real pos[1*n] ,real vel[1*n] ,I[1*n]
    static int n5=1;
    period=cmd.Hz/cmd.printAllJointInfo(1);
    if( cmd.printAllJointInfo(0)!=0
            &&( cmd.mode!=STOP|| cmd.printAllJointInfo(0)==2) )
    {
        if((n5++)%period==0)
        {
            cout<<"real pos,real vel,I: "<<m_armFeedBack.jointRealPos.transpose()<<"; "
               <<m_armFeedBack.jointRealVel.transpose()<<"; "
              <<m_armFeedBack.jointCurrent.transpose() <<endl;
            n5=1;
        }
    }
}
bool MotionCtrl::EndPointCorrection(Vector3f *endPos,Vector3f *rpyEnd)
{
    //--end pos correction
    float ret=1;
    Vector6f endPoint1,endPoint2,jointPos;
    endPoint1<<endPos->coeffRef(0),endPos->coeffRef(1),endPos->coeffRef(2),
            rpyEnd->coeffRef(0),rpyEnd->coeffRef(1),rpyEnd->coeffRef(2);
    endPoint2<<0,0,0,endPoint1(3),endPoint1(4),endPoint1(5) ;

    int count=0;
    while(fabs(endPoint2(0)-endPoint1(0))>0.0005 ||
          fabs(endPoint2(1)-endPoint1(1))>0.0005 ||
          fabs(endPoint2(2)-endPoint1(2))>0.0005)
    {
        endPoint2.block<3,1>(0,0)=endPoint1.block<3,1>(0,0);
        ret=ArmIK(endPoint2,&jointPos);
        if(ret==0)
        {
            return 0;
        }
        //        jointPos(5)=Limit(jointPos(5),-90*pi/180,-0.5*pi/180);
        ArmPosCal(jointPos,&endPoint2);

        //change pos
        //        endPoint1<<endPos->coeffRef(0),endPos->coeffRef(1),endPos->coeffRef(2),
        //                endPoint2(3),endPoint2(4),endPoint2(5);

        if(count++>10)
        {
            cout<<"end point error..."<<count<<endl;
            break;
        }
    }
    cout<<"calculate times:"<<count<<endl;
    //-- return
    endPos->coeffRef(0)=endPoint2(0);
    endPos->coeffRef(1)=endPoint2(1);
    endPos->coeffRef(2)=endPoint2(2);
    rpyEnd->coeffRef(0)=endPoint2(3);
    rpyEnd->coeffRef(1)=endPoint2(4);
    rpyEnd->coeffRef(2)=endPoint2(5);

    return 1;
}


//--test
void MotionCtrl::LineMoveTest(Vector3f& pointA,Vector3f& pointB,Vector6f *goalAngle)
{
    //--note: pos -> int the {base}  ; rpy -> in the {tool}
    pointA<<-0.40, -0.20, 0.10;
    pointB<<-0.40,0.20,0.10 ;

    pointA<<-448.507, 0.800653, 98.5057;
    pointB<<-448.507, 0.800653, 98.5057;
    pointA=pointA/1000;
    pointB=pointB/1000;
    Vector6f output;
    Vector3f pos,rpy;
    rpy<<-0.0657918, 0.0253695, 15.9825;
    rpy=rpy*pi/180;
    for(int i=0;i<3;i++)
    {
        pos(i)=InterpCubicTraj(pointA(i),pointB(i),5, m_time.now/m_time.Hz);
    }

    ArmIK(rpy,pos,goalAngle);

    m_armFeedBack.jointPos=goalAngle->col(0);
    Vector6f tmp;
    ArmPosCal(m_armFeedBack.jointPos,&tmp);

    static bool reverse=0;
    if(reverse==0)
    {
        m_time.now++;
    }
    else
    {
        m_time.now--;
    }
    for(int i=0;i<m_armParam.dof;i++)
    {
        plot(m_time.now,output(i));
    }
    if(m_time.now>500)
    {
        reverse=1;
    }
    if(m_time.now<1)
    {
        reverse=0;
    }
}
void MotionCtrl::ImpedanceCtrlTest()
{
    Vector6f startJointPos,goalJointPos,interpJointPos;
    startJointPos<<0,0,0,0,0,0;
    goalJointPos<<-20,45,-90,90,0,0;
    goalJointPos=goalJointPos*pi/180;
    float time=3;
    for(int i=0;i<m_armParam.dof;i++)
    {
        interpJointPos(i)=InterpCubicTraj(startJointPos(i),goalJointPos(i),
                                          time,m_time.now);
    }
    TrajFollowByTorque(interpJointPos,1);
    //--time
    cmd.speed=1;
    if(m_time.now<=time) //reset
    {
        m_time.now+=cmd.speed*1.0F/m_time.Hz;
    }
}
void MotionCtrl::SplineTest()
{
    vector<float> X= {1,2,3,4,5,6,7,8,9,10,11};
    vector<float> Y= {-464,-514,-428,-342,-342,-342,-342,-342,-342,-428,-514};//4-8
    tk::spline s;
    static bool isFirst=1;
    if(isFirst)
    {
        s.set_boundary(tk::spline::first_deriv,0.0,tk::spline::first_deriv,0,false);
        s.set_points(X,Y);    // X needs to be sorted, strictly increasing
    }
    for (float i=1;i<1000;i++)
    {
        float t=i/100+1;
        float value=s(t);  // interpolated value at 1.5
        cout<<t<<","<<value<<endl;
    }
}

//--bottle catch test
bool MotionCtrl::CupCatchTrajGen(float deltaY,float deltaZ,float cupHeight)//h=0.11
{
    //cmd.speed=4;
    float tableH=-0.413,catchH=0.027;//0.17
    float h=catchH+tableH;//-0.396;

    //--calculate position
    Vector3f startPos,endPos;
    Vector3f rpyStart,rpyEnd;
    float thetaStart,thetaEnd;

    startPos<<h,0.2186,-0.3073;
    endPos<<h+cupHeight,startPos(1)+deltaY,startPos(2)+deltaZ;
    float deltaR=0;
    endPos=CalCatchPos(startPos,endPos,deltaR,&thetaStart,&thetaEnd);

    rpyStart<< -90*pi/180+thetaStart,0,90*pi/180;
    rpyEnd  << -90*pi/180+thetaEnd,0,90*pi/180;
    //--route traj
    Matrix<float,8,1> routeN;
    //routeN.col(0)<<LINE_NODE,2,startPos(0),startPos(1),startPos(2),
    //rpyStart(0),rpyStart(1),rpyStart(2);
    routeN.col(0)<<LINE_NODE,4,endPos(0),endPos(1) ,endPos(2),
            rpyEnd(0),rpyEnd(1),rpyEnd(2);

    //--convert to mm & degree
    for (int i=0;i<1;i++)
    {
        routeN(2,i)=routeN(2,i)*1000;
        routeN(3,i)=routeN(3,i)*1000;
        routeN(4,i)=routeN(4,i)*1000;
        routeN(5,i)=routeN(5,i)/pi*180;
        routeN(6,i)=routeN(6,i)/pi*180;
        routeN(7,i)=routeN(7,i)/pi*180;
    }

    //--copy to cmd
    cmd.route.clear();
    if (cmd.mode==ROUTE_MOVE|| cmd.mode==INTERRUPT)//when is running ,interrupt
    {
        cmd.mode=INTERRUPT;
    }
    else
    {
        cmd.mode=ROUTE_MOVE;
    }
    cmd.isUpdate=true;

    for (int i=0;i<1;i++)
    {
        ROUTE_NODE route;
        if(routeN(0,i)==0)
        {
            route.nodeType=LINE_NODE;
        }
        if(routeN(0,i)==1)
        {
            route.nodeType=WAIT_NODE;
        }
        if(routeN(0,i)==2)
        {
            route.nodeType=CIRCLE_NODE;
        }
        if(routeN(0,i)==3)
        {
            route.nodeType=S_NODE;
        }
        if(routeN(0,i)==4)
        {
            route.nodeType=J_NODE;
        }
        if(routeN(0,i)==5)
        {
            route.nodeType=ROT_NODE;
        }
        route.time=routeN(1,i);
        route.xPos=routeN(2,i);
        route.yPos=routeN(3,i);
        route.zPos=routeN(4,i);
        route.rxPos=routeN(5,i);
        route.ryPos=routeN(6,i);
        route.rzPos=routeN(7,i);

        cmd.route.push_back(route);

    }

    //    float ret=RouteMove();
    //    if (ret==0)
    //    {
    //        return 0;
    //    }

    return 1;
}

bool MotionCtrl::BottleCatchTrajGen(float deltaY,float deltaZ,float cupHeight)//h=0.115
{
    //cmd.speed=4;
    //float cupR=0.040,cupH=0.125,bottleR=0.036,bottleH=0.200,tableH=-0.585,catchH=0.108; //bottle1
    float cupR=0.040,cupH=0.125,bottleR=0.069/2,bottleH=0.148,tableH=-0.413,catchH=0.027; //bootle2
    float h=catchH+tableH;//-0.396;

    //--traj generate
    //endPos
    Vector3f startPos,endPos;
    Vector3f rpyStart,rpyEnd;
    float thetaStart,thetaEnd;

    startPos<<h,0.2186,-0.3073;
    endPos<<h+cupHeight,startPos(1)+deltaY,startPos(2)+deltaZ;
    float deltaR=cupR+bottleR+0.015;//0.12
    endPos=CalCatchPos(startPos,endPos,deltaR,&thetaStart,&thetaEnd);

    rpyStart<< -90*pi/180+thetaStart,0,90*pi/180;
    rpyEnd  << -90*pi/180+thetaEnd,0,90*pi/180;
    //--route traj
    Matrix<float,8,8> routeN;
    routeN.col(0)<<LINE_NODE,2,startPos(0),startPos(1),startPos(2),
            rpyStart(0),rpyStart(1),rpyStart(2);

    routeN.col(2)<<LINE_NODE,2,startPos(0),startPos(1),startPos(2),
            rpyStart(0),rpyStart(1),rpyStart(2);
    routeN.col(3)<<LINE_NODE,4,endPos(0),endPos(1) ,endPos(2),rpyEnd(0),rpyEnd(1),rpyEnd(2);
    routeN.col(4)<<ROT_NODE,8,endPos(0),endPos(1) ,endPos(2),0,100*pi/180,0;
    routeN.col(5)<<ROT_NODE,4,endPos(0),endPos(1) ,endPos(2),0,-60*pi/180,0;
    routeN.col(6)<<LINE_NODE,4,startPos(0),startPos(1),startPos(2),
            rpyStart(0),rpyStart(1),rpyStart(2);
    //--convert to mm & degree
    for (int i=0;i<8;i++)
    {
        routeN(2,i)=routeN(2,i)*1000;
        routeN(3,i)=routeN(3,i)*1000;
        routeN(4,i)=routeN(4,i)*1000;
        routeN(5,i)=routeN(5,i)/pi*180;
        routeN(6,i)=routeN(6,i)/pi*180;
        routeN(7,i)=routeN(7,i)/pi*180;
    }
    routeN.col(1)<<WAIT_NODE,2, 2,0,0,0,0,0; //hand hold
    routeN.col(7)<<WAIT_NODE,4, 1,0,0,0,0,0; //hand release
    //--copy to cmd.route
    cmd.route.clear();
    if (cmd.mode==ROUTE_MOVE || cmd.mode==INTERRUPT)//when is running ,interrupt
    {
        cmd.mode=INTERRUPT;
    }
    else
    {
        cmd.mode=ROUTE_MOVE;
    }
    cmd.isUpdate=true;

    for (int i=0;i<8;i++)
    {
        ROUTE_NODE route;
        if(routeN(0,i)==0)
        {
            route.nodeType=LINE_NODE;
        }
        if(routeN(0,i)==1)
        {
            route.nodeType=WAIT_NODE;
        }
        if(routeN(0,i)==2)
        {
            route.nodeType=CIRCLE_NODE;
        }
        if(routeN(0,i)==3)
        {
            route.nodeType=S_NODE;
        }
        if(routeN(0,i)==4)
        {
            route.nodeType=J_NODE;
        }
        if(routeN(0,i)==5)
        {
            route.nodeType=ROT_NODE;
        }
        route.time=routeN(1,i);
        route.xPos=routeN(2,i);
        route.yPos=routeN(3,i);
        route.zPos=routeN(4,i);
        route.rxPos=routeN(5,i);
        route.ryPos=routeN(6,i);
        route.rzPos=routeN(7,i);

        cmd.route.push_back(route);
    }

    //     float ret=RouteMove();
    //     if (ret==0)
    //     {
    //         return 0;
    //     }
    //        while(1)
    //        {
    //            UpdateRobotStatus(m_armInput.jointPos,m_armInput.jointPos,m_armInput.jointPos);
    //            ControlLoop();
    //    //        cout<<m_time.now<<": "<<m_armInput.jointPos.transpose()<<endl;
    //        }
    return 1;
}

Vector3f MotionCtrl::CalCatchPos(Vector3f &startPos,Vector3f &endPos,
                                 float deltaR,float* thetaStart,float* thetaEnd)
{
    float rBottlePos=sqrt(endPos(1)*endPos(1)+endPos(2)*endPos(2));
    float rEndArm=sqrt(rBottlePos*rBottlePos-deltaR*deltaR);
    (*thetaStart)=atan2(startPos(2),startPos(1));
    (*thetaEnd)=atan2(endPos(2),endPos(1))-acos(rEndArm/rBottlePos);

    endPos<<endPos(0),rEndArm*cos(*thetaEnd),rEndArm*sin(*thetaEnd);
    return endPos;
}

bool MotionCtrl::CircleInterrupt(float cycle,float nodeTime,float cupHeight)
{
    float count=0;
    Vector6f startPoint=m_armInput.toolPos;

    float Time=5;
    float Hz=1.0f/cycle;
    while((count++)/Hz<Time)
    {
        Matrix<float,8,1> routeN;
        float R=0.05;
        float deltaZ= R*cos(2*pi*count/Hz/Time);
        float deltaY= R*sin(2*pi*count/Hz/Time);
        routeN.col(0)<<LINE_NODE,nodeTime,startPoint(0),startPoint(1)+deltaY,startPoint(2)-R+deltaZ,
                startPoint(3),startPoint(4),startPoint(5);

        //--convert to mm & degree
        for (int i=0;i<1;i++)
        {
            routeN(2,i)=routeN(2,i)*1000;
            routeN(3,i)=routeN(3,i)*1000;
            routeN(4,i)=routeN(4,i)*1000;
            routeN(5,i)=routeN(5,i)/pi*180;
            routeN(6,i)=routeN(6,i)/pi*180;
            routeN(7,i)=routeN(7,i)/pi*180;
        }
        //--copy to cmd
        cmd.route.clear();
        if (cmd.mode==ROUTE_MOVE || cmd.mode==INTERRUPT)//when is running ,interrupt
        {
            cmd.mode=INTERRUPT;
        }
        else
        {
            cmd.mode=ROUTE_MOVE;
        }
        cmd.isUpdate=true;

        for (int i=0;i<1;i++)
        {
            ROUTE_NODE route;
            if(routeN(0,i)==0)
            {
                route.nodeType=LINE_NODE;
            }
            if(routeN(0,i)==1)
            {
                route.nodeType=WAIT_NODE;
            }
            if(routeN(0,i)==2)
            {
                route.nodeType=CIRCLE_NODE;
            }
            if(routeN(0,i)==3)
            {
                route.nodeType=S_NODE;
            }
            if(routeN(0,i)==4)
            {
                route.nodeType=J_NODE;
            }
            if(routeN(0,i)==5)
            {
                route.nodeType=ROT_NODE;
            }
            route.time=routeN(1,i);
            route.xPos=routeN(2,i);
            route.yPos=routeN(3,i);
            route.zPos=routeN(4,i);
            route.rxPos=routeN(5,i);
            route.ryPos=routeN(6,i);
            route.rzPos=routeN(7,i);

            cmd.route.push_back(route);
        }
        usleep(1000*1000/Hz);//50ms
    }
    return 1;
}


//--test
#include "stdlib.h"
#include "time.h"
int main_()
{
    MotionCtrl test;
    //test ArmDynamicDH & MCG
//    Vector6f q,qd,qdd;
//    q<<0.1312,1.7166-90.0*DEG2RAD,0.1458, 0.1458,0.1458,0;
//    qd<< 0.5154,0.5727,0.5727,0.5727, 0.5727,0;
//    qdd<< 1.3536,1.5040,1.5040,1.5040,1.5040,0;

//    Vector6f jointTorque=test.ArmDynamicDH(q,qd,qdd);

//    Matrix6_6f M;
//    Vector6f C,G,taoTheory;
//    M=test.MCG(q,qd,&C,&G);
//    taoTheory=M*qdd+C+G;

//    //--to test MCG & dynDH are right
//    cout<<"theory MCG/DynamicDH torque check:"<<endl;
//    cout<<taoTheory.transpose()<<endl;
//    cout<<jointTorque.transpose()<<endl;


    //--test bottle catch & range calculate
    //    cmd.speed=5;
    ////    test.BottleCatchTrajGen(0.2,0.3,0.115);

    //    float ret=0;
    //    for (float i=0;i<=0.375;i=i+0.05)
    //    {
    //        for(float j=0;j<=0.72;j+=0.05)
    //        {
    //            ret=test.BottleCatchTrajGen(i,j,0.115);
    ////            ret=test.CupCatchTrajGen(i,j,0);
    //            if(ret==1)
    //            {
    //                cout<<i<<","<<j<<endl;
    //            }
    //        }
    //    }



    while(1)
    {
        //         test.ImpedanceCtrlTest();


        //                SplineTest();



        //        Vector6f C,G;
        //        Matrix6_6f M;

        //        M=MCG(q2,qd,&C,&G);//ok
        //        out=M*q2+C+G;
        //        cout<<out.transpose()<<endl;

        //        Ctq(q2,qd,&out);//ok
        //        cout<<out.transpose()<<endl;

        //--collision detect
        //        Vector6f q,qd,qdd,out;
        //        Vector6f kj;
        //        kj<<1,1,1,1,1,1;
        //        static float t_=0,t=0;
        //        t_++;
        //        t=t_/100;
        //        if(t_>200)
        //        {
        //            break;
        //        }
        //        for(int i=0;i<6;i++)
        //        {
        //            float T=4; // 4s --> 360 degrees   T=2 max=2.05 ; T=4 max=0.272; T=5,max=0.14;T=6,max=0.02
        //            float k=2.0F/T;
        //            q(i)=1*sin(t*k*pi)*90/180*pi/kj(i);
        //            qd(i)=1*cos(t*k*pi)*90/180*pi*k*pi/kj(i);
        //            qdd(i)=1*1*-sin(t*k*pi)*90/180*pi*k*pi*k*pi/kj(i);
        //        }
        //        if(t_>100 && t_ <110)
        //        {
        //            Vector6f qerror,qderror;
        //            qerror<<0.0349,0.0349,0,0,0,0;
        //            qderror<<0.1745,0.1745,0,0,0,0;
        //            q=q+qerror;
        //            qd=qd+qderror;
        //        }
        ////         cout<<q (0)<<endl;
        //        test.m_armInput.jointPos=q;
        //        test.m_armInput.jointVel=qd;
        //        test.m_armInput.jointAcc=qdd;
        //        test.m_armFeedBack.jointRealPos=q;
        //        test.m_armFeedBack.jointVel=qd;
        //        test.CollisionDetect();

        //       test.ReadPoint();
        //-test Swing
        //        cmd.speed=25;
        //        Vector3f ps,pe,interp;
        //        ps<<0.0864687, 0.0799118, -0.421901;
        //        pe<<0.0964687, 0.0899118, -0.421901;
        //        test.Swing(ps,pe,0.03);

        //        static int i;
        //        if(i>25)
        //        {
        //            i=0;
        //        }
        //        i++;
        //        interp=SwingTraj(ps,pe,i,25,0.03);
        //        cout<<i<<endl;
        //        cout<<interp.transpose()<<endl;

        //--test LineMoveTest
        //        Vector3f a,b;
        //        Vector6f goal;
        //        test.LineMoveTest(a,b,&goal);

        //--test Log data
        //        Vector6f goalPos;
        //        int handMove;
        //        test.LogOutput(&goalPos,&handMove);

        //        int hand;
        //        Vector6f realJointPos,goal;
        //        realJointPos<<1,2,3,4,5,6;
        //        test.CopyMove(1,0,realJointPos,&hand,&goal);
        usleep(1000*10);
    }
    return 0;
}
