#include "robot_control/ArmCollisionDetect.h"
#include "robot_control/MoveCmd.h"
extern Move cmd;

CollisionDectect::CollisionDectect()
{
    CollisionInitiate();
}
CollisionDectect::~CollisionDectect()
{
}
void CollisionDectect::CollisionInitiate()
{
    cmd.isCollision=1;
    m_collision.isFirst=true;
    m_collision.isCollision=false;
    m_collision.cout=0;
    m_collision.initiateTime=50;
    m_collision.rMax<<0,0,0,0,0,0;
    m_collision.velLast<<0,0,0,0,0,0;
    m_collision.viP<<0,0,0,0,0,0;
    m_collision.voP=m_collision.viP;

    m_torqueLast<<0,0,0,0,0,0;
}
Vector6f CollisionDectect::FrictionCal(Vector6f &qd)
{
    Vector6f kf,kv;
    kf<<0,0,0,0,0,0;
    kv<<0,0,0,0,0,0;

    kf<<-114.4911,-3.1265,-0.96666,-2.505,-9.2267,0;
    kv<<2416.5678,-27.4782,4.3335,-2.1447,-131.3319,0;
    Vector6f friction;
    friction<<0,0,0, 0,0,0;
    for (int i=0; i<m_armParam.dof ;i++)
    {
        float v=0;
        if(fabs(qd(i))<0.0001)
        {
            v=0;
        }
        else
        {
            v=qd(i);
        }
        friction(i)=sign(v)*kf(i)+kv(i)*qd(i);
    }
    return friction;
}

void CollisionDectect::CollisionDetect()
{
    //--input
    Vector6f q,qd,qdd,qFeedback,qdFeedback,taoFeedback;
    q  =m_armInput.jointPos;
    qd =m_armInput.jointVel;
    qdd=m_armInput.jointAcc;
    qFeedback =m_armFeedBack.jointRealPos;
    qdFeedback=m_armFeedBack.jointRealVel;
    qdFeedback=VelLowFilter(0.1,qdFeedback);
    taoFeedback=Current2torque(m_armFeedBack.jointCurrent);//unit : Nm
    Vector6f taoFeedbackTmp=taoFeedback;

    if(1)//for arms with obvious joint pos control error , better  //optimized in 2021-6
    {
        taoFeedback=TorqueLowFilter(0.1,taoFeedback);
        qFeedback=q;
        qdFeedback=qd;
    }

    //--initiate
    static Vector6f r ,rLast, p ,pLast;
    if (m_collision.isFirst==true)
    {
        CollisionInitiate();
        r<<0 ,0, 0, 0, 0, 0;
        rLast<<0, 0, 0, 0 ,0 ,0;
        p<<0, 0 ,0 ,0 ,0, 0;
        pLast<<0 ,0 ,0, 0, 0, 0;

        m_collision.isFirst=false;
    }

    //--calculate MCG & Ctq
    Matrix6_6f M;
    Vector6f C,G,alpha;
    M=MCG(qFeedback,qdFeedback,&C,&G);
    p=M*qdFeedback;
    Ctq(qFeedback,qdFeedback,&alpha);

    //--Discretization
    float T=0.01f; //s
    float Ki=10000;
    r=1.0F/(1.0F+Ki*T)*rLast+Ki/(1.0F+Ki*T)*
            (p-pLast-(taoFeedback+alpha-G)*T);
    rLast=r;
    pLast=p;

    //--friction compensation
    Vector6f friction=FrictionCal(qdFeedback);
    if(cmd.collisionSet(2)==1)
    {
        r=r-friction;
    }

    //--print info
    if(cmd.mode!=STOP)
    {
        PrintCollisionError(r,q,qd,qdd,taoFeedback,
                            qdFeedback,friction);
    }
    //--print joint_i qd,tao filtered_data -> "jointi;qd,qdF;tao,taoF;r"
    static int n=1;
    if( cmd.printCollision(5)!=0 && cmd.mode!=STOP )
    {
        int period=cmd.Hz/cmd.printCollision(0);
        int i=cmd.printCollision(5)-1;
        if((n++)%period==0)
        {
            cout<<"joint;qdReal,qdFiter;taoReal,taoFiter;r: "<<i+1<<" ; "
               << m_armFeedBack.jointRealVel(i)<<","<<qdFeedback(i)
               <<" ; " <<taoFeedbackTmp(i)<<","<<taoFeedback(i)<<" ; "<<r(i)<<endl;
            n=1;
        }
    }

    //--HighPassFilterRC
    if(cmd.collisionSet(4)==1)
    {
        r=HighPassFilterRC(r,&m_collision.viP,&m_collision.voP,100,20);
    }

    //--collision decision
    if(m_collision.cout<m_collision.initiateTime)
    {
        m_collision.cout++;
    }
    else
    {
        PrintCollisionInfo(r);
        //m_collision.isCollision=cmd.isCollision; //for simulate test  whether the interrupt is valid
        Vector6f jointPosError=(m_armInput.jointPos-m_armFeedBack.jointRealPos)*RAD2DEG;
        jointPosError(0)=jointPosError(0)/RAD2DEG;
        bool isDetected=0;
        static int timesCount=0;
        for(int i=0;i<m_armParam.dof;i++)
        {
            if(fabs(r(i))>cmd.collisionLimit(i) && cmd.isSimulate==false
                    &&(cmd.collisionSet(4)==0 || cmd.collisionSet(4)==2 )  )
            {
                isDetected=true;

            }
            if(fabs(jointPosError(i))>cmd.collisionErrLimit(i) && cmd.isSimulate==false
                    &&(cmd.collisionSet(4)==1 || cmd.collisionSet(4)==2 ) )
            {
                m_collision.isCollision=true;
                cout<<"err ";
                break;
            }
        }
        if(isDetected==true)
        {
            timesCount++;
            if(timesCount>1)
            {
                m_collision.isCollision=true;
                cout<<"dyn ";
                timesCount=0;
            }
        }
        else
        {
            timesCount=0;
        }

        //--collision stop or suspend
        if(m_collision.isCollision)
        {
            cout<<clr::yellow;
            cout<<"collision detected :"<<m_collision.rMax.transpose()<<" ; "<<jointPosError.transpose()<<endl;
            cout<<clr::reset;
            m_armInput.jointPosLast=m_armInput.jointPos;//update lastJointPos to avoid outofspeed alert!
            if(cmd.collisionSet(0)==0)
            {
                cmd.mode=STOP;
            }
            if(cmd.collisionSet(0)==1)
            {
                cmd.mode=SUSPEND;
                cout<<"suspending ..."<<endl;
            }
            m_armState=COLLISION;
            CollisionInitiate();
        }
    }
}
void CollisionDectect::PrintCollisionError(Vector6f &r,Vector6f &q,Vector6f &qd,
                                            Vector6f &qdd,Vector6f &taoFeedback,
                                            Vector6f &qdFeedback,Vector6f &friction)
{
    //--print error(taoTheory-taoFeedback),r =[1*6,1*6]
    static int n1=1;
    if( cmd.printCollision(1)==1 )
    {
        int period=cmd.Hz/cmd.printCollision(0);
        if( (n1++)%period==0 )
        {
            Matrix6_6f M;
            Vector6f C,G,taoTheory;
            M=MCG(q,qd,&C,&G);
            taoTheory=M*qdd+C+G;
            m_armInput.jointTorque=ArmDynamicDH(q,qd,qdd);

            //--to test MCG & dynDH test right
            cout<<q.transpose()<<"; "<<qd.transpose()<<"; "<<qdd.transpose()<<endl;
            cout<<"theory MCG/DynamicDH torque check: "<<endl;
            cout<<taoTheory.transpose()<<endl;
            cout<<m_armInput.jointTorque.transpose()<<endl;

            //--to test error?=r ,when no collision, error~=0
            Vector6f errorTmp=taoTheory-taoFeedback;
            cout<<"error(taoTheory-taoFeedback),r: "<<errorTmp.transpose()<<" ; "
               <<r.transpose()<<endl;
            n1=1;
        }
    }

    //--for friction identification & check (matlab identification program)
    //--print friction identification data=[1*7]->[jointi,qd,qdFeedback,r,taoFeedback,taoTheory,friction]
    static int n2=0;
    if(cmd.printCollision(2)==1 &&
            m_collision.cout>=m_collision.initiateTime)
    {
        int period=cmd.Hz/cmd.printCollision(0);
        if( (n2++)%period==0 )
        {
            //cout<<m_collision.rMax.norm()<<";"<<m_collision.rMax.transpose()<<endl;
            Vector6f taoTheory=ArmDynamicDH(q,qd,qdd);
            for(int i=0;i<m_armParam.dof;i++)
            {
                if(cmd.jointVel(i)!=0)
                {
                    cout<<i+1<<" "<<qd(i)<<" "<<qdFeedback(i)<<" "<< r(i)<<" "<<taoFeedback(i)<<" "<<
                          taoTheory(i)<<" "<<friction(i)<<endl;
                }
            }
            n2=0;
        }
    }
}
void CollisionDectect::PrintCollisionInfo(Vector6f &r)
{
    //--print collision torque Max -> "norm(1*1);rMax(1*6)"
    bool isPrintf=false;
    for(int i=0;i<m_armParam.dof;i++)
    {
        if(fabs(m_collision.rMax(i))<fabs(r(i)))
        {
            m_collision.rMax(i)=fabs( r(i) );
            isPrintf=true;
        }
    }
    if(cmd.printCollision(3)==1  &&  isPrintf)
    {
        cout<<"collision torque Max: "<<m_collision.rMax.norm()<<";"<<m_collision.rMax.transpose()<<endl;
    }

    //--print collision torque ,to plot the collision curve -> "r(1*6);rMax(1*6)"
    static int n=1;
    if( cmd.printCollision(4)==1 )
    {
        int period=cmd.Hz/cmd.printCollision(0);
        if((n++)%period==0)
        {
            cout<<"r,rMax: "<< r.transpose()<<" ; " <<m_collision.rMax.transpose()<<endl;
            n=1;
        }
    }
}
Vector6f CollisionDectect::HighPassFilterRC(Vector6f &Vi,Vector6f *Vi_p,Vector6f *Vo_p,
                                            float sampleFrq,float CutFrq )
// out, in_previou, out_previous  =[in,in_previous,out_previous,Hz,cutHz]
{
    //high pass filter @cutoff frequency
    float Coff=1.0F/(1.0F+2.0F*pi*CutFrq/sampleFrq);
    Vector6f Vo = (Vi - (*Vi_p) +(*Vo_p) )*Coff ;

    Vo_p->col(0) = Vo;
    Vi_p->col(0) = Vi;
    return Vo;
}
Vector6f CollisionDectect::VelLowFilter(float kLowFilter,const Vector6f &in)
{
    Vector6f out;
    out = kLowFilter* in + (1.0F - kLowFilter) * m_collision.velLast;
    m_collision.velLast= out;
    return out;
}
Vector6f CollisionDectect::TorqueLowFilter(float kLowFilter,Vector6f &in)
{
    Vector6f out;
    out = kLowFilter* in + (1.0F - kLowFilter) * m_torqueLast;
    m_torqueLast= out;
    return out;
}
