#include "robot_control/HeadControl.h"

HeadControl::HeadControl()
{
}
HeadControl::~HeadControl()
{
}
HeadControl* HeadControl::GetPtr()
{
    static HeadControl head;
    return &head;
}
void HeadControl::Init(Matrix4f T_headBase2robotBase,
                       Matrix4f T_camera2headEnd)
{
    m_headTrans.T_headBase2robotBase=T_headBase2robotBase;
    m_headTrans.T_camera2headEnd=T_camera2headEnd;
}

Matrix4f HeadControl::GetT_camera2robotBase(float in[2])
{
    // 转动云台，计算相机对于机器人基座的关系
    Matrix4f T_headEnd2robotBase=HeadFK(in);
    Matrix4f T_camera2robotBase=T_headEnd2robotBase*m_headTrans.T_camera2headEnd;
    return T_camera2robotBase;
}

Matrix4f HeadControl::HeadFK(float in[2])
{
    //    float a1=0.035;  //V1
    //    float d1=-0.0445;
    //    float deltaX=0.12;
    //    float deltaY=-0.025;

    float a1=0.035;  //V2
    float d1=-0.0255;
    float deltaX=0.1075;
    float deltaY=0.0225;

    //--zero point trans
    float t1=-in[0]*DEG2RAD+pi/2;
    float t2=-in[1]*DEG2RAD+pi/2;

    //--calculate T_headEnd2robotBase
    Matrix4f T_headEnd2robotBase;

    m_headTrans.T_headEnd2headBase << cos(t1)*cos(t2), -cos(t1)*sin(t2), -sin(t1), a1*cos(t1)+deltaX,
            cos(t2)*sin(t1), -sin(t1)*sin(t2),  cos(t1), a1*sin(t1)+deltaY,
            -sin(t2),         -cos(t2),        0,         d1,
            0,                0,        0,          1;

    T_headEnd2robotBase=m_headTrans.T_headBase2robotBase*m_headTrans.T_headEnd2headBase;
    return T_headEnd2robotBase;
}



