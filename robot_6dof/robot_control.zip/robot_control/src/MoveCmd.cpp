#include "robot_control/MoveCmd.h"
#include "eigen_math/common_functions.h"
Move cmd;
armPosInfo dataShow;
mutex mut;

MoveCmd::MoveCmd()
{
    dataShow.armState=0;
    dataShow.headState=0;
    dataShow.handState=0;
    dataShow.wheelState=0;
}
MoveCmd::~MoveCmd()
{
}
void MoveCmd::PointMove(MOVE_DIRECTION direction, RPY_DIRECTION rpy,ACTION_TYPE action)
{
    if (action==ACTION_START)
    {
        cmd.mode=POINT_MOVE;
        switch (direction)
        {
        case MOVE_FRONT:
            cmd.toolVel(X)=+1*cmd.velMax(0)*cmd.speed;
            break;
        case MOVE_BACK:
            cmd.toolVel(X)=-1*cmd.velMax(0)*cmd.speed;
            break;
        case MOVE_RIGHT:
            cmd.toolVel(Y)=+1*cmd.velMax(0)*cmd.speed;
            break;
        case MOVE_LEFT:
            cmd.toolVel(Y)=-1*cmd.velMax(0)*cmd.speed;
            break;
        case MOVE_UP:
            cmd.toolVel(Z)=+1*cmd.velMax(0)*cmd.speed;
            break;
        case MOVE_DOWN:
            cmd.toolVel(Z)=-1*cmd.velMax(0)*cmd.speed;
            break;
        default:
            break;
        }
        switch (rpy)
        {
        case X_AXIS_RIGHT:
            cmd.toolVel(ROLL+3)=-1*cmd.velMax(1)*cmd.speed;
            break;
        case X_AXIS_LEFT:
            cmd.toolVel(ROLL+3)=+1*cmd.velMax(1)*cmd.speed;
            break;
        case Y_AXIS_RIGHT:
            cmd.toolVel(PIT+3)=+1*cmd.velMax(1)*cmd.speed;
            break;
        case Y_AXIS_LEFT:
            cmd.toolVel(PIT+3)=-1*cmd.velMax(1)*cmd.speed;
            break;
        case Z_AXIS_RIGHT:
            cmd.toolVel(YAW+3)=+1*cmd.velMax(1)*cmd.speed;
            break;
        case Z_AXIS_LEFT:
            cmd.toolVel(YAW+3)=-1*cmd.velMax(1)*cmd.speed;
            break;
        default:
            break;
        }
    }
    else
    {
        cmd.mode=SLOW_DOWN;
        cmd.toolVel<<0,0,0,0,0,0;
    }
}
void MoveCmd::JointMove(JOINT_PART_NAME jointName, CONTROL_DIRECTION control,ACTION_TYPE action)
{
    if (action==ACTION_START)
    {
        cmd.mode=JOINT_MOVE;
        //--direction
        int dir=0;
        if (control==REDUCE)
        {
            dir=-1;
        }
        if (control==INCREASE)
        {
            dir=+1;
        }
        //--joint
        switch (jointName)
        {
        case FOUNDATION:
            cmd.jointVel(0)=dir*cmd.speed;
            break;
        case SHOULDER:
            cmd.jointVel(1)=dir*cmd.speed;
            break;
        case ELBOW:
            cmd.jointVel(2)=dir*cmd.speed;
            break;
        case WRIST1:
            cmd.jointVel(3)=dir*cmd.speed;
            break;
        case WRIST2:
            cmd.jointVel(4)=dir*cmd.speed;
            break;
        case WRIST3:
            cmd.jointVel(5)=dir*cmd.speed;
            break;
        default:
            break;
        }
    }
    else
    {
        cmd.mode=SLOW_DOWN;
        cmd.jointVel<<0,0,0,0,0,0;
    }

}
void MoveCmd::SetSpeed(int speed)
{
    cmd.speed=float(speed)/100;
}
void MoveCmd::FreeDrive(ACTION_TYPE action)
{
    if (action==ACTION_START)
    {
        cmd.mode=FREE_DRIVE;
    }
    else
    {
        cmd.mode=STOP;
    }
}
void MoveCmd::HomingSet()
{
    cmd.mode=RETURN_ZERO;
}
void MoveCmd::CloseRobot()
{
    cmd.mode=CLOSE;
}
void MoveCmd::StartRobot()
{
    cmd.mode=START;
}

void MoveCmd::PlayRoute(std::vector<ROUTE_NODE> trajectoryList)
{
    cmd.route.clear();
    cmd.route.assign(trajectoryList.begin(), trajectoryList.end());
    if (cmd.mode==ROUTE_MOVE || cmd.mode==INTERRUPT)//when is running ,interrupt
    {
        cmd.mode=INTERRUPT;
        cout<<"set new route : INTERRUPT"<<endl;
    }
    else
    {
        cmd.mode=ROUTE_MOVE;
        cout<<"set new route : ROUTE_MOVE"<<endl;
    }
    cmd.isUpdate=true;
}
void MoveCmd::PlayStop()
{
    cmd.mode=STOP;
}
void MoveCmd::RobotModeSet(ROBOT_MODE mode)
{
    if (mode==SIMULATION_MODE)
    {
        cmd.isSimulate=true;
    }
    if (mode==REALROBOT_MODE)
    {
        cmd.isSimulate=false;
    }
}
CURRENT_POSITION MoveCmd::GetCurrentPosition( )
{
    float RAD2DEG= 57.2958;
    float m2mm=1000;
    CURRENT_POSITION position;
    position.xPos =dataShow.toolPos(0)*1000;
    position.yPos =dataShow.toolPos(1)*1000;
    position.zPos =dataShow.toolPos(2)*1000;
    position.rxPos=dataShow.toolPos(3)*RAD2DEG;
    position.ryPos=dataShow.toolPos(4)*RAD2DEG;
    position.rzPos=dataShow.toolPos(5)*RAD2DEG;

    position.foundAngle   =dataShow.jointPos(0)*m2mm;
    position.shoulderAngle=dataShow.jointPos(1)*RAD2DEG;
    position.elbowAngle   =dataShow.jointPos(2)*RAD2DEG;
    position.wrist1Angle  =dataShow.jointPos(3)*RAD2DEG;
    position.wrist2Angle  =dataShow.jointPos(4)*RAD2DEG;
    position.wrist3Angle  =dataShow.jointPos(5)*RAD2DEG;
    return position;
}
int MoveCmd::GetArmStatus()
{
   return dataShow.armState;
}
int MoveCmd::GetHeadStatus()
{
   return dataShow.headState;
}
int MoveCmd::GetHandStatus()
{
   return dataShow.handState;
}
int MoveCmd::GetWheelStatus()
{
   return dataShow.wheelState;
}
void MoveCmd::GetT_camera2armBase(float *rpyxyz)
{
     Vector6f out=tran2rpyxyz(dataShow.T_camera2robotBase);
     for(int i=0;i<6;i++)
     {
         rpyxyz[i]=out(i);
     }
}
