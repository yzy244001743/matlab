/*
 * File: getPinv.h
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 12-Jul-2019 14:24:18
 */

#ifndef GETPINV_H
#define GETPINV_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "getPinv_types.h"
#include "common_functions.h"
/* Function Declarations */
Matrix<float,6,6> getPinv(const Matrix<float,6,6> input);
void getPinv_initialize(void);
void getPinv_terminate(void);

#endif

/*
 * File trailer for getPinv.h
 *
 * [EOF]
 */
