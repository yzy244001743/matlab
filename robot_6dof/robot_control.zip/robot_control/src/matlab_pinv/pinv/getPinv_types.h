/*
 * File: getPinv_types.h
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 12-Jul-2019 14:24:18
 */

#ifndef GETPINV_TYPES_H
#define GETPINV_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for getPinv_types.h
 *
 * [EOF]
 */
