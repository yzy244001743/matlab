#include "robot_control/ArmBasics.h"

//float d2,d4,d_t ;

//float Ix1,Iy1,Iz1,Ix2,Iy2,Iz2,Ix3,Iy3,Iz3,Ix4,Iy4,Iz4,Ix5,Iy5,Iz5,Ix6,Iy6,Iz6 ;
//float px1,py1,pz1,px2,py2,pz2,px3,py3,pz3,px4,py4,pz4,px5,py5,pz5,px6,py6,pz6 ;

//d2=0.268;
//d4=0.330;

//Ix1=0.002613;
//Ix2=0.006628;
//Ix3=0.004031;
//Ix4=0.001487;
//Ix5=0.001169;
//Ix6=3.924e-5;

//Iy1=0.001658;
//Iy2=0.006496;
//Iy3=0.001003;
//Iy4=0.001415;
//Iy5=0.0002073;
//Iy6=4.846e-5;

//Iz1=0.002529;
//Iz2=0.001122;
//Iz3=0.004051;
//Iz4=0.0003572;
//Iz5=0.00113;
//Iz6=3.693e-5;

//px1= -0.0001805;
//py1=   0.008651;
//pz1=   -0.01747;
//px2=         0;
//py2= 0.0004085;
//pz2=   -0.1174;
//px3= -0.0001259;
//py3=    0.02253;
//pz3=   -0.00811;
//px4= -8.09e-5;
//py4= 0.002168;
//pz4= -0.09327;
//px5=  3.29e-5;
//py5=  0.05078;
//pz5= 0.004309;
//px6=  0.01619;
//py6= 2.242e-5;
//pz6=  0.02152;


Matrix6_6f ArmBasics::MCG(Vector6f &q,Vector6f &qd,Vector6f* Cq,Vector6f* Gf)
{
    float c1,c2,c3,c4,c5,c6,s1,s2,s3,s4,s5,s6;
    float t1,t2,t3,t4,t5,t6,dt1,dt2,dt3,dt4,dt5,dt6;
    float m1,m2,m3,m4,m5,m6 ;

    m1=m_armParam.mass(0);
    m2=m_armParam.mass(1);
    m3=m_armParam.mass(2);
    m4=m_armParam.mass(3);
    m5=m_armParam.mass(4);
    m6=m_armParam.mass(5);
    float a1=m_armParam.dhParam(0);
    float a2=m_armParam.dhParam(1);
    float a3=m_armParam.dhParam(2);
    float a4=m_armParam.dhParam(3);

    Vector6f qZero;
    qZero<<0,pi/2,0,0,0,0;//MDH offset
    t1=q(0);
    t2=q(1)+qZero(1);
    t3=q(2);
    t4=q(3);
    t5=q(4);
    t6=q(5);

    dt1=qd(0);
    dt2=qd(1);
    dt3=qd(2);
    dt4=qd(3);
    dt5=qd(4);
    dt6=qd(5);

    s1=sin(t1);
    s2=sin(t2);
    s3=sin(t3);
    s4=sin(t4);
    s5=sin(t5);
    s6=sin(t6);

    c1=cos(t1);
    c2=cos(t2);
    c3=cos(t3);
    c4=cos(t4);
    c5=cos(t5);
    c6=cos(t6);

    Matrix6_6f M;
    Vector6f C,G;
    //--
    M(0,0)=m1 + m2 + m3 + m4 + m5;
    M(0,1)=0.0;
    M(0,2)=0.0;
    M(0,3)=0.0;
    M(0,4)=-1.0*a4*c5*m5;
    M(1,0)=0.0;
    M(1,1)=+ 0.0197*c2*c2*m2 + 0.0197*m2*s2*s2 + 0.0105*c2*c2 + 0.0105*s2*s2 + a1*a1*c2*c2*m2 + a1*a1*c2*c2*m3 + a1*a1*c2*c2*m4 + a1*a1*c2*c2*m5 + 0.0216*c2*c2*c3*c3*m3
    + a1*a1*m2*s2*s2 + a1*a1*m3*s2*s2 + a1*a1*m4*s2*s2 + a1*a1*m5*s2*s2 + 0.0216*c2*c2*m3*s3*s3 + 0.0216*c3*c3*m3*s2*s2 + 0.0216*m3*s2*s2*s3*s3 + 0.281*a1*c2*c2*m2 + 0.281*a1*m2*s2*s2 + a2*a2*c2*c2*c3*c3*m3
    + a2*a2*c2*c2*c3*c3*m4 + a2*a2*c2*c2*c3*c3*m5 + 0.0158*c2*c2*c3*c3*c4*c4*m4 + a2*a2*c2*c2*m3*s3*s3 + a2*a2*c3*c3*m3*s2*s2 + a2*a2*c2*c2*m4*s3*s3 + a2*a2*c3*c3*m4*s2*s2 + a2*a2*c2*c2*m5*s3*s3 + a2*a2*c3*c3*m5*s2*s2 + 0.0158*c2*c2*c3*c3*m4*s4*s4
    + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + a2*a2*m3*s2*s2*s3*s3 + a2*a2*m4*s2*s2*s3*s3 + a2*a2*m5*s2*s2*s3*s3 + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3
    + 0.0158*m4*s2*s2*s3*s3*s4*s4 + 0.294*a1*c2*c2*c3*m3 + 0.294*a1*c3*m3*s2*s2 + 0.294*a2*c2*c2*c3*c3*m3 + 0.294*a2*c2*c2*m3*s3*s3 + 0.294*a2*c3*c3*m3*s2*s2
    + 0.294*a2*m3*s2*s2*s3*s3 + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.252*a2*c2*c2*c3*c3*c4*m4 + 0.252*a2*c2*c2*c4*m4*s3*s3 + 0.0102*a2*c2*c2*c3*c3*m4*s4 + 0.252*a2*c3*c3*c4*m4*s2*s2 + 0.252*a2*c4*m4*s2*s2*s3*s3
    + 0.0102*a2*c2*c2*m4*s3*s3*s4 + 0.0102*a2*c3*c3*m4*s2*s2*s4 + 0.0102*a2*m4*s2*s2*s3*s3*s4 + 0.252*a3*c2*c2*c3*c3*c4*c4*m4 + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2
    + 0.252*a3*c2*c2*m4*s3*s3*s4*s4 + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4 + 2.0*a1*a2*c2*c2*c3*m3 + 2.0*a1*a2*c2*c2*c3*m4 + 2.0*a1*a2*c2*c2*c3*m5
    + 0.252*a1*c2*c2*c3*c4*m4 + 2.0*a1*a2*c3*m3*s2*s2 + 2.0*a1*a2*c3*m4*s2*s2 + 2.0*a1*a2*c3*m5*s2*s2 + 0.252*a1*c3*c4*m4*s2*s2 + 0.0102*a1*c2*c2*c3*m4*s4 + 0.0102*a1*c2*c2*c4*m4*s3 + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5
    + 0.0102*a1*c3*m4*s2*s2*s4 + 0.0102*a1*c4*m4*s2*s2*s3 - 0.252*a1*c2*c2*m4*s3*s4 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3 + a3*a3*c3*c3*c4*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3
    + a3*a3*c3*c3*c4*c4*m5*s2*s2 - 0.252*a1*m4*s2*s2*s3*s4 + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3 + a3*a3*c2*c2*m5*s3*s3*s4*s4 + a3*a3*c3*c3*m5*s2*s2*s4*s4 + a3*a3*c4*c4*m5*s2*s2*s3*s3
    + 2.0*a1*a3*c2*c2*c3*c4*m4 + 2.0*a1*a3*c2*c2*c3*c4*m5 + 2.0*a1*a3*c3*c4*m4*s2*s2 + 2.0*a1*a3*c3*c4*m5*s2*s2 - 2.0*a1*a3*c2*c2*m4*s3*s4 - 2.0*a1*a3*c2*c2*m5*s3*s4 - 2.0*a1*a3*m4*s2*s2*s3*s4
    - 2.0*a1*a3*m5*s2*s2*s3*s4 + 2.0*a2*a3*c2*c2*c3*c3*c4*m4 + 2.0*a2*a3*c2*c2*c3*c3*c4*m5 + 2.0*a2*a3*c2*c2*c4*m4*s3*s3 + 2.0*a2*a3*c3*c3*c4*m4*s2*s2 + 2.0*a2*a3*c2*c2*c4*m5*s3*s3 + 2.0*a2*a3*c3*c3*c4*m5*s2*s2 + 2.0*a2*a3*c4*m4*s2*s2*s3*s3
    + 2.0*a2*a3*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5 + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4 + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2 + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4
    + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4 + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3 + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3 + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2
    + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4 + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3 + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a1*a4*c2*c2*c3*c4*c5*m5 + 2.0*a1*a4*c3*c4*c5*m5*s2*s2
    - 2.0*a1*a4*c2*c2*c5*m5*s3*s4 - 2.0*a1*a4*c5*m5*s2*s2*s3*s4 + 2.0*a2*a4*c2*c2*c3*c3*c4*c5*m5 + 2.0*a2*a4*c2*c2*c4*c5*m5*s3*s3 + 2.0*a2*a4*c3*c3*c4*c5*m5*s2*s2 + 2.0*a2*a4*c4*c5*m5*s2*s2*s3*s3
    ;
    M(1,2)=+ 0.0216*c2*c2*c3*c3*m3 + 0.0216*c2*c2*m3*s3*s3 + 0.0216*c3*c3*m3*s2*s2 + 0.0216*m3*s2*s2*s3*s3 + a2*a2*c2*c2*c3*c3*m3 + a2*a2*c2*c2*c3*c3*m4 + a2*a2*c2*c2*c3*c3*m5 + 0.0158*c2*c2*c3*c3*c4*c4*m4 + a2*a2*c2*c2*m3*s3*s3 + a2*a2*c3*c3*m3*s2*s2 + a2*a2*c2*c2*m4*s3*s3
    + a2*a2*c3*c3*m4*s2*s2 + a2*a2*c2*c2*m5*s3*s3 + a2*a2*c3*c3*m5*s2*s2 + 0.0158*c2*c2*c3*c3*m4*s4*s4 + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + a2*a2*m3*s2*s2*s3*s3 + a2*a2*m4*s2*s2*s3*s3 + a2*a2*m5*s2*s2*s3*s3
    + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3 + 0.0158*m4*s2*s2*s3*s3*s4*s4 + 0.147*a1*c2*c2*c3*m3 + 0.147*a1*c3*m3*s2*s2
    + 0.294*a2*c2*c2*c3*c3*m3 + 0.294*a2*c2*c2*m3*s3*s3 + 0.294*a2*c3*c3*m3*s2*s2 + 0.294*a2*m3*s2*s2*s3*s3 + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.252*a2*c2*c2*c3*c3*c4*m4 + 0.252*a2*c2*c2*c4*m4*s3*s3
    + 0.0102*a2*c2*c2*c3*c3*m4*s4 + 0.252*a2*c3*c3*c4*m4*s2*s2 + 0.252*a2*c4*m4*s2*s2*s3*s3 + 0.0102*a2*c2*c2*m4*s3*s3*s4 + 0.0102*a2*c3*c3*m4*s2*s2*s4 + 0.0102*a2*m4*s2*s2*s3*s3*s4 + 0.252*a3*c2*c2*c3*c3*c4*c4*m4
    + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2 + 0.252*a3*c2*c2*m4*s3*s3*s4*s4 + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4
    + a1*a2*c2*c2*c3*m3 + a1*a2*c2*c2*c3*m4 + a1*a2*c2*c2*c3*m5 + 0.126*a1*c2*c2*c3*c4*m4 + a1*a2*c3*m3*s2*s2 + a1*a2*c3*m4*s2*s2 + a1*a2*c3*m5*s2*s2 + 0.126*a1*c3*c4*m4*s2*s2
    + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5 - 0.126*a1*c2*c2*m4*s3*s4 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3 + a3*a3*c3*c3*c4*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3 + a3*a3*c3*c3*c4*c4*m5*s2*s2
    - 0.126*a1*m4*s2*s2*s3*s4 + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3 + a3*a3*c2*c2*m5*s3*s3*s4*s4 + a3*a3*c3*c3*m5*s2*s2*s4*s4 + a3*a3*c4*c4*m5*s2*s2*s3*s3 + a1*a3*c2*c2*c3*c4*m4
    + a1*a3*c2*c2*c3*c4*m5 + a1*a3*c3*c4*m4*s2*s2 + a1*a3*c3*c4*m5*s2*s2 - 1.0*a1*a3*c2*c2*m4*s3*s4 - 1.0*a1*a3*c2*c2*m5*s3*s4 - 1.0*a1*a3*m4*s2*s2*s3*s4 - 1.0*a1*a3*m5*s2*s2*s3*s4 + 2.0*a2*a3*c2*c2*c3*c3*c4*m4
    + 2.0*a2*a3*c2*c2*c3*c3*c4*m5 + 2.0*a2*a3*c2*c2*c4*m4*s3*s3 + 2.0*a2*a3*c3*c3*c4*m4*s2*s2 + 2.0*a2*a3*c2*c2*c4*m5*s3*s3 + 2.0*a2*a3*c3*c3*c4*m5*s2*s2 + 2.0*a2*a3*c4*m4*s2*s2*s3*s3 + 2.0*a2*a3*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5
    + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4 + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2 + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4 + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4 + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3
    + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3 + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2 + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4
    + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3 + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4 + a1*a4*c2*c2*c3*c4*c5*m5 + a1*a4*c3*c4*c5*m5*s2*s2 - 1.0*a1*a4*c2*c2*c5*m5*s3*s4 - 1.0*a1*a4*c5*m5*s2*s2*s3*s4
    + 2.0*a2*a4*c2*c2*c3*c3*c4*c5*m5 + 2.0*a2*a4*c2*c2*c4*c5*m5*s3*s3 + 2.0*a2*a4*c3*c3*c4*c5*m5*s2*s2 + 2.0*a2*a4*c4*c5*m5*s2*s2*s3*s3;
    M(1,3)=+ 0.0158*c2*c2*c3*c3*c4*c4*m4 + 0.0158*c2*c2*c3*c3*m4*s4*s4 + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3 + 0.0158*m4*s2*s2*s3*s3*s4*s4
    + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.126*a2*c2*c2*c3*c3*c4*m4 + 0.126*a2*c2*c2*c4*m4*s3*s3 + 0.126*a2*c3*c3*c4*m4*s2*s2 + 0.126*a2*c4*m4*s2*s2*s3*s3
    + 0.252*a3*c2*c2*c3*c3*c4*c4*m4 + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2 + 0.252*a3*c2*c2*m4*s3*s3*s4*s4 + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4
    + 0.126*a1*c2*c2*c3*c4*m4 + 0.126*a1*c3*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5 - 0.126*a1*c2*c2*m4*s3*s4 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3
    + a3*a3*c3*c3*c4*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3 + a3*a3*c3*c3*c4*c4*m5*s2*s2 - 0.126*a1*m4*s2*s2*s3*s4 + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3
    + a3*a3*c2*c2*m5*s3*s3*s4*s4 + a3*a3*c3*c3*m5*s2*s2*s4*s4 + a3*a3*c4*c4*m5*s2*s2*s3*s3 + a1*a3*c2*c2*c3*c4*m4 + a1*a3*c2*c2*c3*c4*m5 + a1*a3*c3*c4*m4*s2*s2 + a1*a3*c3*c4*m5*s2*s2 - 1.0*a1*a3*c2*c2*m4*s3*s4 - 1.0*a1*a3*c2*c2*m5*s3*s4
    - 1.0*a1*a3*m4*s2*s2*s3*s4 - 1.0*a1*a3*m5*s2*s2*s3*s4 + a2*a3*c2*c2*c3*c3*c4*m4 + a2*a3*c2*c2*c3*c3*c4*m5 + a2*a3*c2*c2*c4*m4*s3*s3 + a2*a3*c3*c3*c4*m4*s2*s2 + a2*a3*c2*c2*c4*m5*s3*s3 + a2*a3*c3*c3*c4*m5*s2*s2
    + a2*a3*c4*m4*s2*s2*s3*s3 + a2*a3*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5 + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4 + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2 + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4
    + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4 + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3 + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3
    + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2 + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4 + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3 + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4 + a1*a4*c2*c2*c3*c4*c5*m5 + a1*a4*c3*c4*c5*m5*s2*s2
    - 1.0*a1*a4*c2*c2*c5*m5*s3*s4 - 1.0*a1*a4*c5*m5*s2*s2*s3*s4 + a2*a4*c2*c2*c3*c3*c4*c5*m5 + a2*a4*c2*c2*c4*c5*m5*s3*s3 + a2*a4*c3*c3*c4*c5*m5*s2*s2 + a2*a4*c4*c5*m5*s2*s2*s3*s3
    ;
    M(1,4)=- 1.0*a2*a4*c2*c2*m5*s3*s3*s4*s5 - 1.0*a2*a4*c3*c3*m5*s2*s2*s4*s5 - 1.0*a2*a4*m5*s2*s2*s3*s3*s4*s5 - 1.0*a1*a4*c2*c2*c3*m5*s4*s5 - 1.0*a1*a4*c2*c2*c4*m5*s3*s5 - 1.0*a1*a4*c3*m5*s2*s2*s4*s5 - 1.0*a1*a4*c4*m5*s2*s2*s3*s5
    - 1.0*a2*a4*c2*c2*c3*c3*m5*s4*s5;
    M(2,0)=0.0;
    M(2,1)=+ 0.0216*c2*c2*c3*c3*m3 + 0.0216*c2*c2*m3*s3*s3 + 0.0216*c3*c3*m3*s2*s2 + 0.0216*m3*s2*s2*s3*s3 + a2*a2*c2*c2*c3*c3*m3 + a2*a2*c2*c2*c3*c3*m4 + a2*a2*c2*c2*c3*c3*m5 + 0.0158*c2*c2*c3*c3*c4*c4*m4 + a2*a2*c2*c2*m3*s3*s3 + a2*a2*c3*c3*m3*s2*s2 + a2*a2*c2*c2*m4*s3*s3
    + a2*a2*c3*c3*m4*s2*s2 + a2*a2*c2*c2*m5*s3*s3 + a2*a2*c3*c3*m5*s2*s2 + 0.0158*c2*c2*c3*c3*m4*s4*s4 + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + a2*a2*m3*s2*s2*s3*s3 + a2*a2*m4*s2*s2*s3*s3 + a2*a2*m5*s2*s2*s3*s3
    + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3 + 0.0158*m4*s2*s2*s3*s3*s4*s4 + 0.147*a1*c2*c2*c3*m3 + 0.147*a1*c3*m3*s2*s2
    + 0.294*a2*c2*c2*c3*c3*m3 + 0.294*a2*c2*c2*m3*s3*s3 + 0.294*a2*c3*c3*m3*s2*s2 + 0.294*a2*m3*s2*s2*s3*s3 + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.252*a2*c2*c2*c3*c3*c4*m4 + 0.252*a2*c2*c2*c4*m4*s3*s3
    + 0.0102*a2*c2*c2*c3*c3*m4*s4 + 0.252*a2*c3*c3*c4*m4*s2*s2 + 0.252*a2*c4*m4*s2*s2*s3*s3 + 0.0102*a2*c2*c2*m4*s3*s3*s4 + 0.0102*a2*c3*c3*m4*s2*s2*s4 + 0.0102*a2*m4*s2*s2*s3*s3*s4 + 0.252*a3*c2*c2*c3*c3*c4*c4*m4
    + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2 + 0.252*a3*c2*c2*m4*s3*s3*s4*s4 + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4
    + a1*a2*c2*c2*c3*m3 + a1*a2*c2*c2*c3*m4 + a1*a2*c2*c2*c3*m5 + 0.126*a1*c2*c2*c3*c4*m4 + a1*a2*c3*m3*s2*s2 + a1*a2*c3*m4*s2*s2 + a1*a2*c3*m5*s2*s2 + 0.126*a1*c3*c4*m4*s2*s2
    + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5 - 0.126*a1*c2*c2*m4*s3*s4 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3 + a3*a3*c3*c3*c4*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3 + a3*a3*c3*c3*c4*c4*m5*s2*s2
    - 0.126*a1*m4*s2*s2*s3*s4 + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3 + a3*a3*c2*c2*m5*s3*s3*s4*s4 + a3*a3*c3*c3*m5*s2*s2*s4*s4 + a3*a3*c4*c4*m5*s2*s2*s3*s3 + a1*a3*c2*c2*c3*c4*m4
    + a1*a3*c2*c2*c3*c4*m5 + a1*a3*c3*c4*m4*s2*s2 + a1*a3*c3*c4*m5*s2*s2 - 1.0*a1*a3*c2*c2*m4*s3*s4 - 1.0*a1*a3*c2*c2*m5*s3*s4 - 1.0*a1*a3*m4*s2*s2*s3*s4 - 1.0*a1*a3*m5*s2*s2*s3*s4 + 2.0*a2*a3*c2*c2*c3*c3*c4*m4
    + 2.0*a2*a3*c2*c2*c3*c3*c4*m5 + 2.0*a2*a3*c2*c2*c4*m4*s3*s3 + 2.0*a2*a3*c3*c3*c4*m4*s2*s2 + 2.0*a2*a3*c2*c2*c4*m5*s3*s3 + 2.0*a2*a3*c3*c3*c4*m5*s2*s2 + 2.0*a2*a3*c4*m4*s2*s2*s3*s3 + 2.0*a2*a3*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5
    + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4 + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2 + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4 + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4 + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3
    + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3 + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2 + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4
    + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3 + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4 + a1*a4*c2*c2*c3*c4*c5*m5 + a1*a4*c3*c4*c5*m5*s2*s2 - 1.0*a1*a4*c2*c2*c5*m5*s3*s4 - 1.0*a1*a4*c5*m5*s2*s2*s3*s4
    + 2.0*a2*a4*c2*c2*c3*c3*c4*c5*m5 + 2.0*a2*a4*c2*c2*c4*c5*m5*s3*s3 + 2.0*a2*a4*c3*c3*c4*c5*m5*s2*s2 + 2.0*a2*a4*c4*c5*m5*s2*s2*s3*s3;
    M(2,2)=+ 0.0216*c2*c2*c3*c3*m3 + 0.0216*c2*c2*m3*s3*s3 + 0.0216*c3*c3*m3*s2*s2 + 0.0216*m3*s2*s2*s3*s3 + a2*a2*c2*c2*c3*c3*m3 + a2*a2*c2*c2*c3*c3*m4 + a2*a2*c2*c2*c3*c3*m5 + 0.0158*c2*c2*c3*c3*c4*c4*m4 + a2*a2*c2*c2*m3*s3*s3 + a2*a2*c3*c3*m3*s2*s2 + a2*a2*c2*c2*m4*s3*s3
    + a2*a2*c3*c3*m4*s2*s2 + a2*a2*c2*c2*m5*s3*s3 + a2*a2*c3*c3*m5*s2*s2 + 0.0158*c2*c2*c3*c3*m4*s4*s4 + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + a2*a2*m3*s2*s2*s3*s3 + a2*a2*m4*s2*s2*s3*s3 + a2*a2*m5*s2*s2*s3*s3
    + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3 + 0.0158*m4*s2*s2*s3*s3*s4*s4 + 0.294*a2*c2*c2*c3*c3*m3 + 0.294*a2*c2*c2*m3*s3*s3 + 0.294*a2*c3*c3*m3*s2*s2 + 0.294*a2*m3*s2*s2*s3*s3
    + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.252*a2*c2*c2*c3*c3*c4*m4 + 0.252*a2*c2*c2*c4*m4*s3*s3 + 0.0102*a2*c2*c2*c3*c3*m4*s4 + 0.252*a2*c3*c3*c4*m4*s2*s2 + 0.252*a2*c4*m4*s2*s2*s3*s3
    + 0.0102*a2*c2*c2*m4*s3*s3*s4 + 0.0102*a2*c3*c3*m4*s2*s2*s4 + 0.0102*a2*m4*s2*s2*s3*s3*s4 + 0.252*a3*c2*c2*c3*c3*c4*c4*m4 + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2
    + 0.252*a3*c2*c2*m4*s3*s3*s4*s4 + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3
    + a3*a3*c3*c3*c4*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3 + a3*a3*c3*c3*c4*c4*m5*s2*s2 + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3 + a3*a3*c2*c2*m5*s3*s3*s4*s4
    + a3*a3*c3*c3*m5*s2*s2*s4*s4 + a3*a3*c4*c4*m5*s2*s2*s3*s3 + 2.0*a2*a3*c2*c2*c3*c3*c4*m4 + 2.0*a2*a3*c2*c2*c3*c3*c4*m5 + 2.0*a2*a3*c2*c2*c4*m4*s3*s3 + 2.0*a2*a3*c3*c3*c4*m4*s2*s2 + 2.0*a2*a3*c2*c2*c4*m5*s3*s3
    + 2.0*a2*a3*c3*c3*c4*m5*s2*s2 + 2.0*a2*a3*c4*m4*s2*s2*s3*s3 + 2.0*a2*a3*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5 + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4 + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2
    + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4 + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4 + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3 + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3
    + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2 + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4 + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3 + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a2*a4*c2*c2*c3*c3*c4*c5*m5
    + 2.0*a2*a4*c2*c2*c4*c5*m5*s3*s3 + 2.0*a2*a4*c3*c3*c4*c5*m5*s2*s2 + 2.0*a2*a4*c4*c5*m5*s2*s2*s3*s3;
    M(2,3)=+ 0.0158*c2*c2*c3*c3*c4*c4*m4 + 0.0158*c2*c2*c3*c3*m4*s4*s4 + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3 + 0.0158*m4*s2*s2*s3*s3*s4*s4
    + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.126*a2*c2*c2*c3*c3*c4*m4 + 0.126*a2*c2*c2*c4*m4*s3*s3 + 0.126*a2*c3*c3*c4*m4*s2*s2 + 0.126*a2*c4*m4*s2*s2*s3*s3
    + 0.252*a3*c2*c2*c3*c3*c4*c4*m4 + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2 + 0.252*a3*c2*c2*m4*s3*s3*s4*s4 + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4
    + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3 + a3*a3*c3*c3*c4*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3 + a3*a3*c3*c3*c4*c4*m5*s2*s2
    + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3 + a3*a3*c2*c2*m5*s3*s3*s4*s4 + a3*a3*c3*c3*m5*s2*s2*s4*s4 + a3*a3*c4*c4*m5*s2*s2*s3*s3 + a2*a3*c2*c2*c3*c3*c4*m4 + a2*a3*c2*c2*c3*c3*c4*m5
    + a2*a3*c2*c2*c4*m4*s3*s3 + a2*a3*c3*c3*c4*m4*s2*s2 + a2*a3*c2*c2*c4*m5*s3*s3 + a2*a3*c3*c3*c4*m5*s2*s2 + a2*a3*c4*m4*s2*s2*s3*s3 + a2*a3*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5 + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4
    + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2 + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4 + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4 + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3 + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4
    + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3 + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2 + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4 + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3
    + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4 + a2*a4*c2*c2*c3*c3*c4*c5*m5 + a2*a4*c2*c2*c4*c5*m5*s3*s3 + a2*a4*c3*c3*c4*c5*m5*s2*s2 + a2*a4*c4*c5*m5*s2*s2*s3*s3
    ;
    M(2,4)=- 1.0*a2*a4*c2*c2*m5*s3*s3*s4*s5 - 1.0*a2*a4*c3*c3*m5*s2*s2*s4*s5 - 1.0*a2*a4*m5*s2*s2*s3*s3*s4*s5 - 1.0*a2*a4*c2*c2*c3*c3*m5*s4*s5;
    M(3,0)=0.0;
    M(3,1)=+ 0.0158*c2*c2*c3*c3*c4*c4*m4 + 0.0158*c2*c2*c3*c3*m4*s4*s4 + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3 + 0.0158*m4*s2*s2*s3*s3*s4*s4
    + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.126*a2*c2*c2*c3*c3*c4*m4 + 0.126*a2*c2*c2*c4*m4*s3*s3 + 0.126*a2*c3*c3*c4*m4*s2*s2 + 0.126*a2*c4*m4*s2*s2*s3*s3
    + 0.252*a3*c2*c2*c3*c3*c4*c4*m4 + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2 + 0.252*a3*c2*c2*m4*s3*s3*s4*s4 + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4
    + 0.126*a1*c2*c2*c3*c4*m4 + 0.126*a1*c3*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5 - 0.126*a1*c2*c2*m4*s3*s4 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3
    + a3*a3*c3*c3*c4*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3 + a3*a3*c3*c3*c4*c4*m5*s2*s2 - 0.126*a1*m4*s2*s2*s3*s4 + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3
    + a3*a3*c2*c2*m5*s3*s3*s4*s4 + a3*a3*c3*c3*m5*s2*s2*s4*s4 + a3*a3*c4*c4*m5*s2*s2*s3*s3 + a1*a3*c2*c2*c3*c4*m4 + a1*a3*c2*c2*c3*c4*m5 + a1*a3*c3*c4*m4*s2*s2 + a1*a3*c3*c4*m5*s2*s2 - 1.0*a1*a3*c2*c2*m4*s3*s4 - 1.0*a1*a3*c2*c2*m5*s3*s4
    - 1.0*a1*a3*m4*s2*s2*s3*s4 - 1.0*a1*a3*m5*s2*s2*s3*s4 + a2*a3*c2*c2*c3*c3*c4*m4 + a2*a3*c2*c2*c3*c3*c4*m5 + a2*a3*c2*c2*c4*m4*s3*s3 + a2*a3*c3*c3*c4*m4*s2*s2 + a2*a3*c2*c2*c4*m5*s3*s3 + a2*a3*c3*c3*c4*m5*s2*s2
    + a2*a3*c4*m4*s2*s2*s3*s3 + a2*a3*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5 + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4 + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2 + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4
    + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4 + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3 + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3
    + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2 + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4 + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3 + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4 + a1*a4*c2*c2*c3*c4*c5*m5 + a1*a4*c3*c4*c5*m5*s2*s2
    - 1.0*a1*a4*c2*c2*c5*m5*s3*s4 - 1.0*a1*a4*c5*m5*s2*s2*s3*s4 + a2*a4*c2*c2*c3*c3*c4*c5*m5 + a2*a4*c2*c2*c4*c5*m5*s3*s3 + a2*a4*c3*c3*c4*c5*m5*s2*s2 + a2*a4*c4*c5*m5*s2*s2*s3*s3
    ;
    M(3,2)=+ 0.0158*c2*c2*c3*c3*c4*c4*m4 + 0.0158*c2*c2*c3*c3*m4*s4*s4 + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3 + 0.0158*m4*s2*s2*s3*s3*s4*s4
    + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.126*a2*c2*c2*c3*c3*c4*m4 + 0.126*a2*c2*c2*c4*m4*s3*s3 + 0.126*a2*c3*c3*c4*m4*s2*s2 + 0.126*a2*c4*m4*s2*s2*s3*s3
    + 0.252*a3*c2*c2*c3*c3*c4*c4*m4 + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2 + 0.252*a3*c2*c2*m4*s3*s3*s4*s4 + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4
    + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3 + a3*a3*c3*c3*c4*c4*m4*s2*s2 + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3 + a3*a3*c3*c3*c4*c4*m5*s2*s2
    + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3 + a3*a3*c2*c2*m5*s3*s3*s4*s4 + a3*a3*c3*c3*m5*s2*s2*s4*s4 + a3*a3*c4*c4*m5*s2*s2*s3*s3 + a2*a3*c2*c2*c3*c3*c4*m4 + a2*a3*c2*c2*c3*c3*c4*m5
    + a2*a3*c2*c2*c4*m4*s3*s3 + a2*a3*c3*c3*c4*m4*s2*s2 + a2*a3*c2*c2*c4*m5*s3*s3 + a2*a3*c3*c3*c4*m5*s2*s2 + a2*a3*c4*m4*s2*s2*s3*s3 + a2*a3*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5 + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4
    + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2 + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4 + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4 + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3 + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4
    + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3 + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2 + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4 + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3
    + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4 + a2*a4*c2*c2*c3*c3*c4*c5*m5 + a2*a4*c2*c2*c4*c5*m5*s3*s3 + a2*a4*c3*c3*c4*c5*m5*s2*s2 + a2*a4*c4*c5*m5*s2*s2*s3*s3
    ;
    M(3,3)=+ 0.0158*c2*c2*c3*c3*c4*c4*m4 + 0.0158*c2*c2*c3*c3*m4*s4*s4 + 0.0158*c2*c2*c4*c4*m4*s3*s3 + 0.0158*c3*c3*c4*c4*m4*s2*s2 + 0.0158*c2*c2*m4*s3*s3*s4*s4 + 0.0158*c3*c3*m4*s2*s2*s4*s4 + 0.0158*c4*c4*m4*s2*s2*s3*s3 + 0.0158*m4*s2*s2*s3*s3*s4*s4
    + a3*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*m5*s2*s2*s3*s3*s4*s4 + 0.252*a3*c2*c2*c3*c3*c4*c4*m4 + 0.252*a3*c2*c2*c3*c3*m4*s4*s4 + 0.252*a3*c2*c2*c4*c4*m4*s3*s3 + 0.252*a3*c3*c3*c4*c4*m4*s2*s2 + 0.252*a3*c2*c2*m4*s3*s3*s4*s4
    + 0.252*a3*c3*c3*m4*s2*s2*s4*s4 + 0.252*a3*c4*c4*m4*s2*s2*s3*s3 + 0.252*a3*m4*s2*s2*s3*s3*s4*s4 + a3*a3*c2*c2*c3*c3*c4*c4*m4 + a3*a3*c2*c2*c3*c3*c4*c4*m5 + a3*a3*c2*c2*c3*c3*m4*s4*s4 + a3*a3*c2*c2*c4*c4*m4*s3*s3 + a3*a3*c3*c3*c4*c4*m4*s2*s2
    + a3*a3*c2*c2*c3*c3*m5*s4*s4 + a3*a3*c2*c2*c4*c4*m5*s3*s3 + a3*a3*c3*c3*c4*c4*m5*s2*s2 + a3*a3*c2*c2*m4*s3*s3*s4*s4 + a3*a3*c3*c3*m4*s2*s2*s4*s4 + a3*a3*c4*c4*m4*s2*s2*s3*s3 + a3*a3*c2*c2*m5*s3*s3*s4*s4 + a3*a3*c3*c3*m5*s2*s2*s4*s4
    + a3*a3*c4*c4*m5*s2*s2*s3*s3 + a4*a4*c2*c2*c3*c3*c4*c4*c5*c5*m5 + a4*a4*c2*c2*c3*c3*c5*c5*m5*s4*s4 + a4*a4*c2*c2*c4*c4*c5*c5*m5*s3*s3 + a4*a4*c3*c3*c4*c4*c5*c5*m5*s2*s2 + a4*a4*c2*c2*c5*c5*m5*s3*s3*s4*s4 + a4*a4*c3*c3*c5*c5*m5*s2*s2*s4*s4
    + a4*a4*c4*c4*c5*c5*m5*s2*s2*s3*s3 + a4*a4*c5*c5*m5*s2*s2*s3*s3*s4*s4 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*c5*m5 + 2.0*a3*a4*c2*c2*c3*c3*c5*m5*s4*s4 + 2.0*a3*a4*c2*c2*c4*c4*c5*m5*s3*s3 + 2.0*a3*a4*c3*c3*c4*c4*c5*m5*s2*s2
    + 2.0*a3*a4*c2*c2*c5*m5*s3*s3*s4*s4 + 2.0*a3*a4*c3*c3*c5*m5*s2*s2*s4*s4 + 2.0*a3*a4*c4*c4*c5*m5*s2*s2*s3*s3 + 2.0*a3*a4*c5*m5*s2*s2*s3*s3*s4*s4;
    M(3,4)=0.0;
    M(4,0)=-1.0*a4*c5*m5;
    M(4,1)=- 1.0*a2*a4*c2*c2*m5*s3*s3*s4*s5 - 1.0*a2*a4*c3*c3*m5*s2*s2*s4*s5 - 1.0*a2*a4*m5*s2*s2*s3*s3*s4*s5 - 1.0*a1*a4*c2*c2*c3*m5*s4*s5 - 1.0*a1*a4*c2*c2*c4*m5*s3*s5 - 1.0*a1*a4*c3*m5*s2*s2*s4*s5 - 1.0*a1*a4*c4*m5*s2*s2*s3*s5
    - 1.0*a2*a4*c2*c2*c3*c3*m5*s4*s5;
    M(4,2)=- 1.0*a2*a4*c2*c2*m5*s3*s3*s4*s5 - 1.0*a2*a4*c3*c3*m5*s2*s2*s4*s5 - 1.0*a2*a4*m5*s2*s2*s3*s3*s4*s5 - 1.0*a2*a4*c2*c2*c3*c3*m5*s4*s5;
    M(4,3)=0.0;
    M(4,4)=a4*a4*c5*c5*m5 + a4*a4*c2*c2*c3*c3*c4*c4*m5*s5*s5 + a4*a4*c2*c2*c3*c3*m5*s4*s4*s5*s5 + a4*a4*c2*c2*c4*c4*m5*s3*s3*s5*s5 + a4*a4*c3*c3*c4*c4*m5*s2*s2*s5*s5 + a4*a4*c2*c2*m5*s3*s3*s4*s4*s5*s5 + a4*a4*c3*c3*m5*s2*s2*s4*s4*s5*s5 + a4*a4*c4*c4*m5*s2*s2*s3*s3*s5*s5
    + a4*a4*m5*s2*s2*s3*s3*s4*s4*s5*s5;
    C(0)=a4*dt5*dt5*m5*s5;
    C(1)=- 0.147*a1*c2*c2*dt3*dt3*m3*s3 - 0.147*a1*dt3*dt3*m3*s2*s2*s3 - 0.126*a2*dt4*dt4*m4*s2*s2*s3*s3*s4 - 0.294*a1*c2*c2*dt2*dt3*m3*s3 - 0.294*a1*dt2*dt3*m3*s2*s2*s3
    - 1.0*a1*a2*c2*c2*dt3*dt3*m3*s3 - 1.0*a1*a2*c2*c2*dt3*dt3*m4*s3 - 1.0*a1*a2*c2*c2*dt3*dt3*m5*s3 - 0.126*a1*c2*c2*c3*dt3*dt3*m4*s4 - 0.126*a1*c2*c2*c4*dt3*dt3*m4*s3
    - 0.126*a1*c2*c2*c3*dt4*dt4*m4*s4 - 0.126*a1*c2*c2*c4*dt4*dt4*m4*s3 - 1.0*a1*a2*dt3*dt3*m3*s2*s2*s3 - 1.0*a1*a2*dt3*dt3*m4*s2*s2*s3 - 1.0*a1*a2*dt3*dt3*m5*s2*s2*s3 - 0.126*a1*c3*dt3*dt3*m4*s2*s2*s4
    - 0.126*a1*c4*dt3*dt3*m4*s2*s2*s3 - 0.126*a1*c3*dt4*dt4*m4*s2*s2*s4 - 0.126*a1*c4*dt4*dt4*m4*s2*s2*s3 - 0.126*a2*c2*c2*c3*c3*dt4*dt4*m4*s4 - 0.126*a2*c2*c2*dt4*dt4*m4*s3*s3*s4 - 0.126*a2*c3*c3*dt4*dt4*m4*s2*s2*s4 - 0.252*a2*dt2*dt4*m4*s2*s2*s3*s3*s4
    - 0.252*a2*dt3*dt4*m4*s2*s2*s3*s3*s4 - 1.0*a2*a3*c2*c2*c3*c3*dt4*dt4*m4*s4 - 1.0*a2*a3*c2*c2*c3*c3*dt4*dt4*m5*s4 - 1.0*a2*a3*c2*c2*dt4*dt4*m4*s3*s3*s4 - 1.0*a2*a3*c3*c3*dt4*dt4*m4*s2*s2*s4 - 1.0*a2*a3*c2*c2*dt4*dt4*m5*s3*s3*s4
    - 1.0*a2*a3*c3*c3*dt4*dt4*m5*s2*s2*s4 - 1.0*a2*a3*dt4*dt4*m4*s2*s2*s3*s3*s4 - 1.0*a2*a3*dt4*dt4*m5*s2*s2*s3*s3*s4 + 0.0102*a1*c2*c2*c3*c4*dt2*dt3*m4 + 0.0102*a1*c2*c2*c3*c4*dt2*dt4*m4
    + 0.0102*a1*c2*c2*c3*c4*dt3*dt4*m4 - 2.0*a1*a2*c2*c2*dt2*dt3*m3*s3 - 2.0*a1*a2*c2*c2*dt2*dt3*m4*s3 - 2.0*a1*a2*c2*c2*dt2*dt3*m5*s3 + 0.0102*a1*c3*c4*dt2*dt3*m4*s2*s2 - 0.252*a1*c2*c2*c3*dt2*dt3*m4*s4 - 0.252*a1*c2*c2*c4*dt2*dt3*m4*s3
    + 0.0102*a1*c3*c4*dt2*dt4*m4*s2*s2 - 0.252*a1*c2*c2*c3*dt2*dt4*m4*s4 - 0.252*a1*c2*c2*c4*dt2*dt4*m4*s3 + 0.0102*a1*c3*c4*dt3*dt4*m4*s2*s2 - 0.252*a1*c2*c2*c3*dt3*dt4*m4*s4 - 0.252*a1*c2*c2*c4*dt3*dt4*m4*s3
    - 2.0*a1*a2*dt2*dt3*m3*s2*s2*s3 - 2.0*a1*a2*dt2*dt3*m4*s2*s2*s3 - 2.0*a1*a2*dt2*dt3*m5*s2*s2*s3 - 0.252*a1*c3*dt2*dt3*m4*s2*s2*s4 - 0.252*a1*c4*dt2*dt3*m4*s2*s2*s3 - 0.0102*a1*c2*c2*dt2*dt3*m4*s3*s4
    - 0.252*a1*c3*dt2*dt4*m4*s2*s2*s4 - 0.252*a1*c4*dt2*dt4*m4*s2*s2*s3 - 0.0102*a1*c2*c2*dt2*dt4*m4*s3*s4 - 0.252*a1*c3*dt3*dt4*m4*s2*s2*s4 - 0.252*a1*c4*dt3*dt4*m4*s2*s2*s3 - 0.0102*a1*c2*c2*dt3*dt4*m4*s3*s4
    - 0.0102*a1*dt2*dt3*m4*s2*s2*s3*s4 - 0.0102*a1*dt2*dt4*m4*s2*s2*s3*s4 - 0.0102*a1*dt3*dt4*m4*s2*s2*s3*s4 + 0.0102*a2*c2*c2*c3*c3*c4*dt2*dt4*m4 + 0.0102*a2*c2*c2*c3*c3*c4*dt3*dt4*m4 - 1.0*a1*a3*c2*c2*c3*dt3*dt3*m4*s4
    - 1.0*a1*a3*c2*c2*c4*dt3*dt3*m4*s3 - 1.0*a1*a3*c2*c2*c3*dt3*dt3*m5*s4 - 1.0*a1*a3*c2*c2*c3*dt4*dt4*m4*s4 - 1.0*a1*a3*c2*c2*c4*dt3*dt3*m5*s3 - 1.0*a1*a3*c2*c2*c4*dt4*dt4*m4*s3 - 1.0*a1*a3*c2*c2*c3*dt4*dt4*m5*s4
    - 1.0*a1*a3*c2*c2*c4*dt4*dt4*m5*s3 + 0.0102*a2*c2*c2*c4*dt2*dt4*m4*s3*s3 - 0.252*a2*c2*c2*c3*c3*dt2*dt4*m4*s4 + 0.0102*a2*c3*c3*c4*dt2*dt4*m4*s2*s2 + 0.0102*a2*c2*c2*c4*dt3*dt4*m4*s3*s3 - 0.252*a2*c2*c2*c3*c3*dt3*dt4*m4*s4
    + 0.0102*a2*c3*c3*c4*dt3*dt4*m4*s2*s2 - 1.0*a1*a3*c3*dt3*dt3*m4*s2*s2*s4 - 1.0*a1*a3*c4*dt3*dt3*m4*s2*s2*s3 - 1.0*a1*a3*c3*dt3*dt3*m5*s2*s2*s4 - 1.0*a1*a3*c3*dt4*dt4*m4*s2*s2*s4 - 1.0*a1*a3*c4*dt3*dt3*m5*s2*s2*s3
    - 1.0*a1*a3*c4*dt4*dt4*m4*s2*s2*s3 - 1.0*a1*a3*c3*dt4*dt4*m5*s2*s2*s4 - 1.0*a1*a3*c4*dt4*dt4*m5*s2*s2*s3 + 0.0102*a2*c4*dt2*dt4*m4*s2*s2*s3*s3 - 0.252*a2*c2*c2*dt2*dt4*m4*s3*s3*s4 - 0.252*a2*c3*c3*dt2*dt4*m4*s2*s2*s4
    + 0.0102*a2*c4*dt3*dt4*m4*s2*s2*s3*s3 - 0.252*a2*c2*c2*dt3*dt4*m4*s3*s3*s4 - 0.252*a2*c3*c3*dt3*dt4*m4*s2*s2*s4 - 1.0*a1*a4*c2*c2*c3*c5*dt3*dt3*m5*s4 - 1.0*a1*a4*c2*c2*c4*c5*dt3*dt3*m5*s3
    - 1.0*a1*a4*c2*c2*c3*c5*dt4*dt4*m5*s4 - 1.0*a1*a4*c2*c2*c4*c5*dt4*dt4*m5*s3 - 1.0*a1*a4*c2*c2*c3*c5*dt5*dt5*m5*s4 - 1.0*a1*a4*c2*c2*c4*c5*dt5*dt5*m5*s3 - 2.0*a2*a3*c2*c2*c3*c3*dt2*dt4*m4*s4 - 2.0*a2*a3*c2*c2*c3*c3*dt2*dt4*m5*s4
    - 2.0*a2*a3*c2*c2*c3*c3*dt3*dt4*m4*s4 - 2.0*a2*a3*c2*c2*c3*c3*dt3*dt4*m5*s4 - 1.0*a1*a4*c3*c5*dt3*dt3*m5*s2*s2*s4 - 1.0*a1*a4*c4*c5*dt3*dt3*m5*s2*s2*s3 - 1.0*a1*a4*c3*c5*dt4*dt4*m5*s2*s2*s4 - 1.0*a1*a4*c4*c5*dt4*dt4*m5*s2*s2*s3
    - 1.0*a1*a4*c3*c5*dt5*dt5*m5*s2*s2*s4 - 1.0*a1*a4*c4*c5*dt5*dt5*m5*s2*s2*s3 - 2.0*a2*a3*c2*c2*dt2*dt4*m4*s3*s3*s4 - 2.0*a2*a3*c3*c3*dt2*dt4*m4*s2*s2*s4 - 2.0*a2*a3*c2*c2*dt2*dt4*m5*s3*s3*s4
    - 2.0*a2*a3*c2*c2*dt3*dt4*m4*s3*s3*s4 - 2.0*a2*a3*c3*c3*dt2*dt4*m5*s2*s2*s4 - 2.0*a2*a3*c3*c3*dt3*dt4*m4*s2*s2*s4 - 2.0*a2*a3*c2*c2*dt3*dt4*m5*s3*s3*s4 - 2.0*a2*a3*c3*c3*dt3*dt4*m5*s2*s2*s4 - 2.0*a2*a3*dt2*dt4*m4*s2*s2*s3*s3*s4
    - 2.0*a2*a3*dt2*dt4*m5*s2*s2*s3*s3*s4 - 2.0*a2*a3*dt3*dt4*m4*s2*s2*s3*s3*s4 - 2.0*a2*a3*dt3*dt4*m5*s2*s2*s3*s3*s4 - 1.0*a2*a4*c2*c2*c3*c3*c5*dt4*dt4*m5*s4 - 1.0*a2*a4*c2*c2*c3*c3*c5*dt5*dt5*m5*s4
    - 1.0*a2*a4*c2*c2*c5*dt4*dt4*m5*s3*s3*s4 - 1.0*a2*a4*c3*c3*c5*dt4*dt4*m5*s2*s2*s4 - 1.0*a2*a4*c2*c2*c5*dt5*dt5*m5*s3*s3*s4 - 1.0*a2*a4*c3*c3*c5*dt5*dt5*m5*s2*s2*s4 - 1.0*a2*a4*c5*dt4*dt4*m5*s2*s2*s3*s3*s4 - 1.0*a2*a4*c5*dt5*dt5*m5*s2*s2*s3*s3*s4
    - 2.0*a1*a3*c2*c2*c3*dt2*dt3*m4*s4 - 2.0*a1*a3*c2*c2*c4*dt2*dt3*m4*s3 - 2.0*a1*a3*c2*c2*c3*dt2*dt3*m5*s4 - 2.0*a1*a3*c2*c2*c3*dt2*dt4*m4*s4 - 2.0*a1*a3*c2*c2*c4*dt2*dt3*m5*s3 - 2.0*a1*a3*c2*c2*c4*dt2*dt4*m4*s3
    - 2.0*a1*a3*c2*c2*c3*dt2*dt4*m5*s4 - 2.0*a1*a3*c2*c2*c3*dt3*dt4*m4*s4 - 2.0*a1*a3*c2*c2*c4*dt2*dt4*m5*s3 - 2.0*a1*a3*c2*c2*c4*dt3*dt4*m4*s3 - 2.0*a1*a3*c2*c2*c3*dt3*dt4*m5*s4
    - 2.0*a1*a3*c2*c2*c4*dt3*dt4*m5*s3 - 2.0*a1*a3*c3*dt2*dt3*m4*s2*s2*s4 - 2.0*a1*a3*c4*dt2*dt3*m4*s2*s2*s3 - 2.0*a1*a3*c3*dt2*dt3*m5*s2*s2*s4 - 2.0*a1*a3*c3*dt2*dt4*m4*s2*s2*s4 - 2.0*a1*a3*c4*dt2*dt3*m5*s2*s2*s3
    - 2.0*a1*a3*c4*dt2*dt4*m4*s2*s2*s3 - 2.0*a1*a3*c3*dt2*dt4*m5*s2*s2*s4 - 2.0*a1*a3*c3*dt3*dt4*m4*s2*s2*s4 - 2.0*a1*a3*c4*dt2*dt4*m5*s2*s2*s3 - 2.0*a1*a3*c4*dt3*dt4*m4*s2*s2*s3 - 2.0*a1*a3*c3*dt3*dt4*m5*s2*s2*s4
    - 2.0*a1*a3*c4*dt3*dt4*m5*s2*s2*s3 - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt2*dt5*m5*s5 - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt3*dt5*m5*s5 - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt4*dt5*m5*s5 - 2.0*a3*a4*c2*c2*c3*c3*dt2*dt5*m5*s4*s4*s5
    - 2.0*a3*a4*c2*c2*c4*c4*dt2*dt5*m5*s3*s3*s5 - 2.0*a3*a4*c3*c3*c4*c4*dt2*dt5*m5*s2*s2*s5 - 2.0*a3*a4*c2*c2*c3*c3*dt3*dt5*m5*s4*s4*s5 - 2.0*a3*a4*c2*c2*c4*c4*dt3*dt5*m5*s3*s3*s5 - 2.0*a3*a4*c3*c3*c4*c4*dt3*dt5*m5*s2*s2*s5
    - 2.0*a3*a4*c2*c2*c3*c3*dt4*dt5*m5*s4*s4*s5 - 2.0*a3*a4*c2*c2*c4*c4*dt4*dt5*m5*s3*s3*s5 - 2.0*a3*a4*c3*c3*c4*c4*dt4*dt5*m5*s2*s2*s5 - 2.0*a3*a4*c2*c2*dt2*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a3*a4*c3*c3*dt2*dt5*m5*s2*s2*s4*s4*s5
    - 2.0*a3*a4*c4*c4*dt2*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a3*a4*c2*c2*dt3*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a3*a4*c3*c3*dt3*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a3*a4*c4*c4*dt3*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a3*a4*c2*c2*dt4*dt5*m5*s3*s3*s4*s4*s5
    - 2.0*a3*a4*c3*c3*dt4*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a3*a4*c4*c4*dt4*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a3*a4*dt2*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a3*a4*dt3*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a3*a4*dt4*dt5*m5*s2*s2*s3*s3*s4*s4*s5
    - 2.0*a1*a4*c2*c2*c3*c5*dt2*dt3*m5*s4 - 2.0*a1*a4*c2*c2*c4*c5*dt2*dt3*m5*s3 - 2.0*a1*a4*c2*c2*c3*c5*dt2*dt4*m5*s4 - 2.0*a1*a4*c2*c2*c4*c5*dt2*dt4*m5*s3 - 2.0*a1*a4*c2*c2*c3*c4*dt2*dt5*m5*s5
    - 2.0*a1*a4*c2*c2*c3*c5*dt3*dt4*m5*s4 - 2.0*a1*a4*c2*c2*c4*c5*dt3*dt4*m5*s3 - 2.0*a1*a4*c2*c2*c3*c4*dt3*dt5*m5*s5 - 2.0*a1*a4*c2*c2*c3*c4*dt4*dt5*m5*s5 - 2.0*a1*a4*c3*c5*dt2*dt3*m5*s2*s2*s4 - 2.0*a1*a4*c4*c5*dt2*dt3*m5*s2*s2*s3
    - 2.0*a1*a4*c3*c5*dt2*dt4*m5*s2*s2*s4 - 2.0*a1*a4*c4*c5*dt2*dt4*m5*s2*s2*s3 - 2.0*a1*a4*c3*c4*dt2*dt5*m5*s2*s2*s5 - 2.0*a1*a4*c3*c5*dt3*dt4*m5*s2*s2*s4 - 2.0*a1*a4*c4*c5*dt3*dt4*m5*s2*s2*s3
    - 2.0*a1*a4*c3*c4*dt3*dt5*m5*s2*s2*s5 - 2.0*a1*a4*c3*c4*dt4*dt5*m5*s2*s2*s5 + 2.0*a1*a4*c2*c2*dt2*dt5*m5*s3*s4*s5 + 2.0*a1*a4*c2*c2*dt3*dt5*m5*s3*s4*s5 + 2.0*a1*a4*c2*c2*dt4*dt5*m5*s3*s4*s5
    - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt2*dt5*m5*s5 - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt3*dt5*m5*s5 - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt4*dt5*m5*s5 + 2.0*a1*a4*dt2*dt5*m5*s2*s2*s3*s4*s5 + 2.0*a1*a4*dt3*dt5*m5*s2*s2*s3*s4*s5
    + 2.0*a1*a4*dt4*dt5*m5*s2*s2*s3*s4*s5 - 2.0*a4*a4*c2*c2*c3*c3*c5*dt2*dt5*m5*s4*s4*s5 - 2.0*a4*a4*c2*c2*c4*c4*c5*dt2*dt5*m5*s3*s3*s5 - 2.0*a4*a4*c3*c3*c4*c4*c5*dt2*dt5*m5*s2*s2*s5 - 2.0*a4*a4*c2*c2*c3*c3*c5*dt3*dt5*m5*s4*s4*s5
    - 2.0*a4*a4*c2*c2*c4*c4*c5*dt3*dt5*m5*s3*s3*s5 - 2.0*a4*a4*c3*c3*c4*c4*c5*dt3*dt5*m5*s2*s2*s5 - 2.0*a4*a4*c2*c2*c3*c3*c5*dt4*dt5*m5*s4*s4*s5 - 2.0*a4*a4*c2*c2*c4*c4*c5*dt4*dt5*m5*s3*s3*s5 - 2.0*a4*a4*c3*c3*c4*c4*c5*dt4*dt5*m5*s2*s2*s5
    - 2.0*a4*a4*c2*c2*c5*dt2*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a4*a4*c3*c3*c5*dt2*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a4*a4*c4*c4*c5*dt2*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a4*a4*c2*c2*c5*dt3*dt5*m5*s3*s3*s4*s4*s5
    - 2.0*a4*a4*c3*c3*c5*dt3*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a4*a4*c4*c4*c5*dt3*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a4*a4*c2*c2*c5*dt4*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a4*a4*c3*c3*c5*dt4*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a4*a4*c4*c4*c5*dt4*dt5*m5*s2*s2*s3*s3*s5
    - 2.0*a4*a4*c5*dt2*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a4*a4*c5*dt3*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a4*a4*c5*dt4*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a2*a4*c2*c2*c3*c3*c5*dt2*dt4*m5*s4 - 2.0*a2*a4*c2*c2*c3*c3*c4*dt2*dt5*m5*s5
    - 2.0*a2*a4*c2*c2*c3*c3*c5*dt3*dt4*m5*s4 - 2.0*a2*a4*c2*c2*c3*c3*c4*dt3*dt5*m5*s5 - 2.0*a2*a4*c2*c2*c3*c3*c4*dt4*dt5*m5*s5 - 2.0*a2*a4*c2*c2*c5*dt2*dt4*m5*s3*s3*s4 - 2.0*a2*a4*c3*c3*c5*dt2*dt4*m5*s2*s2*s4
    - 2.0*a2*a4*c2*c2*c4*dt2*dt5*m5*s3*s3*s5 - 2.0*a2*a4*c2*c2*c5*dt3*dt4*m5*s3*s3*s4 - 2.0*a2*a4*c3*c3*c4*dt2*dt5*m5*s2*s2*s5 - 2.0*a2*a4*c3*c3*c5*dt3*dt4*m5*s2*s2*s4 - 2.0*a2*a4*c2*c2*c4*dt3*dt5*m5*s3*s3*s5
    - 2.0*a2*a4*c3*c3*c4*dt3*dt5*m5*s2*s2*s5 - 2.0*a2*a4*c2*c2*c4*dt4*dt5*m5*s3*s3*s5 - 2.0*a2*a4*c3*c3*c4*dt4*dt5*m5*s2*s2*s5 - 2.0*a2*a4*c5*dt2*dt4*m5*s2*s2*s3*s3*s4 - 2.0*a2*a4*c4*dt2*dt5*m5*s2*s2*s3*s3*s5
    - 2.0*a2*a4*c5*dt3*dt4*m5*s2*s2*s3*s3*s4 - 2.0*a2*a4*c4*dt3*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a2*a4*c4*dt4*dt5*m5*s2*s2*s3*s3*s5;
    C(2)=+ 0.147*a1*c2*c2*dt2*dt2*m3*s3 + 0.147*a1*dt2*dt2*m3*s2*s2*s3 - 0.126*a2*dt4*dt4*m4*s2*s2*s3*s3*s4 + a1*a2*c2*c2*dt2*dt2*m3*s3 + a1*a2*c2*c2*dt2*dt2*m4*s3 + a1*a2*c2*c2*dt2*dt2*m5*s3 + 0.126*a1*c2*c2*c3*dt2*dt2*m4*s4
    + 0.126*a1*c2*c2*c4*dt2*dt2*m4*s3 + a1*a2*dt2*dt2*m3*s2*s2*s3 + a1*a2*dt2*dt2*m4*s2*s2*s3 + a1*a2*dt2*dt2*m5*s2*s2*s3 + 0.126*a1*c3*dt2*dt2*m4*s2*s2*s4 + 0.126*a1*c4*dt2*dt2*m4*s2*s2*s3
    - 0.126*a2*c2*c2*c3*c3*dt4*dt4*m4*s4 - 0.126*a2*c2*c2*dt4*dt4*m4*s3*s3*s4 - 0.126*a2*c3*c3*dt4*dt4*m4*s2*s2*s4 - 0.252*a2*dt2*dt4*m4*s2*s2*s3*s3*s4 - 0.252*a2*dt3*dt4*m4*s2*s2*s3*s3*s4 - 1.0*a2*a3*c2*c2*c3*c3*dt4*dt4*m4*s4 - 1.0*a2*a3*c2*c2*c3*c3*dt4*dt4*m5*s4
    - 1.0*a2*a3*c2*c2*dt4*dt4*m4*s3*s3*s4 - 1.0*a2*a3*c3*c3*dt4*dt4*m4*s2*s2*s4 - 1.0*a2*a3*c2*c2*dt4*dt4*m5*s3*s3*s4 - 1.0*a2*a3*c3*c3*dt4*dt4*m5*s2*s2*s4 - 1.0*a2*a3*dt4*dt4*m4*s2*s2*s3*s3*s4 - 1.0*a2*a3*dt4*dt4*m5*s2*s2*s3*s3*s4
    + 0.0102*a2*c2*c2*c3*c3*c4*dt2*dt4*m4 + 0.0102*a2*c2*c2*c3*c3*c4*dt3*dt4*m4 + a1*a3*c2*c2*c3*dt2*dt2*m4*s4 + a1*a3*c2*c2*c4*dt2*dt2*m4*s3 + a1*a3*c2*c2*c3*dt2*dt2*m5*s4 + a1*a3*c2*c2*c4*dt2*dt2*m5*s3
    + 0.0102*a2*c2*c2*c4*dt2*dt4*m4*s3*s3 - 0.252*a2*c2*c2*c3*c3*dt2*dt4*m4*s4 + 0.0102*a2*c3*c3*c4*dt2*dt4*m4*s2*s2 + 0.0102*a2*c2*c2*c4*dt3*dt4*m4*s3*s3 - 0.252*a2*c2*c2*c3*c3*dt3*dt4*m4*s4 + 0.0102*a2*c3*c3*c4*dt3*dt4*m4*s2*s2
    + a1*a3*c3*dt2*dt2*m4*s2*s2*s4 + a1*a3*c4*dt2*dt2*m4*s2*s2*s3 + a1*a3*c3*dt2*dt2*m5*s2*s2*s4 + a1*a3*c4*dt2*dt2*m5*s2*s2*s3 + 0.0102*a2*c4*dt2*dt4*m4*s2*s2*s3*s3 - 0.252*a2*c2*c2*dt2*dt4*m4*s3*s3*s4
    - 0.252*a2*c3*c3*dt2*dt4*m4*s2*s2*s4 + 0.0102*a2*c4*dt3*dt4*m4*s2*s2*s3*s3 - 0.252*a2*c2*c2*dt3*dt4*m4*s3*s3*s4 - 0.252*a2*c3*c3*dt3*dt4*m4*s2*s2*s4 + a1*a4*c2*c2*c3*c5*dt2*dt2*m5*s4 + a1*a4*c2*c2*c4*c5*dt2*dt2*m5*s3
    - 2.0*a2*a3*c2*c2*c3*c3*dt2*dt4*m4*s4 - 2.0*a2*a3*c2*c2*c3*c3*dt2*dt4*m5*s4 - 2.0*a2*a3*c2*c2*c3*c3*dt3*dt4*m4*s4 - 2.0*a2*a3*c2*c2*c3*c3*dt3*dt4*m5*s4 + a1*a4*c3*c5*dt2*dt2*m5*s2*s2*s4 + a1*a4*c4*c5*dt2*dt2*m5*s2*s2*s3
    - 2.0*a2*a3*c2*c2*dt2*dt4*m4*s3*s3*s4 - 2.0*a2*a3*c3*c3*dt2*dt4*m4*s2*s2*s4 - 2.0*a2*a3*c2*c2*dt2*dt4*m5*s3*s3*s4 - 2.0*a2*a3*c2*c2*dt3*dt4*m4*s3*s3*s4 - 2.0*a2*a3*c3*c3*dt2*dt4*m5*s2*s2*s4
    - 2.0*a2*a3*c3*c3*dt3*dt4*m4*s2*s2*s4 - 2.0*a2*a3*c2*c2*dt3*dt4*m5*s3*s3*s4 - 2.0*a2*a3*c3*c3*dt3*dt4*m5*s2*s2*s4 - 2.0*a2*a3*dt2*dt4*m4*s2*s2*s3*s3*s4 - 2.0*a2*a3*dt2*dt4*m5*s2*s2*s3*s3*s4 - 2.0*a2*a3*dt3*dt4*m4*s2*s2*s3*s3*s4
    - 2.0*a2*a3*dt3*dt4*m5*s2*s2*s3*s3*s4 - 1.0*a2*a4*c2*c2*c3*c3*c5*dt4*dt4*m5*s4 - 1.0*a2*a4*c2*c2*c3*c3*c5*dt5*dt5*m5*s4 - 1.0*a2*a4*c2*c2*c5*dt4*dt4*m5*s3*s3*s4 - 1.0*a2*a4*c3*c3*c5*dt4*dt4*m5*s2*s2*s4
    - 1.0*a2*a4*c2*c2*c5*dt5*dt5*m5*s3*s3*s4 - 1.0*a2*a4*c3*c3*c5*dt5*dt5*m5*s2*s2*s4 - 1.0*a2*a4*c5*dt4*dt4*m5*s2*s2*s3*s3*s4 - 1.0*a2*a4*c5*dt5*dt5*m5*s2*s2*s3*s3*s4 - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt2*dt5*m5*s5 - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt3*dt5*m5*s5
    - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt4*dt5*m5*s5 - 2.0*a3*a4*c2*c2*c3*c3*dt2*dt5*m5*s4*s4*s5 - 2.0*a3*a4*c2*c2*c4*c4*dt2*dt5*m5*s3*s3*s5 - 2.0*a3*a4*c3*c3*c4*c4*dt2*dt5*m5*s2*s2*s5 - 2.0*a3*a4*c2*c2*c3*c3*dt3*dt5*m5*s4*s4*s5
    - 2.0*a3*a4*c2*c2*c4*c4*dt3*dt5*m5*s3*s3*s5 - 2.0*a3*a4*c3*c3*c4*c4*dt3*dt5*m5*s2*s2*s5 - 2.0*a3*a4*c2*c2*c3*c3*dt4*dt5*m5*s4*s4*s5 - 2.0*a3*a4*c2*c2*c4*c4*dt4*dt5*m5*s3*s3*s5
    - 2.0*a3*a4*c3*c3*c4*c4*dt4*dt5*m5*s2*s2*s5 - 2.0*a3*a4*c2*c2*dt2*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a3*a4*c3*c3*dt2*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a3*a4*c4*c4*dt2*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a3*a4*c2*c2*dt3*dt5*m5*s3*s3*s4*s4*s5
    - 2.0*a3*a4*c3*c3*dt3*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a3*a4*c4*c4*dt3*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a3*a4*c2*c2*dt4*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a3*a4*c3*c3*dt4*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a3*a4*c4*c4*dt4*dt5*m5*s2*s2*s3*s3*s5
    - 2.0*a3*a4*dt2*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a3*a4*dt3*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a3*a4*dt4*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt2*dt5*m5*s5 - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt3*dt5*m5*s5
    - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt4*dt5*m5*s5 - 2.0*a4*a4*c2*c2*c3*c3*c5*dt2*dt5*m5*s4*s4*s5 - 2.0*a4*a4*c2*c2*c4*c4*c5*dt2*dt5*m5*s3*s3*s5 - 2.0*a4*a4*c3*c3*c4*c4*c5*dt2*dt5*m5*s2*s2*s5 - 2.0*a4*a4*c2*c2*c3*c3*c5*dt3*dt5*m5*s4*s4*s5
    - 2.0*a4*a4*c2*c2*c4*c4*c5*dt3*dt5*m5*s3*s3*s5 - 2.0*a4*a4*c3*c3*c4*c4*c5*dt3*dt5*m5*s2*s2*s5 - 2.0*a4*a4*c2*c2*c3*c3*c5*dt4*dt5*m5*s4*s4*s5 - 2.0*a4*a4*c2*c2*c4*c4*c5*dt4*dt5*m5*s3*s3*s5
    - 2.0*a4*a4*c3*c3*c4*c4*c5*dt4*dt5*m5*s2*s2*s5 - 2.0*a4*a4*c2*c2*c5*dt2*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a4*a4*c3*c3*c5*dt2*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a4*a4*c4*c4*c5*dt2*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a4*a4*c2*c2*c5*dt3*dt5*m5*s3*s3*s4*s4*s5
    - 2.0*a4*a4*c3*c3*c5*dt3*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a4*a4*c4*c4*c5*dt3*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a4*a4*c2*c2*c5*dt4*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a4*a4*c3*c3*c5*dt4*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a4*a4*c4*c4*c5*dt4*dt5*m5*s2*s2*s3*s3*s5
    - 2.0*a4*a4*c5*dt2*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a4*a4*c5*dt3*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a4*a4*c5*dt4*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a2*a4*c2*c2*c3*c3*c5*dt2*dt4*m5*s4
    - 2.0*a2*a4*c2*c2*c3*c3*c4*dt2*dt5*m5*s5 - 2.0*a2*a4*c2*c2*c3*c3*c5*dt3*dt4*m5*s4 - 2.0*a2*a4*c2*c2*c3*c3*c4*dt3*dt5*m5*s5 - 2.0*a2*a4*c2*c2*c3*c3*c4*dt4*dt5*m5*s5 - 2.0*a2*a4*c2*c2*c5*dt2*dt4*m5*s3*s3*s4 - 2.0*a2*a4*c3*c3*c5*dt2*dt4*m5*s2*s2*s4
    - 2.0*a2*a4*c2*c2*c4*dt2*dt5*m5*s3*s3*s5 - 2.0*a2*a4*c2*c2*c5*dt3*dt4*m5*s3*s3*s4 - 2.0*a2*a4*c3*c3*c4*dt2*dt5*m5*s2*s2*s5 - 2.0*a2*a4*c3*c3*c5*dt3*dt4*m5*s2*s2*s4 - 2.0*a2*a4*c2*c2*c4*dt3*dt5*m5*s3*s3*s5
    - 2.0*a2*a4*c3*c3*c4*dt3*dt5*m5*s2*s2*s5 - 2.0*a2*a4*c2*c2*c4*dt4*dt5*m5*s3*s3*s5 - 2.0*a2*a4*c3*c3*c4*dt4*dt5*m5*s2*s2*s5 - 2.0*a2*a4*c5*dt2*dt4*m5*s2*s2*s3*s3*s4 - 2.0*a2*a4*c4*dt2*dt5*m5*s2*s2*s3*s3*s5
    - 2.0*a2*a4*c5*dt3*dt4*m5*s2*s2*s3*s3*s4 - 2.0*a2*a4*c4*dt3*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a2*a4*c4*dt4*dt5*m5*s2*s2*s3*s3*s5;
    C(3)=0.126*a2*dt2*dt2*m4*s2*s2*s3*s3*s4 + 0.126*a2*dt3*dt3*m4*s2*s2*s3*s3*s4 + 0.126*a1*c2*c2*c3*dt2*dt2*m4*s4 + 0.126*a1*c2*c2*c4*dt2*dt2*m4*s3 + 0.126*a1*c3*dt2*dt2*m4*s2*s2*s4
    + 0.126*a1*c4*dt2*dt2*m4*s2*s2*s3 + 0.126*a2*c2*c2*c3*c3*dt2*dt2*m4*s4 + 0.126*a2*c2*c2*c3*c3*dt3*dt3*m4*s4 + 0.126*a2*c2*c2*dt2*dt2*m4*s3*s3*s4 + 0.126*a2*c3*c3*dt2*dt2*m4*s2*s2*s4
    + 0.126*a2*c2*c2*dt3*dt3*m4*s3*s3*s4 + 0.126*a2*c3*c3*dt3*dt3*m4*s2*s2*s4 + 0.252*a2*dt2*dt3*m4*s2*s2*s3*s3*s4 + a2*a3*c2*c2*c3*c3*dt2*dt2*m4*s4 + a2*a3*c2*c2*c3*c3*dt2*dt2*m5*s4 + a2*a3*c2*c2*c3*c3*dt3*dt3*m4*s4
    + a2*a3*c2*c2*c3*c3*dt3*dt3*m5*s4 + a2*a3*c2*c2*dt2*dt2*m4*s3*s3*s4 + a2*a3*c3*c3*dt2*dt2*m4*s2*s2*s4 + a2*a3*c2*c2*dt2*dt2*m5*s3*s3*s4 + a2*a3*c2*c2*dt3*dt3*m4*s3*s3*s4 + a2*a3*c3*c3*dt2*dt2*m5*s2*s2*s4
    + a2*a3*c3*c3*dt3*dt3*m4*s2*s2*s4 + a2*a3*c2*c2*dt3*dt3*m5*s3*s3*s4 + a2*a3*c3*c3*dt3*dt3*m5*s2*s2*s4 + a2*a3*dt2*dt2*m4*s2*s2*s3*s3*s4 + a2*a3*dt2*dt2*m5*s2*s2*s3*s3*s4 + a2*a3*dt3*dt3*m4*s2*s2*s3*s3*s4 + a2*a3*dt3*dt3*m5*s2*s2*s3*s3*s4
    - 0.0102*a2*c2*c2*c3*c3*c4*dt2*dt3*m4 + a1*a3*c2*c2*c3*dt2*dt2*m4*s4 + a1*a3*c2*c2*c4*dt2*dt2*m4*s3 + a1*a3*c2*c2*c3*dt2*dt2*m5*s4 + a1*a3*c2*c2*c4*dt2*dt2*m5*s3 - 0.0102*a2*c2*c2*c4*dt2*dt3*m4*s3*s3 + 0.252*a2*c2*c2*c3*c3*dt2*dt3*m4*s4
    - 0.0102*a2*c3*c3*c4*dt2*dt3*m4*s2*s2 + a1*a3*c3*dt2*dt2*m4*s2*s2*s4 + a1*a3*c4*dt2*dt2*m4*s2*s2*s3 + a1*a3*c3*dt2*dt2*m5*s2*s2*s4 + a1*a3*c4*dt2*dt2*m5*s2*s2*s3 - 0.0102*a2*c4*dt2*dt3*m4*s2*s2*s3*s3
    + 0.252*a2*c2*c2*dt2*dt3*m4*s3*s3*s4 + 0.252*a2*c3*c3*dt2*dt3*m4*s2*s2*s4 + a1*a4*c2*c2*c3*c5*dt2*dt2*m5*s4 + a1*a4*c2*c2*c4*c5*dt2*dt2*m5*s3 + 2.0*a2*a3*c2*c2*c3*c3*dt2*dt3*m4*s4 + 2.0*a2*a3*c2*c2*c3*c3*dt2*dt3*m5*s4
    + a1*a4*c3*c5*dt2*dt2*m5*s2*s2*s4 + a1*a4*c4*c5*dt2*dt2*m5*s2*s2*s3 + 2.0*a2*a3*c2*c2*dt2*dt3*m4*s3*s3*s4 + 2.0*a2*a3*c3*c3*dt2*dt3*m4*s2*s2*s4 + 2.0*a2*a3*c2*c2*dt2*dt3*m5*s3*s3*s4 + 2.0*a2*a3*c3*c3*dt2*dt3*m5*s2*s2*s4
    + 2.0*a2*a3*dt2*dt3*m4*s2*s2*s3*s3*s4 + 2.0*a2*a3*dt2*dt3*m5*s2*s2*s3*s3*s4 + a2*a4*c2*c2*c3*c3*c5*dt2*dt2*m5*s4 + a2*a4*c2*c2*c3*c3*c5*dt3*dt3*m5*s4 + a2*a4*c2*c2*c5*dt2*dt2*m5*s3*s3*s4 + a2*a4*c3*c3*c5*dt2*dt2*m5*s2*s2*s4
    + a2*a4*c2*c2*c5*dt3*dt3*m5*s3*s3*s4 + a2*a4*c3*c3*c5*dt3*dt3*m5*s2*s2*s4 + a2*a4*c5*dt2*dt2*m5*s2*s2*s3*s3*s4 + a2*a4*c5*dt3*dt3*m5*s2*s2*s3*s3*s4 - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt2*dt5*m5*s5
    - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt3*dt5*m5*s5 - 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt4*dt5*m5*s5 - 2.0*a3*a4*c2*c2*c3*c3*dt2*dt5*m5*s4*s4*s5 - 2.0*a3*a4*c2*c2*c4*c4*dt2*dt5*m5*s3*s3*s5 - 2.0*a3*a4*c3*c3*c4*c4*dt2*dt5*m5*s2*s2*s5
    - 2.0*a3*a4*c2*c2*c3*c3*dt3*dt5*m5*s4*s4*s5 - 2.0*a3*a4*c2*c2*c4*c4*dt3*dt5*m5*s3*s3*s5 - 2.0*a3*a4*c3*c3*c4*c4*dt3*dt5*m5*s2*s2*s5 - 2.0*a3*a4*c2*c2*c3*c3*dt4*dt5*m5*s4*s4*s5 - 2.0*a3*a4*c2*c2*c4*c4*dt4*dt5*m5*s3*s3*s5
    - 2.0*a3*a4*c3*c3*c4*c4*dt4*dt5*m5*s2*s2*s5 - 2.0*a3*a4*c2*c2*dt2*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a3*a4*c3*c3*dt2*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a3*a4*c4*c4*dt2*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a3*a4*c2*c2*dt3*dt5*m5*s3*s3*s4*s4*s5
    - 2.0*a3*a4*c3*c3*dt3*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a3*a4*c4*c4*dt3*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a3*a4*c2*c2*dt4*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a3*a4*c3*c3*dt4*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a3*a4*c4*c4*dt4*dt5*m5*s2*s2*s3*s3*s5
    - 2.0*a3*a4*dt2*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a3*a4*dt3*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a3*a4*dt4*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt2*dt5*m5*s5 - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt3*dt5*m5*s5
    - 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt4*dt5*m5*s5 - 2.0*a4*a4*c2*c2*c3*c3*c5*dt2*dt5*m5*s4*s4*s5 - 2.0*a4*a4*c2*c2*c4*c4*c5*dt2*dt5*m5*s3*s3*s5 - 2.0*a4*a4*c3*c3*c4*c4*c5*dt2*dt5*m5*s2*s2*s5
    - 2.0*a4*a4*c2*c2*c3*c3*c5*dt3*dt5*m5*s4*s4*s5 - 2.0*a4*a4*c2*c2*c4*c4*c5*dt3*dt5*m5*s3*s3*s5 - 2.0*a4*a4*c3*c3*c4*c4*c5*dt3*dt5*m5*s2*s2*s5 - 2.0*a4*a4*c2*c2*c3*c3*c5*dt4*dt5*m5*s4*s4*s5 - 2.0*a4*a4*c2*c2*c4*c4*c5*dt4*dt5*m5*s3*s3*s5
    - 2.0*a4*a4*c3*c3*c4*c4*c5*dt4*dt5*m5*s2*s2*s5 - 2.0*a4*a4*c2*c2*c5*dt2*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a4*a4*c3*c3*c5*dt2*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a4*a4*c4*c4*c5*dt2*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a4*a4*c2*c2*c5*dt3*dt5*m5*s3*s3*s4*s4*s5
    - 2.0*a4*a4*c3*c3*c5*dt3*dt5*m5*s2*s2*s4*s4*s5 - 2.0*a4*a4*c4*c4*c5*dt3*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a4*a4*c2*c2*c5*dt4*dt5*m5*s3*s3*s4*s4*s5 - 2.0*a4*a4*c3*c3*c5*dt4*dt5*m5*s2*s2*s4*s4*s5
    - 2.0*a4*a4*c4*c4*c5*dt4*dt5*m5*s2*s2*s3*s3*s5 - 2.0*a4*a4*c5*dt2*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a4*a4*c5*dt3*dt5*m5*s2*s2*s3*s3*s4*s4*s5 - 2.0*a4*a4*c5*dt4*dt5*m5*s2*s2*s3*s3*s4*s4*s5 + 2.0*a2*a4*c2*c2*c3*c3*c5*dt2*dt3*m5*s4
    + 2.0*a2*a4*c2*c2*c5*dt2*dt3*m5*s3*s3*s4 + 2.0*a2*a4*c3*c3*c5*dt2*dt3*m5*s2*s2*s4 + 2.0*a2*a4*c5*dt2*dt3*m5*s2*s2*s3*s3*s4;
    C(4)=a3*a4*c2*c2*c3*c3*c4*c4*dt2*dt2*m5*s5 - 1.0*a4*a4*c5*dt5*dt5*m5*s5 + a3*a4*c2*c2*c3*c3*c4*c4*dt3*dt3*m5*s5 + a3*a4*c2*c2*c3*c3*c4*c4*dt4*dt4*m5*s5 + a3*a4*c2*c2*c3*c3*dt2*dt2*m5*s4*s4*s5 + a3*a4*c2*c2*c4*c4*dt2*dt2*m5*s3*s3*s5 + a3*a4*c3*c3*c4*c4*dt2*dt2*m5*s2*s2*s5
    + a3*a4*c2*c2*c3*c3*dt3*dt3*m5*s4*s4*s5 + a3*a4*c2*c2*c4*c4*dt3*dt3*m5*s3*s3*s5 + a3*a4*c3*c3*c4*c4*dt3*dt3*m5*s2*s2*s5 + a3*a4*c2*c2*c3*c3*dt4*dt4*m5*s4*s4*s5 + a3*a4*c2*c2*c4*c4*dt4*dt4*m5*s3*s3*s5
    + a3*a4*c3*c3*c4*c4*dt4*dt4*m5*s2*s2*s5 + a3*a4*c2*c2*dt2*dt2*m5*s3*s3*s4*s4*s5 + a3*a4*c3*c3*dt2*dt2*m5*s2*s2*s4*s4*s5 + a3*a4*c4*c4*dt2*dt2*m5*s2*s2*s3*s3*s5 + a3*a4*c2*c2*dt3*dt3*m5*s3*s3*s4*s4*s5 + a3*a4*c3*c3*dt3*dt3*m5*s2*s2*s4*s4*s5
    + a3*a4*c4*c4*dt3*dt3*m5*s2*s2*s3*s3*s5 + a3*a4*c2*c2*dt4*dt4*m5*s3*s3*s4*s4*s5 + a3*a4*c3*c3*dt4*dt4*m5*s2*s2*s4*s4*s5 + a3*a4*c4*c4*dt4*dt4*m5*s2*s2*s3*s3*s5 + a3*a4*dt2*dt2*m5*s2*s2*s3*s3*s4*s4*s5 + a3*a4*dt3*dt3*m5*s2*s2*s3*s3*s4*s4*s5
    + a3*a4*dt4*dt4*m5*s2*s2*s3*s3*s4*s4*s5 + a1*a4*c2*c2*c3*c4*dt2*dt2*m5*s5 + a1*a4*c3*c4*dt2*dt2*m5*s2*s2*s5 - 1.0*a1*a4*c2*c2*dt2*dt2*m5*s3*s4*s5 + a4*a4*c2*c2*c3*c3*c4*c4*c5*dt2*dt2*m5*s5 + a4*a4*c2*c2*c3*c3*c4*c4*c5*dt3*dt3*m5*s5
    + a4*a4*c2*c2*c3*c3*c4*c4*c5*dt4*dt4*m5*s5 + a4*a4*c2*c2*c3*c3*c4*c4*c5*dt5*dt5*m5*s5 - 1.0*a1*a4*dt2*dt2*m5*s2*s2*s3*s4*s5 + a4*a4*c2*c2*c3*c3*c5*dt2*dt2*m5*s4*s4*s5 + a4*a4*c2*c2*c4*c4*c5*dt2*dt2*m5*s3*s3*s5
    + a4*a4*c3*c3*c4*c4*c5*dt2*dt2*m5*s2*s2*s5 + a4*a4*c2*c2*c3*c3*c5*dt3*dt3*m5*s4*s4*s5 + a4*a4*c2*c2*c4*c4*c5*dt3*dt3*m5*s3*s3*s5 + a4*a4*c3*c3*c4*c4*c5*dt3*dt3*m5*s2*s2*s5 + a4*a4*c2*c2*c3*c3*c5*dt4*dt4*m5*s4*s4*s5
    + a4*a4*c2*c2*c4*c4*c5*dt4*dt4*m5*s3*s3*s5 + a4*a4*c3*c3*c4*c4*c5*dt4*dt4*m5*s2*s2*s5 + a4*a4*c2*c2*c3*c3*c5*dt5*dt5*m5*s4*s4*s5 + a4*a4*c2*c2*c4*c4*c5*dt5*dt5*m5*s3*s3*s5 + a4*a4*c3*c3*c4*c4*c5*dt5*dt5*m5*s2*s2*s5 + a4*a4*c2*c2*c5*dt2*dt2*m5*s3*s3*s4*s4*s5
    + a4*a4*c3*c3*c5*dt2*dt2*m5*s2*s2*s4*s4*s5 + a4*a4*c4*c4*c5*dt2*dt2*m5*s2*s2*s3*s3*s5 + a4*a4*c2*c2*c5*dt3*dt3*m5*s3*s3*s4*s4*s5 + a4*a4*c3*c3*c5*dt3*dt3*m5*s2*s2*s4*s4*s5 + a4*a4*c4*c4*c5*dt3*dt3*m5*s2*s2*s3*s3*s5
    + a4*a4*c2*c2*c5*dt4*dt4*m5*s3*s3*s4*s4*s5 + a4*a4*c3*c3*c5*dt4*dt4*m5*s2*s2*s4*s4*s5 + a4*a4*c4*c4*c5*dt4*dt4*m5*s2*s2*s3*s3*s5 + a4*a4*c2*c2*c5*dt5*dt5*m5*s3*s3*s4*s4*s5 + a4*a4*c3*c3*c5*dt5*dt5*m5*s2*s2*s4*s4*s5 + a4*a4*c4*c4*c5*dt5*dt5*m5*s2*s2*s3*s3*s5
    + a4*a4*c5*dt2*dt2*m5*s2*s2*s3*s3*s4*s4*s5 + a4*a4*c5*dt3*dt3*m5*s2*s2*s3*s3*s4*s4*s5 + a4*a4*c5*dt4*dt4*m5*s2*s2*s3*s3*s4*s4*s5 + a4*a4*c5*dt5*dt5*m5*s2*s2*s3*s3*s4*s4*s5 + a2*a4*c2*c2*c3*c3*c4*dt2*dt2*m5*s5
    + a2*a4*c2*c2*c3*c3*c4*dt3*dt3*m5*s5 + a2*a4*c2*c2*c4*dt2*dt2*m5*s3*s3*s5 + a2*a4*c3*c3*c4*dt2*dt2*m5*s2*s2*s5 + a2*a4*c2*c2*c4*dt3*dt3*m5*s3*s3*s5 + a2*a4*c3*c3*c4*dt3*dt3*m5*s2*s2*s5 + a2*a4*c4*dt2*dt2*m5*s2*s2*s3*s3*s5
    + a2*a4*c4*dt3*dt3*m5*s2*s2*s3*s3*s5 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt2*dt3*m5*s5 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt2*dt4*m5*s5 + 2.0*a3*a4*c2*c2*c3*c3*c4*c4*dt3*dt4*m5*s5 + 2.0*a3*a4*c2*c2*c3*c3*dt2*dt3*m5*s4*s4*s5
    + 2.0*a3*a4*c2*c2*c4*c4*dt2*dt3*m5*s3*s3*s5 + 2.0*a3*a4*c3*c3*c4*c4*dt2*dt3*m5*s2*s2*s5 + 2.0*a3*a4*c2*c2*c3*c3*dt2*dt4*m5*s4*s4*s5 + 2.0*a3*a4*c2*c2*c4*c4*dt2*dt4*m5*s3*s3*s5 + 2.0*a3*a4*c3*c3*c4*c4*dt2*dt4*m5*s2*s2*s5
    + 2.0*a3*a4*c2*c2*c3*c3*dt3*dt4*m5*s4*s4*s5 + 2.0*a3*a4*c2*c2*c4*c4*dt3*dt4*m5*s3*s3*s5 + 2.0*a3*a4*c3*c3*c4*c4*dt3*dt4*m5*s2*s2*s5 + 2.0*a3*a4*c2*c2*dt2*dt3*m5*s3*s3*s4*s4*s5 + 2.0*a3*a4*c3*c3*dt2*dt3*m5*s2*s2*s4*s4*s5
    + 2.0*a3*a4*c4*c4*dt2*dt3*m5*s2*s2*s3*s3*s5 + 2.0*a3*a4*c2*c2*dt2*dt4*m5*s3*s3*s4*s4*s5 + 2.0*a3*a4*c3*c3*dt2*dt4*m5*s2*s2*s4*s4*s5 + 2.0*a3*a4*c4*c4*dt2*dt4*m5*s2*s2*s3*s3*s5 + 2.0*a3*a4*c2*c2*dt3*dt4*m5*s3*s3*s4*s4*s5
    + 2.0*a3*a4*c3*c3*dt3*dt4*m5*s2*s2*s4*s4*s5 + 2.0*a3*a4*c4*c4*dt3*dt4*m5*s2*s2*s3*s3*s5 + 2.0*a3*a4*dt2*dt3*m5*s2*s2*s3*s3*s4*s4*s5 + 2.0*a3*a4*dt2*dt4*m5*s2*s2*s3*s3*s4*s4*s5 + 2.0*a3*a4*dt3*dt4*m5*s2*s2*s3*s3*s4*s4*s5
    + 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt2*dt3*m5*s5 + 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt2*dt4*m5*s5 + 2.0*a4*a4*c2*c2*c3*c3*c4*c4*c5*dt3*dt4*m5*s5 + 2.0*a4*a4*c2*c2*c3*c3*c5*dt2*dt3*m5*s4*s4*s5 + 2.0*a4*a4*c2*c2*c4*c4*c5*dt2*dt3*m5*s3*s3*s5
    + 2.0*a4*a4*c3*c3*c4*c4*c5*dt2*dt3*m5*s2*s2*s5 + 2.0*a4*a4*c2*c2*c3*c3*c5*dt2*dt4*m5*s4*s4*s5 + 2.0*a4*a4*c2*c2*c4*c4*c5*dt2*dt4*m5*s3*s3*s5 + 2.0*a4*a4*c3*c3*c4*c4*c5*dt2*dt4*m5*s2*s2*s5
    + 2.0*a4*a4*c2*c2*c3*c3*c5*dt3*dt4*m5*s4*s4*s5 + 2.0*a4*a4*c2*c2*c4*c4*c5*dt3*dt4*m5*s3*s3*s5 + 2.0*a4*a4*c3*c3*c4*c4*c5*dt3*dt4*m5*s2*s2*s5 + 2.0*a4*a4*c2*c2*c5*dt2*dt3*m5*s3*s3*s4*s4*s5 + 2.0*a4*a4*c3*c3*c5*dt2*dt3*m5*s2*s2*s4*s4*s5
    + 2.0*a4*a4*c4*c4*c5*dt2*dt3*m5*s2*s2*s3*s3*s5 + 2.0*a4*a4*c2*c2*c5*dt2*dt4*m5*s3*s3*s4*s4*s5 + 2.0*a4*a4*c3*c3*c5*dt2*dt4*m5*s2*s2*s4*s4*s5 + 2.0*a4*a4*c4*c4*c5*dt2*dt4*m5*s2*s2*s3*s3*s5
    + 2.0*a4*a4*c2*c2*c5*dt3*dt4*m5*s3*s3*s4*s4*s5 + 2.0*a4*a4*c3*c3*c5*dt3*dt4*m5*s2*s2*s4*s4*s5 + 2.0*a4*a4*c4*c4*c5*dt3*dt4*m5*s2*s2*s3*s3*s5 + 2.0*a4*a4*c5*dt2*dt3*m5*s2*s2*s3*s3*s4*s4*s5 + 2.0*a4*a4*c5*dt2*dt4*m5*s2*s2*s3*s3*s4*s4*s5
    + 2.0*a4*a4*c5*dt3*dt4*m5*s2*s2*s3*s3*s4*s4*s5 + 2.0*a2*a4*c2*c2*c3*c3*c4*dt2*dt3*m5*s5 + 2.0*a2*a4*c2*c2*c4*dt2*dt3*m5*s3*s3*s5 + 2.0*a2*a4*c3*c3*c4*dt2*dt3*m5*s2*s2*s5 + 2.0*a2*a4*c4*dt2*dt3*m5*s2*s2*s3*s3*s5
    ;
    G(0)=9.8*m1 + 9.8*m2 + 9.8*m3 + 9.8*m4 + 9.8*m5;
    G(1)=0.0;
    G(2)=0.0;
    G(3)=0.0;
    G(4)=-9.8*a4*c5*m5;

    //--return
    Cq->col(0)=C;
    Gf->col(0)=G;
    return M;
}
