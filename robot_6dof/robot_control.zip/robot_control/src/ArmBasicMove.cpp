#include "robot_control/ArmBasicMove.h"

#include "robot_control/MoveCmd.h"
extern Move cmd;

ArmBasicMove::ArmBasicMove()
{
}
ArmBasicMove::~ArmBasicMove()
{
}

//--basic move api function
bool ArmBasicMove::MovePoint(Vector6f &goalToolPos)
{
    ArmIK(goalToolPos,&m_armInput.jointPos);
    return(IsFinished(0));
}
bool ArmBasicMove::SetJointPos(Vector6f &goalJointPos)
{
   m_armInput.jointPos= goalJointPos;
   return(IsFinished(0));
}
bool ArmBasicMove::MoveL(Vector6f &goalToolPos,float totalT)
{
    Vector6f interpToolPos;
    for(int i=0;i<6;i++)
    {
        interpToolPos(i)=InterpCubicTraj(m_sRoute.startPos(i),goalToolPos(i),totalT,m_time.now);
    }
    //--IK
    ArmIK(interpToolPos,&m_armInput.jointPos);
    return(IsFinished(totalT));
}

bool ArmBasicMove::MoveC(Vector3f &pm,Vector3f &pe,float totalT)
{
    static Vector3f ps;
    if(m_time.now==0)//get start pos
    {
        ps<<m_armFeedBack.toolPos.block<3,1>(0,0);
    }
    //--IK
    Vector3f rpy,pos;
    rpy=m_armInput.toolPos.block<3,1>(3,0);
    pos=Interp3DCircle(ps,pm,pe,totalT,m_time.now);
    ArmIK(rpy,pos,&m_armInput.jointPos);
    return(IsFinished(totalT));
}
void ArmBasicMove::VelLimit(float* time)
{
    for(int i=0;i<m_armParam.dof;i++)
    {
        float timeMin=1.5f*fabs(m_sRoute.startJointPos(i)-m_armParam.zeroPos(i))/
                 fabs(m_armParam.jointVelLimit(i)) ;//time>=1.5*(E-S)/Vmax
        if(*time<timeMin)
        {
            *time=timeMin;
        }
    }
}
bool ArmBasicMove::MoveJ(Vector6f &goalToolPos,float totalT)
{
    VelLimit(&totalT);
    for(int i=0;i<6;i++)
    {
        m_armInput.jointPos(i)=InterpCubicTraj(m_sRoute.startJointPos(i),goalToolPos(i),totalT,m_time.now);
    }
    //--IK
    return(IsFinished(totalT));
}
bool ArmBasicMove::MoveJAV(Vector6f &goalToolPos)
{
    float Ttmp, Tmax=0;//calculated by InterpTtraj(*,&totalT)
    Vector6f Time,kVel;
    for(int i=0;i<m_armParam.dof;i++)//first get the Tmax
    {
        m_armInput.jointPos(i)=InterpTtraj(m_time.now,goalToolPos(i)-m_sRoute.startJointPos(i)
                                           ,  m_armParam.jointAccLimit(i),
                                            m_armParam.jointVelLimit(i),  &Ttmp)
                +m_sRoute.startJointPos(i);
        if(Ttmp>Tmax)
        {
            Tmax=Ttmp;
        }
        Time(i)=Ttmp;
    }
    for(int i=0;i<m_armParam.dof;i++)
    {
        float a,b,c,kt,x1,x2,s,acc,v;
        kt=Tmax/Time(i);

        acc=fabs(m_armParam.jointAccLimit(i));
        v=fabs(m_armParam.jointVelLimit(i));
        s=fabs(goalToolPos(i)-m_sRoute.startJointPos(i));
        if(v*v/acc>s)
        {
            v=sqrt(s*acc);
        }
        a=v*v;
        c=acc*s;
        b=-(c*kt+a*kt );
        x1=(-b+sqrt(b*b-4.0f*a*c))/(2.0f*a);
        x2=(-b-sqrt(b*b-4.0f*a*c))/(2.0f*a);
        if(x1<=x2 )  //get the smaller velocity
        {
            kVel(i)=x1;
        }
        else
        {
            kVel(i)=x2;
        }
        kVel(i)=kVel(i)*v/fabs(m_armParam.jointVelLimit(i));
        if(kt==1 || kVel(i)<0.001)
        {
            kVel(i)=1;
        }
    }
    for(int i=0;i<m_armParam.dof;i++)
    {
        m_armInput.jointPos(i)=InterpTtraj(m_time.now,goalToolPos(i)-m_sRoute.startJointPos(i)
                                           ,  m_armParam.jointAccLimit(i),
                                            m_armParam.jointVelLimit(i)*kVel(i),  &Ttmp)
                +m_sRoute.startJointPos(i);
        if(Ttmp>Tmax)
        {
            Tmax=Ttmp;
        }
    }
    //--IK
    return(IsFinished(Tmax));
}
//float ArmBasicMove::CalCubicTrajTime()
//{
//}
bool ArmBasicMove::MoveToJointPos(Vector6f &goalJointPos,float velPercent)
{
    Vector6f startJointPos=m_sRoute.startJointPos;
    float timeMax=0;
    for(int i=0;i<m_armParam.dof;i++)
    {
        float dis=fabs(startJointPos(i)-goalJointPos(i));
        float time=fabs(1.5f*dis/(m_armParam.jointVelLimit(i)*velPercent));
        //--acc limit if short dis, the time will be small ,lead to the acc  outofrange
        float accMax=6.0f*dis/(time*time);
        if(accMax>m_armParam.jointAccLimit(i))
        {
            time=sqrt(6.0f*fabs(dis/m_armParam.jointAccLimit(i)));
        }
        //--get the max time
        if(time>timeMax)
        {
            timeMax=time;
        }
    }
    timeMax=Limit(timeMax,0.1,100);

    for(int i=0;i<6;i++)
    {
        m_armInput.jointPos(i)=InterpCubicTraj(startJointPos(i),goalJointPos(i),timeMax,m_time.now);
    }
    return(IsFinished(timeMax));
}

bool ArmBasicMove::MoveS(vector<ROUTE_NODE> point)
{
    if(m_sRoute.iSsRouteInitiated[1]==false)
    {
        vector<float> X,Y[6];
        Vector6f goalToolPos;
        X.push_back(0);
        m_sRoute.totalTime=0;
        for(int i=0;i<6;i++)
        {
            Y[i].push_back(m_sRoute.startPos(i));
        }
        for (vector<ROUTE_NODE>::iterator it=point.begin(); it != point.end(); it++)
        {
            goalToolPos<<it->xPos,it->yPos,it->zPos,
                    it->rxPos,it->ryPos,it->rzPos;
            m_sRoute.routeNum++;
            m_sRoute.totalTime+=it->time;
            X.push_back(m_sRoute.totalTime);
            for(int i=0;i<6;i++)
            {
                Y[i].push_back(goalToolPos(i));
            }
        }
        for(int i=0;i<6;i++)
        {
            m_spline[i].set_boundary(tk::spline::first_deriv,0.0,tk::spline::first_deriv,0,false);
            m_spline[i].set_points(X,Y[i]);    // X needs to be sorted, strictly increasing
        }
        m_sRoute.iSsRouteInitiated[1]=true;
    }

    Vector6f goalToolPosInterp;
    for(int i=0;i<6;i++)
    {
        goalToolPosInterp(i)=m_spline[i](m_time.now);
    }
    //    cout<<goalToolPosInterp.transpose()<<endl;
    //--return
    ArmIK(goalToolPosInterp,&m_armInput.jointPos);
    return(IsFinished(m_sRoute.totalTime));
}

bool ArmBasicMove::MoveSJ(vector<ROUTE_NODE> point)
{
    if(m_sRoute.iSsRouteInitiated[1]==false)
    {
        vector<float> X,Y[6];
        Vector6f goalJointPos;

        X.push_back(0);
        m_sRoute.totalTime=0;
        for(int i=0;i<6;i++)
        {
            Y[i].push_back(m_sRoute.startJointPos(i));
        }

        for (vector<ROUTE_NODE>::iterator it=point.begin(); it != point.end(); it++)
        {
            goalJointPos<<it->xPos,it->yPos,it->zPos,
                    it->rxPos,it->ryPos,it->rzPos;

            m_sRoute.routeNum++;
            m_sRoute.totalTime+=it->time;
            X.push_back(m_sRoute.totalTime);
            for(int i=0;i<6;i++)
            {
                Y[i].push_back(goalJointPos(i));
            }
        }
        for(int i=0;i<6;i++)
        {
            m_spline[i].set_boundary(tk::spline::first_deriv,0.0,tk::spline::first_deriv,0,true);
            m_spline[i].set_points(X,Y[i]);    // X needs to be sorted, strictly increasing
        }
        m_sRoute.iSsRouteInitiated[1]=true;
    }

    for(int i=0;i<6;i++)
    {
        m_armInput.jointPos(i)=m_spline[i](m_time.now);
    }
    return(IsFinished(m_sRoute.totalTime));
}
bool ArmBasicMove::Swing(const Vector3f &ps,const Vector3f &pe
                       ,const float swingHeight,const float totalT)
{
    Vector3f pos,tmp;
    float Hz=totalT/(cmd.speed*1.0F/m_time.Hz);
    float i=m_time.now/(cmd.speed*1.0F/m_time.Hz);
    tmp=SwingTraj(ps,pe,i,Hz,swingHeight);

    //    cout<<m_time.now<<endl;
    //    cout<<tmp.transpose()<<" "<<"ps:"<<ps.transpose() <<endl;

    pos<<tmp(2),tmp(0),tmp(1);
    //--IK
    Vector3f rpy;
    rpy=m_armInput.toolPos.block<3,1>(3,0);
    ArmIK(rpy,pos,&m_armInput.jointPos);
    return(IsFinished(totalT));
}
bool ArmBasicMove::MoveRot(Vector3f &rotCmd,float totalTime)
{
    Vector3f RPY_toolNext2toolNow;
    for(int i=0;i<3;i++)
    {
        RPY_toolNext2toolNow(i)=InterpCubicTraj(0,rotCmd(i),totalTime,m_time.now);
    }
    Matrix3f R_toolNow2base=m_sRoute.startPose.block<3,3>(0,0);

    //--method1
//    Matrix4f T_toolNext2base;
//    Vector3f pos;
//    Matrix3f R_toolNext2base=GetRotToolNext2base(rotGoal,R_toolNow2base);
//    pos<<m_armInput.toolPos(0),m_armInput.toolPos(1),m_armInput.toolPos(2);
//    T_toolNext2base<<R_toolNext2base,
//            pos,
//            (RowVector4f()<<0, 0, 0, 1).finished();
//    //--IK
//    ArmIK(T_toolNext2base,&m_armInput.jointPos);
//    return(IsFinished(totalTime));

     //--method2
    Vector3f RPY_toolNext2toolZero=GetRPYtoolNext2toolZero(R_toolNow2base,RPY_toolNext2toolNow);
    Vector6f goalToolPos;
    goalToolPos<<m_armInput.toolPos(0),m_armInput.toolPos(1),m_armInput.toolPos(2),
            RPY_toolNext2toolZero(0),RPY_toolNext2toolZero(1),RPY_toolNext2toolZero(2);
    //--IK
    ArmIK(goalToolPos,&m_armInput.jointPos);
    return(IsFinished(totalTime));
}


bool ArmBasicMove::Wait(float waitTime)
{
    return(IsFinished(waitTime));
}
bool ArmBasicMove::IsFinished(float time)
{
    m_time.now+=cmd.speed*1.0F/m_time.Hz;
    if(m_time.now>=time) //reset
    {
        m_time.now=0;
        ResetStartPos();
        ResetSroute();
        return 1;
    }
    else
    {
        return 0;
    }
}
void ArmBasicMove::ResetStartPos()
{
    m_sRoute.startPos     =m_armFeedBack.toolPos;
    m_sRoute.startPose    =m_armFeedBack.T_tool2base;
    m_sRoute.startJointPos=m_armFeedBack.jointPos;
}
void ArmBasicMove::ResetSroute()
{
    m_sRoute.Points.clear();
    m_sRoute.iSsRouteInitiated<<false,false;
    m_sRoute.routeNum=0;
    m_sRoute.totalTime=2;
}

Vector3f ArmBasicMove::Interp3DCircle(Vector3f& ps,Vector3f& pm,Vector3f& pe,float totalT,float tNow)
{
    static float theta,R;
    static Matrix4f T_c2w;
    if(tNow==0)//calculate circle parameters
    {
        float x1,x2,x3,y1,y2,y3,z1,z2,z3;
        //--test OK
        //        ps<<0.514,0,0;
        //        pm<<-0.514,0.1365,0.07;
        //        pe<<-0.514,0.0,0.175;
        //        ps<<1,0,0;
        //        pm<<0.707,-0.707,0.5;
        //        pe<<0,-1,5;
        //
        x1=ps(0);
        x2=pm(0);
        x3=pe(0);
        y1=ps(1);
        y2=pm(1);
        y3=pe(1);
        z1=ps(2);
        z2=pm(2);
        z3=pe(2);
        Matrix3f A;
        Vector3f D,ax,ay,az,az2,az3,x0;
        A<<y1*z2-y1*z3-z1*y2+z1*y3+y2*z3-y3*z2,-x1*z2+x1*z3+z1*x2-z1*x3-x2*z3+x3*z2,x1*y2-x1*y3-y1*x2+y1*x3+x2*y3-x3*y2,
                2*(x2-x1),2*(y2-y1),2*(z2-z1),
                2*(x3-x1),2*(y3-y1),2*(z3-z1);
        D<<-x1*y2*z3+x1*y3*z2+x2*y1*z3-x3*y1*z2-x2*y3*z1+x3*y2*z1,
                x1*x1+y1*y1+z1*z1-x2*x2-y2*y2-z2*z2,x1*x1+y1*y1+z1*z1-x3*x3-y3*y3-z3*z3;
        x0=-A.inverse()*D;

        Vector3f tmpR;
        tmpR=ps-x0;
        R=tmpR.norm();
        ax=(ps-x0)/R;
        // error: az=cross(ax,(pe-x0')/R)% if a,b is not orthogonal vectors ,then norm(cross(a,b))!=1
        az=ax.cross(pe-x0);
        az=az.normalized();
        az2=(pm-x0).cross(pe-x0);
        az2=az2/(az2.norm());
        az3=(pe-x0).cross(ax);
        az3=az3/(az3.norm());
        if ((az-az2).norm()>0.01 && (az-az3).norm()>0.01)
        {
            az=-az;
        }
        ay=az.cross(ax);

        T_c2w<<ax(0),ay(0),az(0),x0(0),
                ax(1),ay(1),az(1),x0(1),
                ax(2),ay(2),az(2),x0(2),
                0,0,0,1;
        Vector4f peTmp;
        peTmp<<pe(0),pe(1),pe(2),1;
        peTmp=T_c2w.inverse()*peTmp;
        Vector3f peInCircle;
        peInCircle<<peTmp(0),peTmp(1),peTmp(2);
        theta=atan2(peInCircle(1),peInCircle(0));
        if (theta<0)
        {
            theta=pi+pi+theta;
        }
    }

    float thetaD;
    Vector4f posInC,worldPos;
    //    for(int i=0;i<50;i++)//test OK
    //    {
    //        thetaD=theta/50*i;
    //        posInC<<R*cos(thetaD),R*sin(thetaD),0,1;
    //        worldPos=T_c2w*posInC;
    //        cout<<i<<": "<<worldPos.transpose()<<endl;
    //    }

    //    thetaD=InterpTtraj(m_time.now,theta,10*pi/180,10*pi/180);
    thetaD=InterpCubicTraj(0,theta,totalT,tNow);
    posInC<<R*cos(thetaD),R*sin(thetaD),0,1;
    worldPos=T_c2w*posInC;
    //    cout<<m_time.now<<": "<<worldPos.transpose()<<endl;

    //--return
    Vector3f pos=worldPos.block<3,1>(0,0);
    return pos;
}
float ArmBasicMove::InterpCubicTraj(float start,float endpos,float tf,float t)
{
    float a0,a1,a2,a3,output;
    a0=start;
    a1=0;
    a2=3/(tf*tf)*(endpos-start);
    a3=-2/(tf*tf*tf)*(endpos-start);
    output=a0+a1*t+a2*t*t+a3*t*t*t;

    return output;
}
float ArmBasicMove::InterpTtraj(float t,float s,float a, float v,float *T_all)
{
    //-- t s a v > 0 ;t_now
    float dir=sign(s);
    t=fabs(t);s=fabs(s);a=fabs(a);v=fabs(v);

    //-- interp
    if( s!=0 )
    {
        if(v*v/a>s)
        {
            v=sqrt(s*a);
        }
        float T=(a*s+v*v)/(v*a);
        t=Limit(t,0,T);
        float pos;
        if(t<=v/a)
        {
            pos=0.5*a*t*t;
        }
        else if (t<=T-v/a)
        {
            pos=v*t-v*v/(2*a);
        }
        else
        {
            pos=(2*a*v*T-2*v*v-a*a*(t-T)*(t-T))/(2*a);
        }
        *T_all=T;
        return dir*pos;
    }
    else
    {
        return 0;
    }
}
float ArmBasicMove::InterpWhenEndposChange(float S,float E,float sV,float tf,float t)
{
    float a0,a1,a2,a3,output;
    a0=S;
    a1=sV;
    a2=(3*(E-S-sV*tf)+sV*tf)/(tf*tf);
    a3=(-sV-2*a2*tf)/(3*tf*tf);
    output=a0+a1*t+a2*t*t+a3*t*t*t;

    return output;
}

Vector3f ArmBasicMove::GetRPYtoolNext2toolZero(Matrix3f& R_toolNow2base,Vector3f& RPY_toolNext2toolNow)
{
    Matrix3f R_toolNext2base,R_toolZero2base;
    R_toolZero2base=GetRotToolZero2base();

    R_toolNext2base=R_toolNow2base*rpy2rot(RPY_toolNext2toolNow);
    Vector3f RPY_toolNext2toolZero=rot2rpy(R_toolZero2base.transpose()*R_toolNext2base);
    return RPY_toolNext2toolZero;
}
void ArmBasicMove::CalculateVelAcc(Vector6f &realJointPos)
{
    //--theory  vel & acc
    m_armInput.jointVel=(m_armInput.jointPos-m_armInput.jointPosLast)*m_time.Hz;
    m_armInput.jointAcc=(m_armInput.jointVel-m_armInput.jointVelLast)*m_time.Hz;

    m_armInput.jointPosLast=m_armInput.jointPos;//useful when IK error
    m_armInput.jointVelLast=m_armInput.jointVel;

    //--real vel
    m_armFeedBack.jointRealPos=realJointPos;
    m_armFeedBack.jointRealVel=(m_armFeedBack.jointRealPos-m_armFeedBack.jointPosLast)*m_time.Hz;
    static int errorLog[6]={0,0,0,0,0,0};
    for(int i=0;i<m_armParam.dof;i++)// CAN error leads to no feedback pos
    {
        bool tag=0;
        if(m_armFeedBack.jointRealVel(i)==0)
        {
            m_armFeedBack.jointRealVel(i)=m_armFeedBack.jointRealVelLast(i);
            errorLog[i]=1;
            tag=1;
        }
        if(errorLog[i]==1 && tag==0)
        {
            m_armFeedBack.jointRealVel(i)=m_armFeedBack.jointRealVelLast(i);
            errorLog[i]=0;
        }
    }
    m_armFeedBack.jointRealAcc=(m_armFeedBack.jointRealVel-m_armFeedBack.jointRealVelLast)*m_time.Hz;

    m_armFeedBack.jointPosLast=m_armFeedBack.jointRealPos;
    m_armFeedBack.jointRealVelLast=m_armFeedBack.jointRealVel;
}



