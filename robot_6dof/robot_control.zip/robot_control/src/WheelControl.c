#include <math.h>
#include <stdio.h>
#include "robot_control/WheelControl.h"
//#include "eigen_math/common_functions.h"
#ifdef _YBROBOT
//--1800 version--//
ctrl_  ctrl={0.01,1.0f/6,1,6,         //cycle,acc_occupy,imu_update,dance_update
             {15,0.3,20},{40,4,0,20}, //motor pos_pid , vel_pid  f=50
             {1000,10,20},            //integrate limit
             {1,0.1,0.01,4,0.01,6},   //rotate_pid=[f_gain,p_gain,i_gain,p_line,i_line,limit];
             {1,30,0.4,6.0},          //dance pid [f_gain,p,i,limit]
             {0*330,0*-330},          //motor_firction
             30};                     //dacc_limit
car_    car={LOCALIMU,YBROBOT,0.0236,0.0905,1800,0};  //[0:YB 1:clean robot,r_wheel,width_car,encoder,0]
vw_interp_ vw={{1.0,0.3,0.1,0.9},     //T velocity interp
               1,0.1,{0,0}};          // acc_on,acc,acc_interp_last[2]

//--1440 version--//
//ctrl_  ctrl={0.01,1.0F/6,1,6,          //cycle,acc_occupy,imu_update,dance_update
//             {15,0.3,20},{50,4,0,60},  //motor pos_pid , vel_pid
//             {1000,10,20},             //integrate limit
//             {1,0.1,0.01, 4,0.01, 3},  //rotate_pid=[f_gain,p_gain,i_gain,p_line,i_line,limit];
//             {0.5,20,0.2,3},           //dance pid [f_gain,p,i,limit]
//             {0,-0}};                  //motor_firction
//car_    car={LOCALIMU,YBROBOT,0.0236,0.0905,1440,0};  //[0:YB 1:clean robot,r_wheel,width_car,encoder,0]
//vw_interp_ vw={{1,0.3,0.1,0.9},        //T velocity interp
//               1,0.1,{0,0}};           //acc interp

//--480 version--//
//ctrl_  ctrl={0.01,1.0F/6,1,6,          //cycle,acc_occupy,imu_update,dance_update
//             {40,1,50},{100,5,6,100},  //motor pos_pid , vel_pid
//             {1000,10,20},             //integrate limit
//             {1,0.1,0.01,8,3},         //rotate_pid=[f_gain,p_gain,i_gain,p_line,limit];
//             {0.5,20,0.2,3.14},        //dance pid [f_gain,p,i,limit]
//             {0,-0}};                  //motor_firction
//car_    car={LOCALIMU,YBROBOT,0.0236,0.0905,480,0};
#endif
#ifdef _CLEANROBOT
ctrl_  ctrl={0.01,2.0F/5,1,6,            //cycle,acc_occupy,imu_update
             {400,3,96},{960,240,0,1920},//motor pos_pid , vel_pid
             {16000,100,200},            //integrate limit
             {1,0.1,0.01, 1,0.01, 1.57}, //rotate_pid=[f_gain,p_gain,i_gain,p_line,limit];
             {0.5,5,0.01,1.57},          //dance pid [f_gain,p,i,limit]
             {0*4400,0*-1500}};          //motor_firction
car_    car={LOCALIMU,CLEANROBOT,0.032,0.207,560,2785.2};
vw_interp_ vw={{1,0.3,0.1,0.9},          //T velocity interp
               1,0.5,{0,0}};             //acc interp
#endif

#ifdef _HOMEROBOT
ctrl_  ctrl={0.01,2.0F/5,1,6,            //cycle,acc_occupy,imu_update
             {400,3,96},{960,240,0,1920},//motor pos_pid , vel_pid
             {16000,100,200},            //integrate limit
             {1,0.1,0.01, 1,0.01, 1.57}, //rotate_pid=[f_gain,p_gain,i_gain,p_line,limit];
             {0.5,5,0.01,1.57},          //dance pid [f_gain,p,i,limit]
             {0*4400,0*-1500}};          //motor_firction
car_    car={LOCALIMU,CLEANROBOT,0.0625,0.43,560,2785.2};
vw_interp_ vw={{1,0.3,0.1,0.9},          //T velocity interp
               1,0.5,{0,0}};             //acc interp
#endif

input_  input={0,0,0,0,0,0,{0,0},V_W,0};
inner_  inner={0,0,1,0};
sensor_ sensor={0,0,0};
dir_    dir={0,0,0,0};
printf_ printf_option={0,0,0,0 ,0,0,0,0};

pos_ pos={0,{0,0},{0,0},{0,0} };

//--init
int calc_motion_control_cycle_params_init(float ctrl_cycle ,float acc_occupy,float imu_update)
{
    ctrl.cycle=ctrl_cycle;
    ctrl.acc_occupy=acc_occupy;
    ctrl.imu_update=imu_update;
    return 1;
}
int calc_motion_control_speed_pid_params_init(float p,float i,float d)
{
    ctrl.vel_pid[0]=p;
    ctrl.vel_pid[1]=i;
    ctrl.vel_pid[2]=d;
    return 1;
}
int calc_motion_control_postion_pid_params_init(float p,float i,float d)
{
    ctrl.pos_pid[0]=p;
    ctrl.pos_pid[1]=i;
    ctrl.pos_pid[2]=d;
    return 1;
}
int calc_motion_control_struct_param_init(float r_wheel,float width_car,float motor_encoders)
{
    if(width_car<=0 || r_wheel<=0 || motor_encoders<=0)
    {
        printf("width_car & r_wheel & motor_encoders has to be >0 \r\n");
        return -1;
    }
    else
    {
        car.r_wheel=r_wheel;
        car.width_car=width_car;
        car.encoder=motor_encoders;
        return 1;
    }
}
int calc_motion_control_algorithm_reinit()
{
    clear_cmd();
    return 1;
}

//--set & get
void reset_direction()
{
    //--angle
    dir.real_angle=0;
    dir.theory_anlge=0;
    dir.real_w=0;
    dir.start_angle=0;
}
void calc_motion_control_acc_set(float acc)
{
    vw.acc=acc;
}
float get_acc()
{
    return vw.acc;
}
void set_dance_interp_period(float num)
{
    ctrl.dance_update=num;
}
void calc_motion_control_r_turn_set(float r_turn)
{
    input.r_turn=r_turn;
}

int calc_motion_control_target_set(unsigned char type,bool new_cmd,
                                   float vel_forward,float w_rot,float pos_forward,float angle_rot)
{
    vw.acc_on=1;
    //--printf option
    //printf_option.pid_pos_right = 0;
    printf_option.pid_vel_right = 0;
    //printf_option.car_rotate_pid = 0;

    //--init
    inner.end_flag=0;
    car.k_encoder=car.encoder/(car.r_wheel*2*PI_HD);

    //--update
    bool update=1;
    if((type==V_W_IMU && input.cmd_last==W_ANGLE_IMU) ||
            (type==W_ANGLE_IMU && input.cmd_last==V_W_IMU)) //V_W_IMU & W_ANGLE_IMU is the same mode ,dont reset
    {
        update=0;
    }
    if(type!=input.cmd_last && update==1)
    {
        calc_motion_control_algorithm_reinit();
    }

    if(type==W_ANGLE_IMU && input.cmd_last!=W_ANGLE_IMU)   //update theory_anlge to clear the angle accumated by other mode
    {
        dir.theory_anlge=dir.real_angle;
    }
    input.cmd_last=type;

    //--cmd copy
    switch(type)
    {
    case V_W:
        pos_forward=0;
        angle_rot=0;

        input.vel_forward=vel_forward;
        input.w_rot=w_rot;
        break;
    case V_DIS:
        w_rot=0;
        angle_rot=0;

        if(vel_forward==0)
        {
            vel_forward=sign1(pos_forward)*0.05f;
        }
        input.pos_forward=pos_forward;
        input.t_d=fabs(pos_forward/vel_forward);
        input.t_d=limit(input.t_d,0.1f,100.0f);
        break;
    case W_ANGLE:
        vel_forward=0;
        pos_forward=0;

        input.angle_rot=angle_rot;
        if(w_rot==0)
        {
            w_rot=sign1(angle_rot)*30.0f*PI_HD/180.0f;
        }
        input.t_d=fabs(angle_rot/w_rot);
        input.t_d=limit(input.t_d,0.8f,100.0f);
        break;

    case V_W_IMU :
        pos_forward=0;
        angle_rot=0;

        input.vel_forward=vel_forward;
        input.w_rot=w_rot;
        input.angle_rot=0;
        break;
    case W_ANGLE_IMU :
        vel_forward=0;
        pos_forward=0;

        input.vel_forward=0;
        input.w_rot=w_rot;
        input.angle_rot=angle_rot;
        break;
    case V_ANGLE_IMU:
        w_rot=0;
        pos_forward=0;

        input.dance[0]=vel_forward;
        input.dance[1]=angle_rot;
        break;
    default:
        //printf("input type error! \r\n");
        return -1;
    }
    //input.r_turn=r_turn;
    input.is_new_cmd=new_cmd;
    inner.ctrl_mode=type;

    return 1;
}
int calc_motion_control_res_get(float *left_val,float *right_val)
{
    //--get sensor data & calculate
    float imu_roll=0,imu_pitch=0,imu_yaw=0;
    int encoder_left=0,encoder_right=0;

#ifdef _YBROBOT
    ezapp_get_backed_imu_rpy(&imu_roll,&imu_pitch,&imu_yaw);
    ezapp_get_relative_encoder(&encoder_left,&encoder_right);
#endif
#ifdef _CLEANROBOT
    bsp_get_imu_encoder(&imu_yaw,&encoder_left,&encoder_right);
#endif

    sensor.encoder_right=encoder_right;
    sensor.encoder_left=encoder_left;
    sensor.imu_yaw=imu_yaw;

    cal_imu_yaw();

    //--get motor pwm
    if(left_val==NULL || right_val==NULL)
    {
        //printf("pointer error! \r\n");
        return -1;
    }
    int ret=0;
    switch (inner.ctrl_mode)
    {
    case V_W:         //always return 0
        ret=car_speed_control(input.vel_forward,input.w_rot,right_val,left_val);
        break;
    case V_DIS:       //return 1 when completed
        ret=line_move(input.pos_forward,input.t_d,right_val,left_val);
        break;
    case W_ANGLE:     //return 1 when completed
        ret=circle_move(input.angle_rot,input.t_d,right_val,left_val);
        break;

    case V_W_IMU:     //always return 0
        ret=car_speed_control_with_imu(input.vel_forward,input.w_rot,0,
                                       right_val,left_val);
        break;
    case W_ANGLE_IMU: //return 1 when completed
        ret=car_speed_control_with_imu(0,input.w_rot,input.angle_rot,
                                       right_val,left_val);
        break;
    case V_ANGLE_IMU: //always return 0
        dance_interp(input.dance[0],input.dance[1]);//interp pos
        ret=dance_control(input.vel_forward,input.w_rot,right_val,left_val);
        break;
    default:
        break;
    }

    if(ret==1)
    {
        calc_motion_control_algorithm_reinit();//if one movement finished , reinit!
    }

    return ret;
}

//--inner functions api : position control
float clear_cmd()
{
    inner.end_flag=1;  //reset flag
    inner.count_time=1;//reset time
    input.r_turn=0;    //reset r

    //--api function
    dance_interp(0,0);
    angle_pid_with_imu(0);

    //--inner function
    car_IK_circle(0);
    pid_pos_right(0,0);
    pid_pos_left(0,0);
    pid_vel_right(0,0);
    pid_vel_left(0,0);

    car_rotate_pid(0,0,0);

    //--imu reset
    low_filter(0,0);
    cal_imu_yaw();

    //--for YB robot
    if(car.imu_type==LOCALIMU)
    {
        reset_direction();
    }

    //--vw_interp
    vw.acc_interp_last[0]=0;
    vw.acc_interp_last[1]=0;

    //--position control
    pos.encoder_desired[0]=0;
    pos.encoder_desired[1]=0;
    pos.encoder_feedback[0]=0;
    pos.encoder_feedback[1]=0;
    pos.encoder_vd[0]=0;
    pos.encoder_vd[1]=0;

    //--
    inner.end_flag=0;  //reset flag

    return inner.pos_d;
}

float get_pos()
{
    return inner.pos_d;
}

int line_move(float dis_d ,float t_d,int *pwm1,int*pwm2)
{
    float encoder_pos_d;

    //inner.pos_d=interp(dis_d,t_d); //old interp method
    inner.pos_d=interp_cubic(dis_d,t_d);
    encoder_pos_d=car_IK_line(inner.pos_d);

    pos.encoder_desired[0]=encoder_pos_d;
    pos.encoder_desired[1]=encoder_pos_d;
    position_control(pwm1,pwm2);

    return inner.end_flag;
}
int circle_move(float dis_d ,float t_d,int *pwm1,int*pwm2)
{
    float *encoder_pos_d;

    //inner.pos_d=interp(dis_d,t_d); //old interp method
    inner.pos_d=interp_cubic(dis_d,t_d);
    encoder_pos_d=car_IK_circle(inner.pos_d);

    pos.encoder_desired[0]=encoder_pos_d[0];
    pos.encoder_desired[1]=encoder_pos_d[1];
    position_control(pwm1,pwm2);

    return inner.end_flag;
}

//--pos control
void position_control(int *pwm1,int*pwm2)
{
    if(inner.ctrl_mode!=W_ANGLE && inner.ctrl_mode!=V_DIS)
    {
        pos.encoder_desired[0]+=pos.encoder_vd[0];
        pos.encoder_desired[1]+=pos.encoder_vd[1];
    }

    pos.encoder_feedback[0]+=sensor.encoder_right;
    pos.encoder_feedback[1]+=sensor.encoder_left;				   //get encoder pos

    if(fabs(pos.encoder_feedback[0])>car.encoder*100000||
            fabs(pos.encoder_feedback[1])>car.encoder*100000)
    {
        clear_cmd();
    }

    for (int i=0;i<2;i++) //error limit
    {
        float error=pos.encoder_desired[i]-pos.encoder_feedback[i];
        if(fabs(error)> car.encoder/6)
        {
            pos.encoder_desired[i]=pos.encoder_feedback[i]+sign1(error)*car.encoder/6;
        }
    }

    *pwm1=pid_pos_right(pos.encoder_desired[0],pos.encoder_feedback[0]);
    *pwm2=pid_pos_left(pos.encoder_desired[1],pos.encoder_feedback[1]);


    if(printf_option.encoder_v==1 && pos.on==1)
    {
        printf("encoder v_d v_real:%.2f,%d \r\n",pos.encoder_vd[0],sensor.encoder_right);
    }
}

//--inner api functions : velocity control
int wheel_speed_control(float cmd_vel_l,float cmd_vel_r,int *pwm1,int*pwm2)
{
    float encoder_vel_d[2];

    encoder_vel_d[0]=cmd_vel_r*car.k_encoder*ctrl.cycle;
    encoder_vel_d[1]=cmd_vel_l*car.k_encoder*ctrl.cycle;

    if(pwm1==NULL || pwm2==NULL)
    {
        printf("pointer error! \r\n");
        return -1;
    }
    *pwm1=pid_vel_right(encoder_vel_d[0],sensor.encoder_right);
    *pwm2=pid_vel_left(encoder_vel_d[1],sensor.encoder_left);
    return 0;
}

int car_speed_control(float cmd_vel,float cmd_w,float *pwm1,float *pwm2)
{
    float encoder_vel_d[2];
    car_IK_to_encoder(cmd_vel,cmd_w,encoder_vel_d);

    if(pwm1==NULL || pwm2==NULL)
    {
        printf("pointer error! \r\n");
        return -1;
    }

    if(pos.on==0)
    {
        *pwm1=pid_vel_right(encoder_vel_d[0],sensor.encoder_right);
        *pwm2=pid_vel_left(encoder_vel_d[1],sensor.encoder_left);
    }
    else
    {
        pos.encoder_vd[0]=encoder_vel_d[0];
        pos.encoder_vd[1]=encoder_vel_d[1];
        position_control(pwm1,pwm2);
    }

    *pwm1=encoder_vel_d[0];
    *pwm2=encoder_vel_d[1];

    return 0;
}

int car_speed_control_with_imu(float cmd_vel,float cmd_w,float angle_d,int *pwm1,int*pwm2)
{
    int ret=0;
    float encoder_vel_d[2];
    cmd_w=car_rotate_pid(cmd_w,angle_d,&ret);   // rotate speed PID method 1
    //cmd_w=car_rotate_pid2(cmd_w,angle_d,&ret);// rotate speed PID method 2
    car_IK_to_encoder(cmd_vel,cmd_w,encoder_vel_d);

    if(pwm1==NULL || pwm2==NULL)
    {
        printf("pointer error! \r\n");
        return -1;
    }

    if(pos.on==0)
    {
        *pwm1=pid_vel_right(encoder_vel_d[0],sensor.encoder_right);
        *pwm2=pid_vel_left(encoder_vel_d[1],sensor.encoder_left);
    }
    else
    {
        pos.encoder_vd[0]=encoder_vel_d[0];
        pos.encoder_vd[1]=encoder_vel_d[1];
        position_control(pwm1,pwm2);
    }

    if (ret==1)
    {
        *pwm1=0;
        *pwm2=0;
        return 1;
    }
    else
    {
        return 0;
    }
}

//--dance motion control
void dance_interp(const float cmd_vel,const float cmd_w)
{
    static float cmd_vel_last=0,cmd_w_last=0;
    static int count=1;
    float period=ctrl.dance_update;
    if(cmd_vel_last!=cmd_vel || cmd_w_last!= cmd_w)
    {
        input.vel_forward=(cmd_vel-cmd_vel_last)/period*count+cmd_vel_last;
        input.w_rot=(cmd_w-cmd_w_last)/period*count+cmd_w_last;
        count++;
        if(count>period)
        {
            count=1;//reset
            cmd_vel_last=cmd_vel;
            cmd_w_last=cmd_w;
        }
    }
    else
    {
        input.vel_forward=cmd_vel;
        input.w_rot=cmd_w;
        count=1;
    }
    if(printf_option.dance_interp)
    {
        printf("interp in,out:%.4f,%.4f\r\n",cmd_w, input.w_rot );
    }

    //--clear
    if(inner.end_flag==1) //clear static var
    {
        count=1;
        cmd_vel_last=0;
        cmd_w_last=0;
    }
}
int dance_control(float cmd_vel,float cmd_w, int *pwm1,int*pwm2)
{
    float encoder_vel_d[2];
    cmd_w=angle_pid_with_imu(cmd_w);
    //--car IK
    car_IK_to_encoder(cmd_vel,cmd_w,encoder_vel_d);

    if(pwm1==NULL || pwm2==NULL)
    {
        printf("pointer error! \r\n");
        return -1;
    }

    if(pos.on==0)
    {
        *pwm1=pid_vel_right(encoder_vel_d[0],sensor.encoder_right);
        *pwm2=pid_vel_left(encoder_vel_d[1],sensor.encoder_left);
    }
    else
    {
        pos.encoder_vd[0]=encoder_vel_d[0];
        pos.encoder_vd[1]=encoder_vel_d[1];
        position_control(pwm1,pwm2);
    }

    return 0;
}
float angle_pid_with_imu(float cmd_w )
{
    static float angle_d=0,angle_d_last=0;
    static float angle_error=0;
    //angle_d+=cmd_w*ctrl.cycle;//goal angle
    angle_d=cmd_w;

    if(angle_d_last==0)
    {
        angle_d_last=angle_d;
    }
    float w_cmd=(angle_d-angle_d_last)/ctrl.cycle;
    w_cmd=low_filter(0.1,w_cmd);
    angle_d_last=angle_d;

    //--dance pid
    float f_gain,p_gain,i_gain,limit;
    f_gain=ctrl.dance_pid[0];
    p_gain=ctrl.dance_pid[1];
    i_gain=ctrl.dance_pid[2];
    limit =ctrl.dance_pid[3];

    float dy=angle_d-dir.real_angle;
    float w_out=angle_pid(w_cmd,dy,f_gain,p_gain,i_gain,limit,&angle_error);

    if(printf_option.dance_pid)
    {
        printf("w_out,w_d,w; dir_d,dir; imu %.2f, %.2f, %.2f , %.2f , %.2f, %.2f\r\n",
               w_out,w_cmd,dir.real_w,angle_d,dir.real_angle,sensor.imu_yaw);
    }

    //--clear & return
    if(inner.end_flag==1) //clear static var
    {
        angle_d=0;
        angle_d_last=0;
        angle_error=0;
    }
    return w_out;
}

//inner function : car kinematic & motor pid functions
float interp_cubic(float dis_d ,float t_d)
{
    static float last_cmd=0,start_pos=0,last_pos=0,sV=0,output=0;
    static bool is_interrupt=0;
    if(inner.count_time==1)//init
    {
        last_cmd=dis_d;
        start_pos=0;
        last_pos=0;
        sV=0;
        output=0;
        is_interrupt=0;
    }
    if(last_cmd!=dis_d || input.is_new_cmd==1)//--if interrupt
    {
        last_cmd=dis_d;  //update
        is_interrupt=1;
        inner.count_time=1;

        sV=(output-last_pos)/ctrl.cycle;//get current vel
        last_pos=output; //update
        start_pos=output;

        input.is_new_cmd=0;
    }

    //--interp
    float t=inner.count_time*ctrl.cycle;
    if(is_interrupt==0)
    {
        float start=0;
        float a0,a1,a2,a3;
        a0=start;
        a1=0;
        a2=3/(t_d*t_d)*(dis_d-start);
        a3=-2/(t_d*t_d*t_d)*(dis_d-start);

        last_pos=output;
        output=a0+a1*t+a2*t*t+a3*t*t*t;
    }
    else
    {
        last_pos=output;
        output=interp_when_endpos_change(start_pos,dis_d+start_pos,sV,t_d,t);
    }
    //--t
    if (t<=t_d)
    {
        inner.count_time++;
    }
    else //reset when finished
    {
        inner.count_time=1;
        inner.end_flag=1;
    }
    //printf("%.2f,%.2f\r\n",t,output);
    return output;
}
float interp_when_endpos_change(float S,float E,float sV,float tf,float t)
{
    float a0,a1,a2,a3,output;
    a0=S;
    a1=sV;
    a2=(3*(E-S-sV*tf)+sV*tf)/(tf*tf);
    a3=(-sV-2*a2*tf)/(3*tf*tf);
    output=a0+a1*t+a2*t*t+a3*t*t*t;

    return output;
}
float interp(float dis_d ,float t_d)
{
    float t_acc, t_now, a;
    float pos_d;

    t_now=inner.count_time*ctrl.cycle;
    t_acc=ctrl.acc_occupy*t_d;
    if (t_acc>1)  //avoid acc period takes up too much time
    {
        t_acc=1;
    }
    a=dis_d/(t_acc*t_d-t_acc*t_acc);//(t_acc*t_d-t_acc*t_acc) won`t be zero

    if (t_now<=t_acc)
    {
        pos_d=0.5f*a*t_now*t_now;
    }
    else if( t_now>t_acc && t_now<=t_d-t_acc)
    {
        pos_d=0.5f*a*t_acc*t_acc+a*t_acc*(t_now-t_acc);
    }
    else
    {
        float v1=a*t_acc;
        float v2=a*(t_d-t_now);
        pos_d=0.5f*a*t_acc*t_acc+a*t_acc*(t_d-2*t_acc)+0.5f*(v1+v2)*(t_now-t_d+t_acc);
    }

    if (t_now<=t_d)
    {
        inner.count_time++;
    }
    else //reset when finished
    {
        inner.count_time=1;
        inner.end_flag=1;
    }
    //printf(" %.2f, %.2f \r\n",t_now,pos_d);
    return pos_d;
}

float car_IK_line(float pos_d)
{
    float encoder_pos;

    encoder_pos=pos_d*car.k_encoder;
    return encoder_pos;
}

float *car_IK_circle(float pos_d)
{

    static float pos_d_last=0;
    static float encoder_pos[2]={0};
    float v_d ;

    v_d=(pos_d-pos_d_last)/ctrl.cycle;//cycle>0
    pos_d_last=pos_d; //update

    float encoder_vel_d[2]={0,0};
    if(inner.end_flag!=1)
    {
        car_IK_to_encoder(0,v_d,encoder_vel_d);
    }
    encoder_pos[0]+=encoder_vel_d[0];
    encoder_pos[1]+=encoder_vel_d[1];

    if (inner.end_flag==1) //reset
    {
        pos_d_last=0;
        encoder_pos[0]=0;
        encoder_pos[1]=0;
    }
    return encoder_pos;
}

void acc_interp(float *encoder_vel_d)
{
    if (vw.acc_on==1)
    {
        for(int i=0;i<2;i++)
        {
            float delta=encoder_vel_d[i]-vw.acc_interp_last[i];
            if(fabs(delta)>vw.acc*car.k_encoder*ctrl.cycle*ctrl.cycle)
            {
                encoder_vel_d[i]=vw.acc_interp_last[i]+sign1(delta)*vw.acc*car.k_encoder*ctrl.cycle*ctrl.cycle;
            }
            else
            {
                //encoder_vel_d[i]=encoder_vel_d[i];
            }
            vw.acc_interp_last[i]=encoder_vel_d[i];//update last
        }
    }
}
void car_IK_to_encoder(float cmd_vel,float cmd_w,float *encoder_vel_d)
{
    cal_encoder_v(cmd_vel, cmd_w,encoder_vel_d);
    //acc_interp(encoder_vel_d);
}
void cal_encoder_v(float cmd_vel,float cmd_w,float *encoder_vel_d)
{
    if(input.r_turn!=0 ) // rotate with r_trun
    {
        encoder_vel_d[1]=(2*input.r_turn-car.width_car)*cmd_w/2*car.k_encoder*ctrl.cycle;
        encoder_vel_d[0]=encoder_vel_d[1]+cmd_w*car.width_car*car.k_encoder*ctrl.cycle;
    }
    else
    {
        encoder_vel_d[0]=(2*cmd_vel+cmd_w*car.width_car)/2;//*car.k_encoder*ctrl.cycle;
        encoder_vel_d[1]=encoder_vel_d[0]+(-cmd_w*car.width_car);//*car.k_encoder*ctrl.cycle;
    }
}
float pid_motor(float yd, float dy,float ddy,float *y_integral,float integrate_limit,
                float p_forward,float p_gaid,float i_gaid,float d_gaid)
{
    float u=0;
    if(fabs(i_gaid*(*y_integral))>integrate_limit)    //integral limit
    {
        (*y_integral)=sign1((*y_integral))*integrate_limit/i_gaid;
    }

    u=p_forward*yd+p_gaid*dy+i_gaid*(*y_integral)+d_gaid*ddy;
    u=motor_friction(yd,u);
    u=limit(u,-integrate_limit,integrate_limit);

    return u;
}
int pid_pos_right(float yd, float y)
{
    static float dy_last=0,y_integral=0;
    float dy,ddy,e,u=0;
    //float integrate_limit,integrate_a,integrate_b;
    float integrate_limit;
    integrate_limit=ctrl.integrate[0];
    //integrate_a=ctrl.integrate[1];
    //integrate_b=ctrl.integrate[2];

    dy=yd-y;
    ddy=dy-dy_last;
    e=(dy+dy_last)/2; //Trapezoidal integration
    dy_last=dy;       //update dy_last

    y_integral+=e;
    //y_integral+=e*integrate_change( e,integrate_a,integrate_b);

    u=pid_motor(yd,dy,ddy,&y_integral,integrate_limit,
                0,ctrl.pos_pid[0],ctrl.pos_pid[1],ctrl.pos_pid[2]);

    if(inner.end_flag==1)
    {
        dy_last=0;
        y_integral=0;
        u=0;
    }
    if(printf_option.pid_pos_right)
    {
        printf("yd,y,u,y_i:%.2f, %.2f,%.2f ,%.2f\r\n",yd,y,u,y_integral);
    }
    return u ;
}

int pid_pos_left(float yd, float y)
{
    static float dy_last=0,y_integral=0;
    float dy,ddy,e, u=0;
    //float integrate_limit,integrate_a,integrate_b;
    float integrate_limit;
    integrate_limit=ctrl.integrate[0];
    //integrate_a=ctrl.integrate[1];
    //integrate_b=ctrl.integrate[2];

    dy=yd-y;
    ddy=dy-dy_last;
    e=(dy+dy_last)/2; //Trapezoidal integration
    dy_last=dy;       //update dy_last

    y_integral+=e;
    //y_integral+=e*integrate_change( e,integrate_a,integrate_b);
    u=pid_motor(yd,dy,ddy,&y_integral,integrate_limit,
                0,ctrl.pos_pid[0],ctrl.pos_pid[1],ctrl.pos_pid[2]);

    if(inner.end_flag==1)
    {
        dy_last=0;
        y_integral=0;
        u=0;
    }
    if(printf_option.pid_pos_left)
    {
        printf("yd,y,u,y_i:%.2f, %.2f,%.2f ,%.2f\r\n",yd,y,u,y_integral);
    }
    return u ;
}
void change_vel_i_gain(float dy,float *e,bool is_on)
{
#ifdef _YBROBOT
    //--get initial value
    static float i_init=4;
    static bool is_init=1;
    if(is_init==1)
    {
        i_init=ctrl.vel_pid[1];
        is_init=0;
    }
    //--cal border min encoder v
    float w_border= 30.0f/180*PI_HD; //degree/s
    float k_i_max=14;
    float v_border=0.01;

    if(inner.ctrl_mode==V_ANGLE_IMU)
    {
        v_border =0.12;  //other modes when v>0.03cm/s not works
    }
    else
    {
        v_border=0.01;
    }

    float encoder_v[2],v_limit,v_limit2;
    cal_encoder_v(0,w_border,encoder_v);
    v_limit =get_fabs_max(encoder_v[0],encoder_v[1]);

    cal_encoder_v(v_border,0,encoder_v);
    v_limit2=get_fabs_max(encoder_v[0],encoder_v[1]);
    v_limit=get_fabs_max(v_limit,v_limit2);


    if(fabs(input.w_rot)<=w_border && fabs(input.vel_forward)<=v_border && is_on==1 )
    {
        //--method1
        int m=1;
        if(m==1)
        {
            float k=(1.0f-k_i_max)/w_border*fabs(input.w_rot)+k_i_max;
            if(input.w_rot==0)
            {
                k=(1.0f-k_i_max)/v_border*fabs(input.vel_forward)+k_i_max;
            }
            ctrl.vel_pid[1]=k*i_init;

            *e=limit(*e,-v_limit,v_limit);
        }

        //--method2  not worked ,  because dy changes quikly
        if(m==2)
        {
            dy=limit(dy,-v_limit,v_limit);
            float k=(1.0f-k_i_max)/v_limit*fabs(dy)+k_i_max;
            ctrl.vel_pid[1]=k*i_init;
        }
    }
    else
    {
        ctrl.vel_pid[1]=i_init;
    }
    //printf("%.2f,%.2f,%.2f\r\n",input.vel_forward,input.w_rot,ctrl.vel_pid[1]);
#endif
}
void dacc_limit(float y, float *v_last,float *a_last, bool *is_on)
{
    float a_now,dacc;
    a_now=y-(*v_last);
    (*v_last)=y;
    dacc=a_now-(*a_last);
    (*a_last)=a_now;

    if(fabs(dacc)>ctrl.dacc_limit)
    {
        is_on=0;
    }
}
int pid_vel_right(float yd, float y)
{
    static float dy_last=0,y_integral=0;
    float dy,ddy,e, u=0;
    //float integrate_limit,integrate_a,integrate_b;
    float integrate_limit;
    integrate_limit=ctrl.integrate[0];
    //integrate_a=ctrl.integrate[1];
    //integrate_b=ctrl.integrate[2];

    dy=yd-y;
    ddy=dy-dy_last;
    e=(dy+dy_last)/2; //Trapezoidal integration
    dy_last=dy;       //update dy_last

    //--calculate dacc
    static float v_last,a_last;
    static bool is_on=1;
    float a_now,dacc;
    a_now=y-v_last;
    v_last=y;
    dacc=a_now-a_last;
    a_last=a_now;

    if(fabs(dacc)>ctrl.dacc_limit)
    {
        is_on=0;
        //printf("%s dance mode find shocking and change mode\r\n",__func__);
    }

    static int n=1;
    if((n++)%10==0)
    {
        //printf("dacc: %.2f \r\n",dacc);
        n=1;
    }
    //--change i
    change_vel_i_gain(dy,&e,is_on);

    //--PID
    y_integral+=e;
    //y_integral+=e*integrate_change( e,integrate_a,integrate_b);
    u=pid_motor(yd,dy,ddy,&y_integral,integrate_limit,
                ctrl.vel_pid[3],ctrl.vel_pid[0],ctrl.vel_pid[1],ctrl.vel_pid[2]);

    if(inner.end_flag==1)
    {
        dy_last=0;
        y_integral=0;
        u=0;
        v_last=0;a_last=0;is_on=1;
    }
    if(printf_option.pid_vel_right)
    {
        printf("r-yd,y,u,y_i:%.2f, %.2f,%.2f ,%.2f\r\n",yd,y,u,y_integral);
    }
    if(printf_option.encoder==1)
    {
        printf("d,r,l:%.2f,%d,%d\r\n",yd,sensor.encoder_right,sensor.encoder_left);
    }
    return u ;
}

int pid_vel_left(float yd, float y)
{
    static float dy_last=0,y_integral=0;
    float dy,ddy,e,u=0;
    //float integrate_limit,integrate_a,integrate_b;
    float integrate_limit;
    integrate_limit=ctrl.integrate[0];
    //integrate_a=ctrl.integrate[1];
    //integrate_b=ctrl.integrate[2];

    dy=yd-y;
    ddy=dy-dy_last;
    e=(dy+dy_last)/2; //Trapezoidal integration
    dy_last=dy;       //update dy_last

    //--calculate dacc
    static float v_last,a_last;
    static bool is_on=1;
    float a_now,dacc;
    a_now=y-v_last;
    v_last=y;
    dacc=a_now-a_last;
    a_last=a_now;

    if(fabs(dacc)>ctrl.dacc_limit)
    {
        is_on=0;
        //printf("%s dance mode find shocking and change mode\r\n",__func__);
    }
    //--change i
    change_vel_i_gain(dy,&e,is_on);

    //--PID
    y_integral+=e;
    //y_integral+=e*integrate_change( e,integrate_a,integrate_b);

    u=pid_motor(yd,dy,ddy,&y_integral,integrate_limit,
                ctrl.vel_pid[3],ctrl.vel_pid[0],ctrl.vel_pid[1],ctrl.vel_pid[2]);

    if(inner.end_flag==1)
    {
        dy_last=0;
        y_integral=0;
        u=0;
        v_last=0;a_last=0;is_on=1;
    }
    if(printf_option.pid_vel_left)
    {
        printf("l-yd,y,u,y_i:%.2f, %.2f,%.2f ,%.2f\r\n",yd,y,u,y_integral);
    }
    return u;
}

float integrate_change(float e,float integrate_a,float integrate_b)
{
    float k_integrate;
    if (fabsf(e)<integrate_a)  							//ctrl.integrate optimization
    {
        k_integrate=1.5;
    }
    else if( fabsf(e)<integrate_b)
    {
        k_integrate=( integrate_b-fabsf(e) )/integrate_a*1.5f;  //ctrl.integrate speed varies from [0,1], integrate_a>0
    }
    else
    {
        k_integrate=0.5;
    }
    return k_integrate;
}
float motor_friction(float dy,float u)
{
    if(dy>0)
    {
        u=u+ctrl.motor_firction[0];
    }
    if(dy<0)
    {
        u=u+ctrl.motor_firction[1];
    }
    return u;
}
float angle_pid(float cmd_w_d,float dy,float f_gain ,float p_gain,float i_gain,float limit_i,float *integrate_error)
{
    (*integrate_error)+=dy;
    if (fabs((*integrate_error)*i_gain)>limit_i)
    {
        (*integrate_error)=sign1((*integrate_error))*limit_i/i_gain;
    }
    float w_output=f_gain*cmd_w_d+p_gain*dy+i_gain*(*integrate_error);

    w_output=limit(w_output,-limit_i,limit_i);

    return w_output;
}
float car_rotate_pid2(float cmd_w_d,float angle_d,int *ret)
{
    static float w_output=0;
    static float angle_d_last=0 ;
    //--if new angle_d , then start from current angle
    if(angle_d_last==0)
    {
        angle_d_last=angle_d;
    }
    if(angle_d_last!=angle_d)
    {
        dir.start_angle=dir.real_angle;
        angle_d_last=angle_d;
    }

    //--four different cases:
    //1. w_rot==0 && angle_rot ==0 ,line velocity control with imu feedback
    //2. w_rot!=0 && angle_rot ==0 ,rotate at velocity of w_rot
    //3. w_rot==0 && angle_rot !=0 ,rotate to angle_d at a default w_rot
    //4. w_rot!=0 && angle_rot !=0 ,rotate to angle_d at velocity of w_rot
    if (cmd_w_d==0 && angle_d==0)  // 1
    {
    }
    if (cmd_w_d!=0 && angle_d==0)  // 2
    {
    }
    if (cmd_w_d==0 && angle_d!=0)  // 3
    {
        cmd_w_d=50*PI_HD/180;
    }
    if (cmd_w_d!=0 && angle_d!=0)  // 4
    {
        cmd_w_d=w_interp(dir.start_angle,cmd_w_d,angle_d);
        if ( fabs(dir.real_angle-dir.start_angle)>=fabs(angle_d) )  //rotate direction control
        {
            if(ret==NULL)
            {
                printf("pointer error! \r\n");
                return -1;
            }
            *ret=1;
            inner.end_flag=1;
            dir.start_angle=dir.real_angle;
        }
    }

    dir.theory_anlge+=cmd_w_d*ctrl.cycle;
    w_output=angle_pid_with_imu(dir.theory_anlge);
    //--clear & return
    if(inner.end_flag==1) //clear static var
    {
        w_output=0;
        angle_d_last=0;
    }
    return w_output;
}
float car_rotate_pid(float cmd_w_d,float angle_d,int *ret)
{
    static float w_output=0;
    static float angle_d_last=0;
    static float angle_error1=0,angle_error2=0;
    //--rotate pid
    float f_gain,p_gain,i_gain,p_line,i_line,w_limit;
    f_gain=ctrl.rotate_pid[0];
    p_gain=ctrl.rotate_pid[1];
    i_gain=ctrl.rotate_pid[2];
    p_line=ctrl.rotate_pid[3];
    i_line=ctrl.rotate_pid[4];
    w_limit =ctrl.rotate_pid[5];

    //--calculate imu yaw
    //--if new angle_d , then start from current angle
    if(angle_d_last==0) //first time set
    {
        angle_d_last=angle_d;
    }

    if ( input.cmd_last == W_ANGLE_IMU)
    {
        if(angle_d_last!=angle_d || input.is_new_cmd==1) //if new cmd
        {
            dir.theory_anlge=dir.real_angle;
            angle_d_last=angle_d;

            input.is_new_cmd=0;
        }
    }
    //--four different cases:
    //1. w_rot==0 && angle_rot ==0 ,line velocity control with imu feedback
    //2. w_rot!=0 && angle_rot ==0 ,rotate at velocity of w_rot
    //3. w_rot==0 && angle_rot !=0 ,rotate to angle_d at a default w_rot
    //4. w_rot!=0 && angle_rot !=0 ,rotate to angle_d at velocity of w_rot
    if ( input.cmd_last == V_W_IMU)
    {
        if (cmd_w_d==0 && angle_d==0)  // 1  line
        {
            float dy=dir.theory_anlge-dir.real_angle;
            w_output=angle_pid(cmd_w_d,dy,0,p_line,0*i_line,w_limit,&angle_error1);//i_line Reduces the  error but also causes overshoot
            if(fabs(dy)<0.02)
            {
                dy=0;
                w_output=0;
            }
        }
        if (cmd_w_d!=0 && angle_d==0)  // 2  rotate
        {
            float dy=cmd_w_d-dir.real_w;
            w_output=angle_pid(cmd_w_d,dy,f_gain,p_gain,i_gain,w_limit,&angle_error2);
            //dir.theory_anlge+=cmd_w_d*ctrl.cycle;  //errors will accumulate ,so dir.theory_anlge need to be updated
            dir.theory_anlge=dir.real_angle;
        }
    }
    if ( input.cmd_last == W_ANGLE_IMU)
    {
        if (cmd_w_d==0 )  // 3
        {
            cmd_w_d=50*PI_HD/180;
        }
        if (cmd_w_d!=0 )  // 4
        {
            cmd_w_d=w_interp(dir.theory_anlge,cmd_w_d,angle_d);
            w_output=cmd_w_d;

            if ( fabs(dir.real_angle-dir.theory_anlge)>=fabs(angle_d) )  //rotate direction control
            {
                if(ret==NULL)
                {
                    printf("pointer error! \r\n");
                    return -1;
                }
                *ret=1;
                inner.end_flag=1;
                dir.theory_anlge+=angle_d;
            }
        }
    }

    //--print
    if(printf_option.car_rotate_pid)
    {
        static int count=1;
        if(count++%100==0)
        {
            printf("w_d,w; dir_d,dir; imu %.2f, %.2f, %.2f , %.2f , %.2f\r\n",
                   w_output,dir.real_w ,dir.theory_anlge,dir.real_angle ,sensor.imu_yaw);
            count=1;
        }
    }
    //--clear & return
    if(inner.end_flag==1) //clear static var
    {
        w_output=0;
        angle_d_last=0;
        angle_error1=0;
        angle_error2=0;
    }
    return w_output;
}

//--other functions
float sign1(float x)
{
    if(x>=0)
    {
        return 1;
    }
    else
    {
        return -1;
    }
}
float get_fabs_min(float a,float b)
{
    float ret=fabs(a);
    if(fabs(a)>fabs(b))
    {
        ret=fabs(b);
    }
    return ret;
}
float get_fabs_max(float a,float b)
{
    float ret=fabs(a);
    if(fabs(a)<fabs(b))
    {
        ret=fabs(b);
    }
    return ret;
}
float limit(float in,float min,float max)
{
    float out;
    if (in<min)
    {
        out=min;
    }
    else if (in>max)
    {
        out=max;
    }
    else
    {
        out=in;
    }
    return out;
}

float low_filter(float klow_filter,float in)
{
    static float out_last=0;
    float res;

    res = klow_filter * in  + (1.0F - klow_filter ) * out_last ;
    out_last  = res;

    if(inner.end_flag==1)
    {
        out_last=0;
    }

    return res;
}
float w_interp(float start_angle,float cmd_w_d,float angle_d)
{
    //-- from ks - 1 - ke
    float k=fabs((start_angle+angle_d-dir.real_angle)/angle_d);
    float ks=0.3,ke=0.3,t1=0.1,t2=0.9;
    ks=vw.kn[0];
    ke=vw.kn[1];
    t1=vw.kn[2];
    t2=vw.kn[3];

    float kw=0;
    if(1-k<t1)
    {
        kw=(1-k)*(1-ks)/t1+ks;
    }
    else if(1-k>t2)
    {
        kw=(1-k)*(ke-1)/(1-t2)+ke-(ke-1)/(1-t2);
    }
    else
    {
        kw=1;
    }
    cmd_w_d=fabs(cmd_w_d)*sign1(angle_d)*kw;
    return cmd_w_d;
}

void cal_imu_yaw()
{
    static bool initiate=1;
    static int count=1;
    static float imu_yaw_last=0,w_last=0;

    if (initiate==1)  //if == 1,2 ,rotate speed=0
    {
        imu_yaw_last=sensor.imu_yaw;
        initiate=0;
    }
    if(count==ctrl.imu_update+1)  //integrate angle changes
    {
        float delta_angle=imu_singularity(sensor.imu_yaw,imu_yaw_last);
        if(car.imu_type==GLOBALIMU && car.robot_type==CLEANROBOT)
        {
            dir.real_angle=sensor.imu_yaw;
        }
        if(car.imu_type==LOCALIMU || car.robot_type==YBROBOT)
        {
            dir.real_angle+=delta_angle;
        }
        dir.real_w=delta_angle/(ctrl.imu_update*ctrl.cycle);
        //--reset & update
        count=1;
        imu_yaw_last=sensor.imu_yaw;
    }
    count++;

    //--filter w_real
    float klow_filter=0.1;
    dir.real_w = klow_filter * dir.real_w  + (1.0F - klow_filter ) * w_last ;
    w_last  = dir.real_w;
    //--clear static var
    if(inner.end_flag==1)
    {
        initiate=1;
        count=1;
        imu_yaw_last=0;
        w_last=0;
    }
}
float imu_singularity(float imu_yaw,float imu_yaw_last)
{
    float angle;
    if(imu_yaw-imu_yaw_last<-PI_HD)
    {
        angle=imu_yaw+PI_HD+PI_HD-imu_yaw_last;
    }
    else if(imu_yaw-imu_yaw_last>PI_HD)
    {
        angle=imu_yaw-PI_HD-PI_HD-imu_yaw_last;
    }
    else
    {
        angle=imu_yaw-imu_yaw_last;
    }
    return angle;
}
bool control_trigger(float angle_d,float dy)
{
    static bool trigger=0;
    static int num=0;
    static float angle_d_last=0;

    if(angle_d!=angle_d_last || fabs(dy)>PI_HD/180*5) //reset & update
    {
        num=0;
        trigger=1;
        angle_d_last=angle_d;
    }
    else
    {
        if(num<1000)
        {
            num++;
        }
    }
    if(num>10)
    {
        trigger=0;
    }
    return trigger;
}


