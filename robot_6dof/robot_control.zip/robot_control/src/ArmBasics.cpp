#include "robot_control/ArmBasics.h"
#include "yaml-cpp/yaml.h"

ArmBasics::ArmBasics()
{
    YAML::Node config = YAML::LoadFile("../../../../src/config.yaml");
    //--m_armParam
    m_armParam.xTool=config["arm"]["xTool"].as< float >();
    m_armParam.yTool=config["arm"]["yTool"].as< float >();
    m_armParam.zTool=config["arm"]["zTool"].as< float >();

    m_armParam.dof=config["motor"]["num"].as< int >();
    m_armParam.dhParam =config["arm"]["dhParam"].as< Matrix<float,6,1> >();
    m_armParam.mass =config["arm"]["mass"].as< Matrix<float,6,1> >();

    m_armParam.zeroPos<<0,0,0,0,0,0;
    m_armParam.zeroPos=m_armParam.zeroPos*DEG2RAD;

    m_armParam.jointType=config["motor"]["jointType"].as< Matrix<int,6,1> >();
    //--load param
    LoadParam();

    //--m_armInput
    m_armInput.toolPos<<0,0,0,0,0,0;
    m_armInput.jointPos=m_armParam.zeroPos;
    m_armInput.jointPosLast=m_armParam.zeroPos;
    m_armInput.jointVel<<0,0,0,0,0,0;
    m_armInput.jointVelLast<<0,0,0,0,0,0;
    m_armInput.jointAcc<<0,0,0,0,0,0;

    m_armInput.jointCurrent<<0,0,0,0,0,0;
    m_armInput.jointTorque<<0,0,0,0,0,0;

    //--m_armFeedBack
    m_armFeedBack.toolPos<<0,0,0,0,0,0;
    m_armFeedBack.jointPos=m_armParam.zeroPos;
    m_armFeedBack.jointPosLast=m_armParam.zeroPos;
    m_armFeedBack.jointRealPos=m_armParam.zeroPos;
    m_armFeedBack.jointRealVel<<0,0,0,0,0,0;
    m_armFeedBack.jointRealVelLast<<0,0,0,0,0,0;
    m_armFeedBack.jointRealAcc<<0,0,0,0,0,0;

    m_armFeedBack.jointCurrent<<0,0,0,0,0,0;
    //--IK state
    m_isIkError=false;
}

void ArmBasics::LoadParam()
{
    YAML::Node config = YAML::LoadFile("../../../../src/config.yaml");

    m_armParam.jointPosLimit=config["motor"]["limit"].as< Matrix<float,6,2> >();
    m_armParam.jointVelLimit=config["motor"]["jointVelLimit"].as< Matrix<float,6,1> >();
    m_armParam.jointAccLimit=config["motor"]["jointAccLimit"].as< Matrix<float,6,1> >();
    for(int i=0;i<m_armParam.dof;i++)
    {
        if(m_armParam.jointType(i)==0)
        {
            m_armParam.jointPosLimit.row(i)=m_armParam.jointPosLimit.row(i)*DEG2RAD;
            m_armParam.jointVelLimit(i)=m_armParam.jointVelLimit(i)*DEG2RAD;
            m_armParam.jointAccLimit(i)=m_armParam.jointAccLimit(i)*DEG2RAD;
        }
    }
    m_armParam.kTorque=config["motor"]["kTorque"].as< Matrix<float,6,1> >();//
}
ArmBasics::~ArmBasics()
{
}
armFeedBack ArmBasics::ReadArmState()
{
    return m_armFeedBack;
}
armParam ArmBasics::ReadArmParam()
{
    return m_armParam;
}
Vector6f ArmBasics::VelControl(Vector6f &joint,Vector6f &vd)
{
    Vector5f vJoint;
    float t1,t2,t3,t4,t5,t6;
    t1=joint(0);
    t2=joint(1)+90*DEG2RAD;
    t3=joint(2);
    t4=joint(3);
    t5=joint(4);
    t6=joint(5);

    Matrix<float,6,5> J0;
    Matrix<float,5,5>I;

    //Matrix<float, Dynamic, Dynamic> J0(6,m_armParam.dof);
    //Matrix<float, Dynamic, Dynamic> I(m_armParam.dof,m_armParam.dof);
    J0=Jacobian0(joint);

    //-- sigularity avoidance
    //maniplty compute
    Matrix<float,3,6> JJ;
    JJ=J0.block<3,6>(0,0);
    Matrix3f tmp;
    tmp=JJ * JJ.transpose();
    float manip,k,kk,renta;
    manip=sqrt(tmp.determinant());
    k=0.01;
    kk=0.05;
    I=MatrixXf::Identity(m_armParam.dof,m_armParam.dof);
    renta=(1-(manip/k)*(manip/k))*kk;
    Matrix<float,5,5> tmp2,tmp3;
    if (manip<=0.01)
    {
        tmp2=(J0.transpose()*J0+renta*I);
        vJoint=tmp2.inverse()*J0.transpose()*vd ;
        //vJoint=J0.transpose()*tmp2.inverse()*vd ;
    }
    else
    {
        MatrixXf Jinv,Jtmp;
        Jtmp=J0;

        pinv(Jtmp, Jinv);
        vJoint=Jinv*vd ;
    }

    //    if (fabs(vJoint(0))>pi/2 || fabs(vJoint(1))>pi/2 || fabs(vJoint(2))>pi/2 || fabs(vJoint(3))>pi/2 ||
    //            fabs(vJoint(4))>pi/2 || fabs(vJoint(5))>pi/2)
    //    {
    //        tmp2=(J0.transpose()*J0+renta*I);
    //        tmp3=tmp2.inverse();
    //        vJoint=tmp2.inverse()*J0.transpose()*vd ;
    //    }

    //--limit
    for (int j=0;j<m_armParam.dof;j++)
    {
        if(fabs(vJoint(j))>pi/2)
        {
            vJoint(j)=sign(vJoint(j))*pi/4;
        }
        if(isnan(vJoint(j)))
        {
            vJoint(j)=0;
        }
    }
    //vJoint=LowFilter(0.1,vJoint);

    //--return
    Vector6f retVel;
    for(int i=0;i<6;i++)
    {
        if(i<m_armParam.dof)
        {
            retVel(i)=vJoint(i);
        }
        else
        {
            retVel(i)=0;
        }
    }
    return retVel;
}

Matrix3f ArmBasics::GetRotToolZero2base()
{
    Matrix3f R_toolZero2base;
    R_toolZero2base<<1,0,0,
            0,1,0,
            0,0,1;
    return R_toolZero2base;
}
Matrix4f ArmBasics::ArmFK(const Vector6f &angle)
{
    float a1=m_armParam.dhParam(0);
    float a2=m_armParam.dhParam(1);
    float a3=m_armParam.dhParam(2);
    float a4=m_armParam.dhParam(3);

    float t1=angle(0);
    float t2=angle(1)+90*DEG2RAD;
    float t3=angle(2);
    float t4=angle(3);
    float t5=angle(4);

    Matrix4f T1,T2,T3,T4,T5,T;
    T1<< 0,     1,   0,    0,
            -1 , 0,   0,    0,
            0,       0, 1 , t1,
            0,       0,   0,  1.0;
    T2<< cos(t2), -1.0*sin(t2),   0, a1*cos(t2),
            sin(t2),      cos(t2),   0, a1*sin(t2),
            0,            0, 1.0,          0,
            0,            0,   0,        1.0;
    T3<< cos(t3), -1.0*sin(t3),   0, a2*cos(t3),
            sin(t3),      cos(t3),   0, a2*sin(t3),
            0,            0, 1.0,          0,
            0,            0,   0,        1.0;
    T4<< cos(t4),0, -1.0*sin(t4), a3*cos(t4),
            sin(t4),  0,      cos(t4), a3*sin(t4),
            0,             -1.0,      0,          0,
            0,                0,            0,   1.0;
    T5<< cos(t5),0,      sin(t5), a4*cos(t5),
            sin(t5),  0, -cos(t5), a4*sin(t5),
            0,              1.0,      0,          0,
            0,                0,            0,   1.0;
    T=T1*T2*T3*T4*T5;

    return T;
}
Matrix4f ArmBasics::ArmPosCal(const Vector6f &angle,Vector6f* posInBase)
{
    Matrix4f T_tool2base=ArmFK(angle);
    Matrix3f Rot=T_tool2base.block<3,3>(0,0);
    Vector3f RPY=rot2rpy(Rot);
    //--return
    (*posInBase)<<T_tool2base(0,3),T_tool2base(1,3),T_tool2base(2,3),
            RPY(0),RPY(1),RPY(2);
    return T_tool2base;
}

Matrix3f ArmBasics::GetRotToolNext2base(const Vector3f& rpy,const Matrix3f &R_toolNow2base)
{
    Matrix3f R_toolNext2toolNow=rpy2rot(rpy);
    Matrix3f R_toolNext2base=R_toolNow2base*R_toolNext2toolNow;
    return R_toolNext2base;
}
int ArmBasics::ArmIKCheck(const Vector3f &rpy,const Vector3f &pos, int IKtype, Vector6f* angle)
//input  :(1,-1)(right arm ,left arm)
//return :(0,1,2) (no err, out of arm maxium distance , joint out of range)
{
    //--note !!!: pos -> Pos_inBase ; rpy -> RPY_toolNext2toolZero
    Matrix4f T_tool2base;
    Matrix3f R_toolZero2base ;
    R_toolZero2base<<1,0,0,
            0,1,0,
            0,0,1;
    Matrix3f R_toolNext2toolZero;
    float roll,pitch,yaw;
    roll=rpy(0);
    pitch=rpy(1);
    yaw=rpy(2);
    R_toolNext2toolZero<<cos(pitch)*cos(yaw), cos(yaw)*sin(pitch)*sin(roll) - cos(roll)*sin(yaw), sin(roll)*sin(yaw) + cos(roll)*cos(yaw)*sin(pitch),
            cos(pitch)*sin(yaw), cos(roll)*cos(yaw) + sin(pitch)*sin(roll)*sin(yaw), cos(roll)*sin(pitch)*sin(yaw) - cos(yaw)*sin(roll),
            -sin(pitch),                               cos(pitch)*sin(roll),                               cos(pitch)*cos(roll);

    Matrix3f R_toolNext2base=R_toolZero2base*R_toolNext2toolZero;
    T_tool2base<<R_toolNext2base,
            pos,
            (RowVector4f()<<0, 0, 0, 1).finished();

    //--ArmIK
    Vector6f angle1,angle2;
    float t1,t2,t3,t4,t5;
    float c1,c2,c3,c4,s1,s2,s3,s4;

    float a1=0.27;//0.27,0.26,0.23  ,0.032
    float a2=0.26;
    float a3=0.23;
    float a4=0.032;

    float nx=T_tool2base(0,0);
    float ny=T_tool2base(1,0);
    float nz=T_tool2base(2,0);

    float ox=T_tool2base(0,1);
    float oy=T_tool2base(1,1);
    float oz=T_tool2base(2,1);

    float ax=T_tool2base(0,2);
    float ay=T_tool2base(1,2);
    float az=T_tool2base(2,2);

    float px=T_tool2base(0,3);
    float py=T_tool2base(1,3);
    float pz=T_tool2base(2,3);

    //--  t1 t5
    t5=atan2(-nz,az);
    t1=pz+a4*sin(t5);

    // T4_1=T1^-1*T*T5^-1
    Matrix4f T4_1;
    T4_1<< - ny*cos(t5) - ay*sin(t5), ay*cos(t5) - ny*sin(t5), -oy,      a4*ny - py ,
            nx*cos(t5) + ax*sin(t5), nx*sin(t5) - ax*cos(t5),  ox,      px - a4*nx ,
            nz*cos(t5) + az*sin(t5), nz*sin(t5) - az*cos(t5),  oz, pz - t1 - a4*nz ,
            0,                       0,   0,               1;
    //update T
    nx=T4_1(0,0);
    ny=T4_1(1,0);
    nz=T4_1(2,0);

    ox=T4_1(0,1);
    oy=T4_1(1,1);
    oz=T4_1(2,1);

    ax=T4_1(0,2);
    ay=T4_1(1,2);
    az=T4_1(2,2);

    px=T4_1(0,3);
    py=T4_1(1,3);
    pz=T4_1(2,3);

    //-- t2
    int type=1;
    float a=(2*a1*a3*nx-2*px*a1);
    float b=(2*a1*a3*ny-2*py*a1);
    float c=a2*a2-px*px-py*py-a1*a1-a3*a3*nx*nx-a3*a3*ny*ny+2*px*a3*nx+2*py*a3*ny;
    float k1,k2,ksqrt;
    float zeroLimit=1.0e-6;//avoid denominator zero
    for(int i=0;i<2;i++) //two type inverse solutions
    {
        if (fabs(a)>fabs(b))
        {
            k1=c/a;
            k2=b/a;
            ksqrt=k1*k1*k2*k2-(k2*k2+1)*(k1*k1-1);
            if( fabs(ksqrt )<zeroLimit ) // when j3=j4=0,j2!=0, only one solution, ksqrt=0;
            {
                ksqrt=0;
            }
            if(ksqrt<0)
            {
                cout<< "IK error : ksqrt<0 , out of arm maxium distance"<< endl;
                return 1;
            }

            s2=(k1*k2-type*sqrt(ksqrt) )/(k2*k2+1);
            if (fabs(c-b*s2)+fabs(a)<zeroLimit)
            {
                c2=0;
            }
            else
            {
                c2=c/a-b/a*s2;
                c2=(c-b*s2)/a; // better
            }
        }
        else
        {
            k1=c/b;
            k2=a/b;
            ksqrt=k1*k1*k2*k2-(k2*k2+1)*(k1*k1-1);
            if( fabs(ksqrt )<zeroLimit ) // when j3=j4=0,j2!=0, only on solution, so ksqrt=0;
            {
                ksqrt=0;
            }
            if(ksqrt<0)
            {
                cout<< "IK check error : ksqrt<0 , out of arm maxium distance "<< endl;
                return 1;
            }

            c2=(k1*k2-type*sqrt(ksqrt) )/(k2*k2+1);
            if (fabs(c-a*c2)+fabs(b)<zeroLimit)
            {
                c2=0;
            }
            else
            {
                s2=c/b-a/b*c2;
                s2=(c-a*c2)/b; // better
            }
        }
        t2=atan2(s2,c2);

        // t3 t4
        float nx1= nx*cos(t2) + ny*sin(t2);
        float ny1= ny*cos(t2) - nx*sin(t2);

        c3=(px*cos(t2) - a1 + py*sin(t2)-a3*nx1)/a2;
        s3=(py*cos(t2) - px*sin(t2)-a3*ny1)/a2;
        t3=atan2(s3,c3);

        s4=(s3*nx1-c3*ny1)/(-c3*c3-s3*s3);
        if(s3==0)
        {
            c4=(nx1+s3*s4)/c3;
        }
        else
        {
            c4=(ny1-c3*s4)/s3;
        }
        t4=atan2(s4,c4);

        if(i==0)
        {
            angle1<<t1,t2-3.141592/2,t3,t4,t5,0;
            type=-type;
        }
        if(i==1)
        {
            angle2<<t1,t2-3.141592/2,t3,t4,t5,0;// joint 2 zeroAngle=90
        }
    }
    //-- error check
    Matrix<float,6,2> jointPosLimit;
    jointPosLimit<< -0.001,0.81,
            -95,95,
            -145,145,
            -125,125,
            -90,90,
            -90,90;
    jointPosLimit=jointPosLimit/180.0f*3.141592;
    jointPosLimit(0,0)= -0.001;jointPosLimit(0,1)=0.81;
    int ret1=0,ret2=0;
    for(int i=0;i<5;i++)
    {
        if(angle1(i)<jointPosLimit(i,0) || angle1(i)>jointPosLimit(i,1) || isnan(angle1(i)))
        {
           ret1=2;
        }
    }
    for(int i=0;i<5;i++)
    {
        if(angle2(i)<jointPosLimit(i,0) || angle2(i)>jointPosLimit(i,1) || isnan(angle2(i)))
        {
           ret2=2;
        }
    }

    int ret=0;
    if(IKtype==1)//right arm
    {
        if(angle1(2)>=0)
        {
            ret=ret1;
            angle->col(0)=angle1;
        }
        if(angle2(2)>=0)
        {
            ret=ret2;
            angle->col(0)=angle2;
        }
    }
    if(IKtype==-1)//left arm
    {
        if(angle1(2)<=0)
        {
            ret=ret1;
            angle->col(0)=angle1;
        }
        if(angle2(2)<=0)
        {
            ret=ret2;
            angle->col(0)=angle2;
        }
    }
    if(ret==2)
    {
        cout<< "IK check error : joint out of range "<< endl;
    }
    return ret;
}
bool ArmBasics::ArmIK(Matrix4f &T_tool2base,Vector6f *output)
{
    Vector6f angle,angle1,angle2;
    float t1,t2,t3,t4,t5;
    float c1,c2,c3,c4,s1,s2,s3,s4;

    float a1=m_armParam.dhParam(0);
    float a2=m_armParam.dhParam(1);
    float a3=m_armParam.dhParam(2);
    float a4=m_armParam.dhParam(3);

    float nx=T_tool2base(0,0);
    float ny=T_tool2base(1,0);
    float nz=T_tool2base(2,0);

    float ox=T_tool2base(0,1);
    float oy=T_tool2base(1,1);
    float oz=T_tool2base(2,1);

    float ax=T_tool2base(0,2);
    float ay=T_tool2base(1,2);
    float az=T_tool2base(2,2);

    float px=T_tool2base(0,3);
    float py=T_tool2base(1,3);
    float pz=T_tool2base(2,3);

    //--  t1 t5
    t5=atan2(-nz,az);
    t1=pz+a4*sin(t5);

    // T4_1=T1^-1*T*T5^-1
    Matrix4f T4_1;
    T4_1<< - ny*cos(t5) - ay*sin(t5), ay*cos(t5) - ny*sin(t5), -oy,      a4*ny - py ,
            nx*cos(t5) + ax*sin(t5), nx*sin(t5) - ax*cos(t5),  ox,      px - a4*nx ,
            nz*cos(t5) + az*sin(t5), nz*sin(t5) - az*cos(t5),  oz, pz - t1 - a4*nz ,
            0,                       0,   0,               1;
    //update T
    nx=T4_1(0,0);
    ny=T4_1(1,0);
    nz=T4_1(2,0);

    ox=T4_1(0,1);
    oy=T4_1(1,1);
    oz=T4_1(2,1);

    ax=T4_1(0,2);
    ay=T4_1(1,2);
    az=T4_1(2,2);

    px=T4_1(0,3);
    py=T4_1(1,3);
    pz=T4_1(2,3);

    //-- t2
    int type=1;
    float a=(2*a1*a3*nx-2*px*a1);
    float b=(2*a1*a3*ny-2*py*a1);
    float c=a2*a2-px*px-py*py-a1*a1-a3*a3*nx*nx-a3*a3*ny*ny+2*px*a3*nx+2*py*a3*ny;
    float k1,k2,ksqrt;
    float zeroLimit=1.0e-6;//avoid denominator zero
    for(int i=0;i<2;i++) //two type inverse solutions
    {
        if (fabs(a)>fabs(b))
        {
            k1=c/a;
            k2=b/a;
            ksqrt=k1*k1*k2*k2-(k2*k2+1)*(k1*k1-1);
            if( fabs(ksqrt )<zeroLimit ) // when j3=j4=0,j2!=0, only one solution, ksqrt=0;
            {
                ksqrt=0;
            }
            if(ksqrt<0)
            {
                cout<<clr::red<<"ik input error : ksqrt<0 "<<clr::reset<<endl;
            }

            s2=(k1*k2-type*sqrt(ksqrt) )/(k2*k2+1);
            if (fabs(c-b*s2)+fabs(a)<zeroLimit)
            {
                c2=0;
            }
            else
            {
                c2=c/a-b/a*s2;
                c2=(c-b*s2)/a; // better
            }
        }
        else
        {
            k1=c/b;
            k2=a/b;
            ksqrt=k1*k1*k2*k2-(k2*k2+1)*(k1*k1-1);
            if( fabs(ksqrt )<zeroLimit ) // when j3=j4=0,j2!=0, only on solution, so ksqrt=0;
            {
                ksqrt=0;
            }
            if(ksqrt<0)
            {
                cout<<clr::red<<"ik input error : ksqrt<0 "<<clr::reset<<endl;
            }

            c2=(k1*k2-type*sqrt(ksqrt) )/(k2*k2+1);
            if (fabs(c-a*c2)+fabs(b)<zeroLimit)
            {
                c2=0;
            }
            else
            {
                s2=c/b-a/b*c2;
                s2=(c-a*c2)/b; // better
            }
        }
        t2=atan2(s2,c2);

        // t3 t4
        float nx1= nx*cos(t2) + ny*sin(t2);
        float ny1= ny*cos(t2) - nx*sin(t2);

        c3=(px*cos(t2) - a1 + py*sin(t2)-a3*nx1)/a2;
        s3=(py*cos(t2) - px*sin(t2)-a3*ny1)/a2;
        t3=atan2(s3,c3);

        s4=(s3*nx1-c3*ny1)/(-c3*c3-s3*s3);
        if(s3==0)
        {
            c4=(nx1+s3*s4)/c3;
        }
        else
        {
            c4=(ny1-c3*s4)/s3;
        }
        t4=atan2(s4,c4);

        if(i==0)
        {
            angle1<<t1,t2-90*DEG2RAD,t3,t4,t5,0;
            type=-type;
        }
        if(i==1)
        {
            angle2<<t1,t2-90*DEG2RAD,t3,t4,t5,0;// joint 2 zeroAngle=90
        }
    }
    //    if ( (angle1-m_armInput.jointPosLast).norm()<(angle2-m_armInput.jointPosLast).norm() ) //old method
    //    {
    //        angle=angle1;
    //    }
    //    else
    //    {
    //        angle=angle2;
    //    }
    //    cout<<angle1.transpose()<<endl;
    //    cout<<angle2.transpose()<<endl;
    if(sign(m_armInput.jointPosLast(2)*angle1(2))==1 ||
           m_armInput.jointPosLast(2)*angle1(2)==0 )
    {
        angle=angle1;
    }
    else if(sign(m_armInput.jointPosLast(2)*angle2(2))==1)
    {
        angle=angle2;
    }
    else
    {
        angle=angle1;
    }
    //-- error check
    bool ret=IkErrorCheck(T_tool2base,angle,output);
    if(ret==false)
    {
        m_isIkError=true;
    }
    return ret;
}
bool ArmBasics::IkErrorCheck(Matrix4f &T,Vector6f &angle,Vector6f *output)
{
    //-- error check
    Matrix4f error;
    error=ArmFK(angle)-T;
    //tmp=ArmPosCal(angle);//test ok
    cout<<clr::red;
    if(error.norm()>0.01)
    {
        cout<<"IK error: error.norm out of range :"<<error.norm()<<endl;
        return false;
    }
    else
    {
        //--limit
        bool error=false;
        Vector6f tmp=angle;
        for(int i=0;i<6;i++)
        {
            angle(i)=Limit(angle(i),m_armParam.jointPosLimit(i,0),m_armParam.jointPosLimit(i,1));
            if(tmp(i)!=angle(i))
            {
                cout<<"IK out of range:"<<i+1<<" "<<tmp(i)*180/pi<<endl;
                error=true;
            }
//            if(isnan(angle(i)))//useless
//            {
//                cout<<"IK isnan:"<<i+1<<endl;
//                error=true;
//            }
        }
        if(error==true)
        {
            angle=m_armInput.jointPosLast;
            return false;
        }
        output->col(0)=angle;
    }
    cout<<clr::reset;
    return true;
}
bool ArmBasics::ArmIK(const Vector3f &rpy,const Vector3f &pos,Vector6f *output)
{
    //cout<<"IK check2:"<<ArmIKCheck(rpy,pos,sign(m_armInput.jointPosLast(2)))<<endl;
    //--note !!!: pos -> Pos_inBase ; rpy -> RPY_toolNext2toolZero
    Matrix4f T_toolNext2base;

    Matrix3f R_toolZero2base =GetRotToolZero2base();
    Matrix3f R_toolNext2toolZero=rpy2rot(rpy);
    Matrix3f R_toolNext2base=R_toolZero2base*R_toolNext2toolZero;
    T_toolNext2base<<R_toolNext2base,
            pos,
            (RowVector4f()<<0, 0, 0, 1).finished();

    return(ArmIK(T_toolNext2base,output));
}
bool ArmBasics::ArmIK(const Vector6f &goal,Vector6f *output)
{
    Vector3f rpy,pos;
    rpy=goal.block<3,1>(3,0);
    pos=goal.block<3,1>(0,0);
    return(ArmIK(rpy,pos,output));
}
bool ArmBasics::ArmIKForCheck(const Vector6f &goal,Vector6f *output,Matrix4f *Ttool2base)
{
    Vector3f rpy,pos;
    rpy=goal.block<3,1>(3,0);
    pos=goal.block<3,1>(0,0);
    //--note !!!: pos -> Pos_inBase ; rpy -> RPY_toolNext2toolZero
    Matrix4f T_toolNext2base;

    Matrix3f R_toolZero2base=GetRotToolZero2base();
    Matrix3f R_toolNext2toolZero=rpy2rot(rpy);
    Matrix3f R_toolNext2base=R_toolZero2base*R_toolNext2toolZero;
    T_toolNext2base<<R_toolNext2base,
            pos,
            (RowVector4f()<<0, 0, 0, 1).finished();
    (*Ttool2base)=T_toolNext2base;//update

    //--return
    if(ArmIK(T_toolNext2base,output)==false)
    {
        return false;
    }
    else
    {
        return true;
    }
}

float ArmBasics::AngleTrans(float t4)
{
    //-- t4=atan2() -> but offset!=0 ,
    //--the function can increase the range to 360 degree
    float out=t4;
    if(sign(m_armParam.zeroPos(2))<0)
    {
        if(t4>pi+m_armParam.zeroPos(2) && t4<=pi)
        {
            out=t4+sign(m_armParam.zeroPos(2))*2*pi;
        }
    }
    if(sign(m_armParam.zeroPos(2))>0)
    {
        if( t4>=-pi && t4<-pi+m_armParam.zeroPos(2))
        {
            out=t4+sign(m_armParam.zeroPos(2))*2*pi;
        }
    }
    return out;
}

bool ArmBasics::JointLimit(bool isFeedBack,Vector6f& angle)
{
    float isOutOfRange=0;
    for(int i=0;i<m_armParam.dof;i++)
    {
        cout<<clr::red;
        float tmp=angle(i);
        angle(i)=Limit(angle(i),m_armParam.jointPosLimit(i,0),m_armParam.jointPosLimit(i,1));
        if(tmp!=angle(i))
        {
            float kUnit=1;
            if(m_armParam.jointType(i)==0)
            {
                kUnit=RAD2DEG;
            }
            else
            {
                kUnit=1;
            }
            if(isFeedBack)
            {
                cout<<"Feedback out of range:"<<i+1<<" "<<tmp*kUnit<<endl;
            }
            else
            {
                cout<<"Input out of range:"<<i+1<<" "<<tmp*kUnit<<endl;
            }
            isOutOfRange=1;
        }
        if(isnan(angle(i)))
        {
            angle(i)=m_armInput.jointPosLast(i);
            cout<<"isnan"<<i+1<<endl;
            isOutOfRange=1;
        }
        cout<<clr::reset;
    }
    return isOutOfRange;
}
Vector6f ArmBasics::Current2torque(Vector6f &current)
{
    Vector6f torque;
    for(int i=0;i<m_armParam.dof;i++)
    {
        torque(i)=current(i)/m_armParam.kTorque(i);
    }
    return torque;
}
Vector6f ArmBasics::Torque2Current(Vector6f &torque)
{
    Vector6f current;
    for(int i=0;i<m_armParam.dof;i++)
    {
        current(i)=torque(i)*m_armParam.kTorque(i);
    }
    return current;
}
Vector6f ArmBasics::CalCurrentByTheoryPos()
{
    Vector6f out;
    out=ArmDynamicDH(m_armInput.jointPos,m_armInput.jointVel,m_armInput.jointAcc);
    out=Torque2Current(out);
    return out;
}
Vector6f ArmBasics::CalCurrentByRealPos()
{
    Vector6f out;
    out=ArmDynamicDH(m_armFeedBack.jointRealPos,m_armFeedBack.jointRealVel,m_armFeedBack.jointRealAcc);
    out=Torque2Current(out);
    return out;
}
Vector6f ArmBasics::ArmDynamicDH(const Vector6f &qIn,const Vector6f &qdIn,
                                 const Vector6f &qddIn) //generated by matlab
{
    //--input
    float tau[6],q[6],qd[6],qdd[6];
    Vector6f out,zeroPos,qTmp;
    zeroPos<<0,pi/2,0 ,0,0,0;
    qTmp=qIn+zeroPos;
    for(int i=0;i<6;i++)
    {
        q[i]=qTmp[i];
        qd[i]=qdIn[i];
        qdd[i]=qddIn[i];
    }
    //--
    int i0;
    float P[15];
    static const float fv0[3] = { 0.27F, 0.0F, 0.0F };

    float I[15];
    static const float fv1[3] = { 0.00290420908F, 0.00356141338F, 0.00578756584F };

    static const float fv2[3] = { 0.26F, 0.0F, 0.0F };

    static const float fv3[3] = { 0.000689986569F, 0.0101865958F, 0.0104905516F };

    static const float fv4[3] = { 0.23F, 0.0F, 0.0F };

    static const float fv5[3] = { 0.000277543586F, 0.00672127632F, 0.00682154298F
                                };

    static const float fv6[3] = { 0.121F, 0.0F, 0.0F };

    static const float fv7[3] = { 0.000179554059F, 0.00280507188F, 0.00276487251F
                                };

    float Pc[15];
    static const float fv8[3] = { -0.0413791947F, -0.0293101873F, 0.0754931122F };

    float R[54];
    static const float fv9[3] = { 0.140442744F, 1.28953216E-5F, 0.0401881F };

    static const float fv10[3] = { 0.146951228F, -9.59961108E-5F, 0.0155273788F };

    static const float fv11[3] = { 0.125755F, 0.000400762743F, -0.00510613155F };

    int i1;
    int i;
    static const signed char iv0[3] = { 0, 0, 1 };

    static const signed char iv1[9] = { 0, 1, 0, -1, 0, 0, 0, 0, 1 };

    float Ic[45];
    float w[18];
    static const signed char iv2[3] = { 0, -1, 0 };

    static const signed char iv3[3] = { 0, 1, 0 };

    float dw[18];
    float dv[18];
    static const float fv12[3] = { 0.0F, 0.0F, 9.8F };

    float dvc[18];
    static const signed char iv4[5] = { 1, 0, 0, 0, 0 };

    float c[3];
    float b_R[3];
    float b_w[3];
    float b_c[3];
    float b_dw[3];
    float c_dw[3];
    float b[3];
    float fv13[3];
    float f0;
    static const signed char a[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

    static const signed char b_b[3] = { 0, 0, 1 };

    float N[15];
    static const float fv14[5] = { 1.3515F, 1.1584F, 0.8732F, 0.7029F, 0.5F };

    /*  !!! attention: [origin of {i-1} in {i}]*-1    i=0,1,,,,,  [link.a; d*sin(alpha); d*cos(alpha)]; */
    /* mass centre of Link(i) in {i} */
    /*  the Tc of link i is in the coordinate {i} */
    /*  DH & dynamic params */
    for (i0 = 0; i0 < 3; i0++) {
        P[i0] = 0.0F;
        P[3 + i0] = fv0[i0];
        P[6 + i0] = fv2[i0];
        P[9 + i0] = fv4[i0];
        P[12 + i0] = fv6[i0];
        Pc[i0] = fv8[i0];
        Pc[3 + i0] = fv9[i0];
        Pc[6 + i0] = fv10[i0];
        Pc[9 + i0] = fv11[i0];
        Pc[12 + i0] = 0.0F;
    }

    for (i0 = 0; i0 < 3; i0++) {
        I[5 * i0] = fv1[i0];
        I[1 + 5 * i0] = fv3[i0];
        I[2 + 5 * i0] = fv5[i0];
        I[3 + 5 * i0] = fv7[i0];
        I[4 + 5 * i0] = 0.0F;
    }

    /*  input */
    /* angle velocity */
    /* angle accelation */
    /*  DH */
    memset(&R[0], 0, 54U * sizeof(float));

    /*  i to i+1 */
    R[9] = cosf(q[1]);
    R[10] = -sinf(q[1]);
    R[11] = 0.0F;
    R[12] = sinf(q[1]);
    R[13] = cosf(q[1]);
    R[14] = 0.0F;
    R[18] = cosf(q[2]);
    R[19] = -sinf(q[2]);
    R[20] = 0.0F;
    R[21] = sinf(q[2]);
    R[22] = cosf(q[2]);
    R[23] = 0.0F;
    R[27] = cosf(q[3]);
    R[28] = 0.0F;
    R[29] = -sinf(q[3]);
    R[30] = sinf(q[3]);
    R[31] = 0.0F;
    R[32] = cosf(q[3]);
    R[36] = cosf(q[4]);
    R[37] = 0.0F;
    R[38] = sinf(q[4]);
    R[39] = sinf(q[4]);
    R[40] = 0.0F;
    R[41] = -cosf(q[4]);
    for (i0 = 0; i0 < 3; i0++) {
        for (i1 = 0; i1 < 3; i1++) {
            R[i1 + 3 * i0] = iv1[i1 + 3 * i0];
        }

        R[15 + i0] = iv0[i0];
        R[24 + i0] = iv0[i0];
        R[33 + i0] = iv2[i0];
        R[42 + i0] = iv3[i0];
    }

    /*  */
    for (i = 0; i < 5; i++) {
        Ic[9 * i] = I[i];
        Ic[3 + 9 * i] = 0.0F;
        Ic[6 + 9 * i] = 0.0F;
        Ic[1 + 9 * i] = 0.0F;
        Ic[4 + 9 * i] = I[5 + i];
        Ic[7 + 9 * i] = 0.0F;
        Ic[2 + 9 * i] = 0.0F;
        Ic[5 + 9 * i] = 0.0F;
        Ic[8 + 9 * i] = I[10 + i];
    }

    /*  0:n-1 */
    memset(&w[0], 0, 18U * sizeof(float));
    for (i0 = 0; i0 < 3; i0++) {
        w[i0] = 0.0F;
    }

    memset(&dw[0], 0, 18U * sizeof(float));
    for (i0 = 0; i0 < 3; i0++) {
        dw[i0] = 0.0F;
    }

    memset(&dv[0], 0, 18U * sizeof(float));
    for (i0 = 0; i0 < 3; i0++) {
        dv[i0] = fv12[i0];
        dvc[i0] = 0.0F;
    }

    for (i = 0; i < 5; i++) {
        if (iv4[i] == 1) {
            for (i0 = 0; i0 < 3; i0++) {
                b_R[i0] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    b_R[i0] += R[(i0 + 3 * i1) + 9 * i] * w[i1 + 3 * i];
                }
            }

            for (i0 = 0; i0 < 3; i0++) {
                w[i0 + 3 * (i + 1)] = b_R[i0];
                b_w[i0] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    b_w[i0] += R[(i0 + 3 * i1) + 9 * i] * dw[i1 + 3 * i];
                }
            }

            c[0] = 0.0F;
            c[1] = 0.0F;
            c[2] = qd[i];
            b_c[0] = w[1 + 3 * (i + 1)] * P[2 + 3 * i] - w[2 + 3 * (i + 1)] * P[1 + 3 *
                    i];
            b_c[1] = w[2 + 3 * (i + 1)] * P[3 * i] - w[3 * (i + 1)] * P[2 + 3 * i];
            b_c[2] = w[3 * (i + 1)] * P[1 + 3 * i] - w[1 + 3 * (i + 1)] * P[3 * i];
            b_dw[0] = 0.0F;
            b_dw[1] = 0.0F;
            b_dw[2] = qdd[i];
            for (i0 = 0; i0 < 3; i0++) {
                dw[i0 + 3 * (i + 1)] = b_w[i0];
                b[i0] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    b[i0] += R[(i0 + 3 * i1) + 9 * i] * c[i1];
                }

                fv13[i0] = b_dw[i0] + dv[i0 + 3 * i];
            }

            c_dw[0] = dw[1 + 3 * (i + 1)] * P[2 + 3 * i] - dw[2 + 3 * (i + 1)] * P[1 +
                    3 * i];
            c_dw[1] = dw[2 + 3 * (i + 1)] * P[3 * i] - dw[3 * (i + 1)] * P[2 + 3 * i];
            c_dw[2] = dw[3 * (i + 1)] * P[1 + 3 * i] - dw[1 + 3 * (i + 1)] * P[3 * i];
            c[0] = 2.0F * (w[1 + 3 * (i + 1)] * b[2] - w[2 + 3 * (i + 1)] * b[1]);
            c[1] = 2.0F * (w[2 + 3 * (i + 1)] * b[0] - w[3 * (i + 1)] * b[2]);
            c[2] = 2.0F * (w[3 * (i + 1)] * b[1] - w[1 + 3 * (i + 1)] * b[0]);
            b_w[0] = w[1 + 3 * (i + 1)] * b_c[2] - w[2 + 3 * (i + 1)] * b_c[1];
            b_w[1] = w[2 + 3 * (i + 1)] * b_c[0] - w[3 * (i + 1)] * b_c[2];
            b_w[2] = w[3 * (i + 1)] * b_c[1] - w[1 + 3 * (i + 1)] * b_c[0];
            for (i0 = 0; i0 < 3; i0++) {
                b_R[i0] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    b_R[i0] += R[(i0 + 3 * i1) + 9 * i] * fv13[i1];
                }

                dv[i0 + 3 * (i + 1)] = ((b_R[i0] + c_dw[i0]) + c[i0]) + b_w[i0];
            }
        } else {
            c[0] = 0.0F;
            c[1] = 0.0F;
            c[2] = qd[i];
            for (i0 = 0; i0 < 3; i0++) {
                b_w[i0] = w[i0 + 3 * i] + c[i0];
            }

            for (i0 = 0; i0 < 3; i0++) {
                w[i0 + 3 * (i + 1)] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    w[i0 + 3 * (i + 1)] += R[(i0 + 3 * i1) + 9 * i] * b_w[i1];
                }
            }

            c[0] = 0.0F;
            c[1] = 0.0F;
            c[2] = qdd[i];
            b_w[0] = w[1 + 3 * i] * qd[i];
            b_w[1] = 0.0F - w[3 * i] * qd[i];
            b_w[2] = 0.0F;
            for (i0 = 0; i0 < 3; i0++) {
                c_dw[i0] = (dw[i0 + 3 * i] + c[i0]) + b_w[i0];
            }

            for (i0 = 0; i0 < 3; i0++) {
                dw[i0 + 3 * (i + 1)] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    dw[i0 + 3 * (i + 1)] += R[(i0 + 3 * i1) + 9 * i] * c_dw[i1];
                }
            }

            b[0] = w[1 + 3 * (i + 1)] * P[2 + 3 * i] - w[2 + 3 * (i + 1)] * P[1 + 3 *
                    i];
            b[1] = w[2 + 3 * (i + 1)] * P[3 * i] - w[3 * (i + 1)] * P[2 + 3 * i];
            b[2] = w[3 * (i + 1)] * P[1 + 3 * i] - w[1 + 3 * (i + 1)] * P[3 * i];
            c_dw[0] = dw[1 + 3 * (i + 1)] * P[2 + 3 * i] - dw[2 + 3 * (i + 1)] * P[1 +
                    3 * i];
            c_dw[1] = dw[2 + 3 * (i + 1)] * P[3 * i] - dw[3 * (i + 1)] * P[2 + 3 * i];
            c_dw[2] = dw[3 * (i + 1)] * P[1 + 3 * i] - dw[1 + 3 * (i + 1)] * P[3 * i];
            b_w[0] = w[1 + 3 * (i + 1)] * b[2] - w[2 + 3 * (i + 1)] * b[1];
            b_w[1] = w[2 + 3 * (i + 1)] * b[0] - w[3 * (i + 1)] * b[2];
            b_w[2] = w[3 * (i + 1)] * b[1] - w[1 + 3 * (i + 1)] * b[0];
            for (i0 = 0; i0 < 3; i0++) {
                f0 = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    f0 += R[(i0 + 3 * i1) + 9 * i] * dv[i1 + 3 * i];
                }

                b_dw[i0] = (c_dw[i0] + b_w[i0]) + f0;
            }

            for (i0 = 0; i0 < 3; i0++) {
                dv[i0 + 3 * (i + 1)] = b_dw[i0];
            }
        }

        b[0] = w[1 + 3 * (i + 1)] * Pc[2 + 3 * i] - w[2 + 3 * (i + 1)] * Pc[1 + 3 *
                i];
        b[1] = w[2 + 3 * (i + 1)] * Pc[3 * i] - w[3 * (i + 1)] * Pc[2 + 3 * i];
        b[2] = w[3 * (i + 1)] * Pc[1 + 3 * i] - w[1 + 3 * (i + 1)] * Pc[3 * i];
        c_dw[0] = dw[1 + 3 * (i + 1)] * Pc[2 + 3 * i] - dw[2 + 3 * (i + 1)] * Pc[1 +
                3 * i];
        c_dw[1] = dw[2 + 3 * (i + 1)] * Pc[3 * i] - dw[3 * (i + 1)] * Pc[2 + 3 * i];
        c_dw[2] = dw[3 * (i + 1)] * Pc[1 + 3 * i] - dw[1 + 3 * (i + 1)] * Pc[3 * i];
        b_w[0] = w[1 + 3 * (i + 1)] * b[2] - w[2 + 3 * (i + 1)] * b[1];
        b_w[1] = w[2 + 3 * (i + 1)] * b[0] - w[3 * (i + 1)] * b[2];
        b_w[2] = w[3 * (i + 1)] * b[1] - w[1 + 3 * (i + 1)] * b[0];
        for (i0 = 0; i0 < 3; i0++) {
            dvc[i0 + 3 * (i + 1)] = (c_dw[i0] + b_w[i0]) + dv[i0 + 3 * (i + 1)];
        }

        for (i0 = 0; i0 < 3; i0++) {
            I[i0 + 3 * i] = fv14[i] * dvc[i0 + 3 * (i + 1)];
            b[i0] = 0.0F;
            b_dw[i0] = 0.0F;
            for (i1 = 0; i1 < 3; i1++) {
                b[i0] += Ic[(i0 + 3 * i1) + 9 * i] * w[i1 + 3 * (i + 1)];
                b_dw[i0] += Ic[(i0 + 3 * i1) + 9 * i] * dw[i1 + 3 * (i + 1)];
            }
        }

        b_w[0] = w[1 + 3 * (i + 1)] * b[2] - w[2 + 3 * (i + 1)] * b[1];
        b_w[1] = w[2 + 3 * (i + 1)] * b[0] - w[3 * (i + 1)] * b[2];
        b_w[2] = w[3 * (i + 1)] * b[1] - w[1 + 3 * (i + 1)] * b[0];
        for (i0 = 0; i0 < 3; i0++) {
            N[i0 + 3 * i] = b_dw[i0] + b_w[i0];
        }
    }

    /*  n:1 */
    memset(&w[0], 0, 18U * sizeof(float));
    memset(&dw[0], 0, 18U * sizeof(float));
    for (i = 0; i < 5; i++) {
        if (5 - i == 5) {
            for (i0 = 0; i0 < 3; i0++) {
                f0 = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    f0 += (float)a[i0 + 3 * i1] * w[i1 + 3 * (5 - i)];
                }

                b_dw[i0] = f0 + I[i0 + 3 * (4 - i)];
            }

            for (i0 = 0; i0 < 3; i0++) {
                w[i0 + 3 * (4 - i)] = b_dw[i0];
                b[i0] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    b[i0] += (float)a[i0 + 3 * i1] * P[i1 + 3 * (4 - i)];
                }

                b_c[i0] = P[i0 + 3 * (4 - i)] + Pc[i0 + 3 * (4 - i)];
            }

            b_dw[0] = b[1] * w[2 + 3 * (5 - i)] - b[2] * w[1 + 3 * (5 - i)];
            b_dw[1] = b[2] * w[3 * (5 - i)] - b[0] * w[2 + 3 * (5 - i)];
            b_dw[2] = b[0] * w[1 + 3 * (5 - i)] - b[1] * w[3 * (5 - i)];
            for (i0 = 0; i0 < 3; i0++) {
                c_dw[i0] = dw[i0 + 3 * (5 - i)] + b_dw[i0];
            }

            c[0] = b_c[1] * I[2 + 3 * (4 - i)] - b_c[2] * I[1 + 3 * (4 - i)];
            c[1] = b_c[2] * I[3 * (4 - i)] - b_c[0] * I[2 + 3 * (4 - i)];
            c[2] = b_c[0] * I[1 + 3 * (4 - i)] - b_c[1] * I[3 * (4 - i)];
            for (i0 = 0; i0 < 3; i0++) {
                b_dw[i0] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    b_dw[i0] += (float)a[i0 + 3 * i1] * c_dw[i1];
                }

                dw[i0 + 3 * (4 - i)] = (b_dw[i0] + c[i0]) + N[i0 + 3 * (4 - i)];
                b_R[i0] = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    b_R[i0] += R[(i0 + 3 * i1) + 9 * (4 - i)] * (float)b_b[i1];
                }
            }

            f0 = 0.0F;
            for (i0 = 0; i0 < 3; i0++) {
                f0 += dw[i0 + 3 * (4 - i)] * b_R[i0];
            }

            tau[4 - i] = f0;
        } else {
            for (i0 = 0; i0 < 3; i0++) {
                f0 = 0.0F;
                for (i1 = 0; i1 < 3; i1++) {
                    f0 += R[(i1 + 3 * i0) + 9 * (5 - i)] * w[i1 + 3 * (5 - i)];
                }

                b_R[i0] = f0 + I[i0 + 3 * (4 - i)];
            }

            for (i0 = 0; i0 < 3; i0++) {
                w[i0 + 3 * (4 - i)] = b_R[i0];
            }

            if (iv4[4 - i] == 1) {
                f0 = 0.0F;
                for (i0 = 0; i0 < 3; i0++) {
                    b_R[i0] = 0.0F;
                    for (i1 = 0; i1 < 3; i1++) {
                        b_R[i0] += R[(i0 + 3 * i1) + 9 * (4 - i)] * (float)b_b[i1];
                    }

                    f0 += w[i0 + 3 * (4 - i)] * b_R[i0];
                }

                tau[4 - i] = f0;
            } else {
                for (i0 = 0; i0 < 3; i0++) {
                    b[i0] = 0.0F;
                    for (i1 = 0; i1 < 3; i1++) {
                        b[i0] += R[(i0 + 3 * i1) + 9 * (5 - i)] * P[i1 + 3 * (4 - i)];
                    }

                    b_c[i0] = P[i0 + 3 * (4 - i)] + Pc[i0 + 3 * (4 - i)];
                }

                b_dw[0] = b[1] * w[2 + 3 * (5 - i)] - b[2] * w[1 + 3 * (5 - i)];
                b_dw[1] = b[2] * w[3 * (5 - i)] - b[0] * w[2 + 3 * (5 - i)];
                b_dw[2] = b[0] * w[1 + 3 * (5 - i)] - b[1] * w[3 * (5 - i)];
                for (i0 = 0; i0 < 3; i0++) {
                    c_dw[i0] = dw[i0 + 3 * (5 - i)] + b_dw[i0];
                }

                c[0] = b_c[1] * I[2 + 3 * (4 - i)] - b_c[2] * I[1 + 3 * (4 - i)];
                c[1] = b_c[2] * I[3 * (4 - i)] - b_c[0] * I[2 + 3 * (4 - i)];
                c[2] = b_c[0] * I[1 + 3 * (4 - i)] - b_c[1] * I[3 * (4 - i)];
                for (i0 = 0; i0 < 3; i0++) {
                    b_R[i0] = 0.0F;
                    for (i1 = 0; i1 < 3; i1++) {
                        b_R[i0] += R[(i1 + 3 * i0) + 9 * (5 - i)] * c_dw[i1];
                    }

                    dw[i0 + 3 * (4 - i)] = (b_R[i0] + c[i0]) + N[i0 + 3 * (4 - i)];
                    b_w[i0] = 0.0F;
                    for (i1 = 0; i1 < 3; i1++) {
                        b_w[i0] += R[(i0 + 3 * i1) + 9 * (4 - i)] * (float)b_b[i1];
                    }
                }

                f0 = 0.0F;
                for (i0 = 0; i0 < 3; i0++) {
                    f0 += dw[i0 + 3 * (4 - i)] * b_w[i0];
                }

                tau[4 - i] = f0;
            }
        }
    }


    //--
    for(int i=0;i<m_armParam.dof;i++)
    {
        out[i]=tau[i];
    }
    return out;
}

